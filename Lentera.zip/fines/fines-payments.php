<?php
// ============================================================
// LENTERA LIBRARY SYSTEM – PEMBAYARAN DENDA (FINAL STABLE + STATUS BAYAR)
// ============================================================

$pageTitle = "Pembayaran Denda";

if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . "/../config/session_guard.php";
require_once __DIR__ . "/../config/db_config.php";
require_once __DIR__ . "/../includes/header.php";
require_once __DIR__ . "/../includes/sidebar.php";
require_once __DIR__ . "/../includes/topbar.php";

$conn = db();
$school_id = $_SESSION['school_id'] ?? 0;

// ============================================================
// FILTER
// ============================================================
$date_from = $_GET['from'] ?? date('Y-m-01');
$date_to   = $_GET['to'] ?? date('Y-m-d');
$keyword   = trim($_GET['q'] ?? '');
$status    = $_GET['status'] ?? ''; // all / paid / unpaid

$where = "WHERE fp.school_id = ? AND DATE(fp.payment_date) BETWEEN ? AND ?";
$params = [$school_id, $date_from, $date_to];
$types  = "iss";

if ($keyword !== '') {
    $like = "%{$keyword}%";
    $where .= " AND (s.name LIKE ? OR s.nis LIKE ?)";
    $params[] = $like;
    $params[] = $like;
    $types .= "ss";
}

if ($status === "paid") {
    $where .= " AND fp.is_paid = 1";
} elseif ($status === "unpaid") {
    $where .= " AND (fp.is_paid = 0 OR fp.is_paid IS NULL)";
}

// ============================================================
// QUERY PEMBAYARAN DENDA
// ============================================================
$sql = "
    SELECT 
        fp.*, 
        s.name AS student_name, 
        s.nis, 
        l.loan_code
    FROM fine_payments fp
    JOIN students s ON s.id = fp.student_id
    JOIN book_loans l ON l.id = fp.loan_id
    $where
    ORDER BY fp.payment_date DESC
";

$stmt = $conn->prepare($sql);
$stmt->bind_param($types, ...$params);
$stmt->execute();
$res = $stmt->get_result();
?>

<!-- ============================================================ -->
<!-- MAIN CONTENT AREA -->
<!-- ============================================================ -->
<main id="mainContent" class="flex-grow-1 p-4">
  <div class="container-fluid">

    <!-- HEADER -->
    <div class="d-flex justify-content-between align-items-center mb-3">
      <h4 class="text-primary mb-0">
        <i class="bi bi-cash-stack me-2"></i> Pembayaran Denda
      </h4>
      <div>
        <a href="fines-payments-create.php" class="btn btn-primary btn-sm me-2">
          <i class="bi bi-plus-lg"></i> Tambah Pembayaran
        </a>
        <a href="fines-payments-pdf.php?from=<?= urlencode($date_from) ?>&to=<?= urlencode($date_to) ?>&q=<?= urlencode($keyword) ?>&status=<?= urlencode($status) ?>"
          target="_blank" class="btn btn-outline-success btn-sm">
          <i class="bi bi-printer"></i> Cetak PDF
        </a>
      </div>
    </div>

    <!-- ============================================================ -->
    <!-- FILTER FORM -->
    <!-- ============================================================ -->
    <div class="card shadow-sm border-0 mb-4">
      <div class="card-body">
        <form class="row g-2 align-items-end">
          <div class="col-md-3">
            <label class="form-label fw-semibold">Dari Tanggal</label>
            <input type="date" name="from" class="form-control" value="<?= htmlspecialchars($date_from) ?>">
          </div>
          <div class="col-md-3">
            <label class="form-label fw-semibold">Sampai</label>
            <input type="date" name="to" class="form-control" value="<?= htmlspecialchars($date_to) ?>">
          </div>
          <div class="col-md-3">
            <label class="form-label fw-semibold">Cari Nama / NIS</label>
            <input type="text" name="q" class="form-control" placeholder="Nama siswa atau NIS..." value="<?= htmlspecialchars($keyword) ?>">
          </div>
          <div class="col-md-2">
            <label class="form-label fw-semibold">Status</label>
            <select name="status" class="form-select">
              <option value="">Semua</option>
              <option value="paid" <?= $status === 'paid' ? 'selected' : '' ?>>Sudah Dibayar</option>
              <option value="unpaid" <?= $status === 'unpaid' ? 'selected' : '' ?>>Belum Dibayar</option>
            </select>
          </div>
          <div class="col-md-1 d-grid">
            <button type="submit" class="btn btn-primary"><i class="bi bi-search"></i></button>
          </div>
        </form>
      </div>
    </div>

    <!-- ============================================================ -->
    <!-- DATA TABLE -->
    <!-- ============================================================ -->
    <div class="card shadow-sm border-0">
      <div class="card-body">
        <div class="table-responsive">
          <table id="tblPayments" class="table table-bordered table-hover align-middle w-100">
            <thead class="table-light">
              <tr>
                <th width="5%">#</th>
                <th>Kode Peminjaman</th>
                <th>Nama Siswa</th>
                <th>NIS</th>
                <th>Tanggal Bayar</th>
                <th class="text-end">Nominal (Rp)</th>
                <th>Metode</th>
                <th>Status</th>
                <th width="120">Aksi</th>
              </tr>
            </thead>
            <tbody>
              <?php 
              $no = 1; 
              $total = 0;
              while ($r = $res->fetch_assoc()): 
                $total += $r['amount'];
                $statusBadge = $r['is_paid'] ? "<span class='badge bg-success'>Sudah Dibayar</span>" : "<span class='badge bg-warning text-dark'>Belum Dibayar</span>";
              ?>
              <tr>
                <td><?= $no++ ?></td>
                <td><?= htmlspecialchars($r['loan_code']) ?></td>
                <td><?= htmlspecialchars($r['student_name']) ?></td>
                <td><?= htmlspecialchars($r['nis']) ?></td>
                <td><?= date('d/m/Y H:i', strtotime($r['payment_date'])) ?></td>
                <td class="text-end"><?= number_format($r['amount'], 2, ',', '.') ?></td>
                <td class="text-center"><?= $r['method'] ? strtoupper($r['method']) : '-' ?></td>
                <td class="text-center"><?= $statusBadge ?></td>
                <td class="text-center">
                  <?php if (empty($r['is_paid']) || $r['is_paid'] == 0): ?>
                    <a href="fines-payments-edit.php?id=<?= $r['id'] ?>" class="btn btn-sm btn-success">
                      <i class="bi bi-cash-coin"></i> Bayar
                    </a>
                  <?php else: ?>
                    <button class="btn btn-sm btn-outline-secondary" disabled>
                      <i class="bi bi-check-circle"></i>
                    </button>
                  <?php endif; ?>
                </td>
              </tr>
              <?php endwhile; ?>
            </tbody>
            <tfoot>
              <tr class="fw-bold table-secondary">
                <td colspan="5" class="text-end">TOTAL</td>
                <td class="text-end"><?= number_format($total, 2, ',', '.') ?></td>
                <td colspan="3"></td>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>
    </div>

  </div>
</main>

<?php require_once __DIR__ . "/../includes/footer.php"; ?>

<!-- ============================================================ -->
<!-- DATATABLES INIT -->
<!-- ============================================================ -->
<script>
$(document).ready(function() {
  $("#tblPayments").DataTable({
    pageLength: 10,
    order: [[4, 'desc']],
    language: { url: "../assets/lang/indonesian.json" }
  });
});
</script>
