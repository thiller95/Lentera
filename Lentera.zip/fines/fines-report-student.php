<?php
// ============================================================
// LENTERA LIBRARY SYSTEM – LAPORAN DENDA PER SISWA (FINAL FIXED - ALERT NO DATA)
// ============================================================

$pageTitle = "Laporan Denda per Siswa";

if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . "/../config/session_guard.php";
require_once __DIR__ . "/../config/db_config.php";
require_once __DIR__ . "/../includes/header.php";
require_once __DIR__ . "/../includes/sidebar.php";
require_once __DIR__ . "/../includes/topbar.php";

$conn = db();
$school_id = $_SESSION['school_id'] ?? 0;

// ============================================================
// FILTER
// ============================================================
$date_from = $_GET['from'] ?? date('Y-m-01');
$date_to   = $_GET['to'] ?? date('Y-m-d');
$keyword   = trim($_GET['q'] ?? '');

$where = "fp.school_id = ? AND DATE(fp.payment_date) BETWEEN ? AND ?";
$params = [$school_id, $date_from, $date_to];
$types = "iss";

if ($keyword !== '') {
  $keywordLike = "%" . $keyword . "%";
  $where .= " AND (s.name LIKE ? OR s.nis LIKE ?)";
  $params[] = $keywordLike;
  $params[] = $keywordLike;
  $types .= "ss";
}

// ============================================================
// QUERY
// ============================================================
$sql = "
  SELECT 
    s.id AS student_id,
    s.nis,
    s.name AS student_name,
    COUNT(fp.id) AS total_transaksi,
    SUM(fp.amount) AS total_denda
  FROM fine_payments fp
  JOIN students s ON s.id = fp.student_id
  WHERE $where
  GROUP BY s.id, s.name, s.nis
  ORDER BY total_denda DESC
";

$stmt = $conn->prepare($sql);
$stmt->bind_param($types, ...$params);
$stmt->execute();
$res = $stmt->get_result();

$noData = ($res->num_rows === 0);
?>

<!-- ============================================================ -->
<!-- MAIN CONTENT AREA -->
<!-- ============================================================ -->
<main id="mainContent" class="flex-grow-1 p-4">
  <div class="container-fluid">

    <!-- Header -->
    <div class="d-flex justify-content-between align-items-center mb-3">
      <h4 class="text-primary mb-0"><i class="bi bi-people me-2"></i> Laporan Denda per Siswa</h4>
      <a href="fines-report-student-pdf.php?from=<?= urlencode($date_from) ?>&to=<?= urlencode($date_to) ?>&q=<?= urlencode($keyword) ?>"
         target="_blank" class="btn btn-outline-success btn-sm">
        <i class="bi bi-printer"></i> Cetak PDF
      </a>
    </div>

    <!-- Filter -->
    <div class="card shadow-sm border-0 mb-3">
      <div class="card-body">
        <form class="row g-2 align-items-end">
          <div class="col-md-3">
            <label class="form-label">Dari</label>
            <input type="date" name="from" class="form-control" value="<?= htmlspecialchars($date_from) ?>">
          </div>
          <div class="col-md-3">
            <label class="form-label">Sampai</label>
            <input type="date" name="to" class="form-control" value="<?= htmlspecialchars($date_to) ?>">
          </div>
          <div class="col-md-4">
            <label class="form-label">Cari Siswa / NIS</label>
            <input type="text" name="q" class="form-control" placeholder="Nama atau NIS..." value="<?= htmlspecialchars($keyword) ?>">
          </div>
          <div class="col-md-2 d-grid">
            <button type="submit" class="btn btn-primary"><i class="bi bi-search"></i> Tampilkan</button>
          </div>
        </form>
      </div>
    </div>

    <!-- Jika tidak ada data -->
    <?php if ($noData): ?>
      <div class="alert alert-info shadow-sm fade show" role="alert">
        <i class="bi bi-info-circle me-2"></i>
        Belum ada data pembayaran denda untuk periode ini.
      </div>
    <?php endif; ?>

    <!-- Tabel -->
    <div class="card shadow-sm border-0">
      <div class="card-body">
        <div class="table-responsive">
          <table id="tblReport" class="table table-bordered table-hover align-middle">
            <thead class="table-light">
              <tr>
                <th width="5%">#</th>
                <th>NIS</th>
                <th>Nama Siswa</th>
                <th class="text-center">Jumlah Transaksi</th>
                <th class="text-end">Total Denda (Rp)</th>
              </tr>
            </thead>
            <tbody>
              <?php 
              $no = 1; 
              $grand = 0;
              while ($r = $res->fetch_assoc()):
                $grand += (float)$r['total_denda'];
              ?>
              <tr>
                <td><?= $no++ ?></td>
                <td><?= htmlspecialchars($r['nis']) ?></td>
                <td><?= htmlspecialchars($r['student_name']) ?></td>
                <td class="text-center"><?= (int)$r['total_transaksi'] ?></td>
                <td class="text-end"><?= number_format($r['total_denda'], 2, ',', '.') ?></td>
              </tr>
              <?php endwhile; ?>
            </tbody>
            <tfoot>
              <tr class="fw-bold table-secondary">
                <td colspan="4" class="text-end">TOTAL</td>
                <td class="text-end"><?= number_format($grand, 2, ',', '.') ?></td>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>
    </div>

  </div>
</main>

<?php require_once __DIR__ . "/../includes/footer.php"; ?>

<!-- ============================================================ -->
<!-- DATATABLE INIT -->
<!-- ============================================================ -->
<script>
$(function(){
  $("#tblReport").DataTable({
    pageLength: 10,
    order: [[4, 'desc']],
    language: { url: "../assets/lang/indonesian.json" }
  });
});
</script>
