<?php
// ============================================================
// LENTERA LIBRARY SYSTEM – CETAK BUKTI PEMBAYARAN DENDA (FINAL FIXED)
// ============================================================
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . "/../config/session_guard.php";
require_once __DIR__ . "/../config/db_config.php";

$conn = db();
$school_id = $_SESSION['school_id'] ?? 0;
$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) die("Invalid ID");

// ============================================================
// AMBIL DATA PEMBAYARAN
// ============================================================
$stmt = $conn->prepare("
  SELECT 
    fp.id, fp.payment_date, fp.amount, fp.method, fp.note,
    s.name AS student_name, s.nis,
    l.loan_code,
    sc.name AS school_name, sc.logo, sc.address, sc.phone, sc.email
  FROM fine_payments fp
  JOIN students s ON s.id = fp.student_id
  JOIN book_loans l ON l.id = fp.loan_id
  JOIN schools sc ON sc.id = fp.school_id
  WHERE fp.school_id = ? AND fp.id = ?
  LIMIT 1
");
$stmt->bind_param("ii", $school_id, $id);
$stmt->execute();
$res = $stmt->get_result();
$data = $res->fetch_assoc();
if (!$data) die("Data pembayaran tidak ditemukan.");
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="utf-8">
<title>Bukti Pembayaran Denda - <?= htmlspecialchars($data['loan_code']) ?></title>
<link href="../assets/css/bootstrap.min.css" rel="stylesheet">
<style>
body {
  font-family: Arial, sans-serif;
  color: #000;
  font-size: 13px;
  background: #fff;
  margin: 25px;
}
.header {
  display: flex;
  align-items: center;
  border-bottom: 2px solid #000;
  padding-bottom: 10px;
  margin-bottom: 15px;
}
.header img {
  height: 60px;
  width: auto;
  margin-right: 15px;
}
.header .title {
  font-weight: bold;
  font-size: 18px;
  text-transform: uppercase;
}
.table {
  width: 100%;
  border-collapse: collapse;
}
.table td, .table th {
  border: 1px solid #000;
  padding: 6px 8px;
}
.table-borderless td {
  border: none !important;
}
.footer {
  text-align: center;
  font-size: 12px;
  color: #444;
  margin-top: 40px;
}
@media print {
  .no-print { display: none !important; }
  body { margin: 10mm; }
}
</style>
</head>

<body onload="window.print()">

<div class="container my-4">

  <!-- Header -->
  <div class="header">
    <img src="<?= htmlspecialchars($data['logo'] ?: '../assets/img/logo.png') ?>" alt="Logo Sekolah">
    <div>
      <div class="title"><?= htmlspecialchars($data['school_name']) ?></div>
      <div><?= htmlspecialchars($data['address']) ?></div>
      <div>Telp: <?= htmlspecialchars($data['phone'] ?? '-') ?> | Email: <?= htmlspecialchars($data['email'] ?? '-') ?></div>
    </div>
  </div>

  <!-- Title -->
  <div class="text-center mb-3">
    <h5 class="mb-1"><u>Bukti Pembayaran Denda Perpustakaan</u></h5>
    <small>Kode Peminjaman: <strong><?= htmlspecialchars($data['loan_code']) ?></strong></small>
  </div>

  <!-- Info Pembayaran -->
  <table class="table table-borderless mb-3">
    <tr>
      <td width="25%">Nama Siswa</td>
      <td>: <?= htmlspecialchars($data['student_name']) ?></td>
      <td width="25%">Tanggal Bayar</td>
      <td>: <?= date('d M Y H:i', strtotime($data['payment_date'])) ?></td>
    </tr>
    <tr>
      <td>NIS</td>
      <td>: <?= htmlspecialchars($data['nis']) ?></td>
      <td>Metode Pembayaran</td>
      <td>: <?= strtoupper($data['method']) ?></td>
    </tr>
    <tr>
      <td>Nominal Denda</td>
      <td colspan="3">: <strong>Rp <?= number_format($data['amount'], 2, ',', '.') ?></strong></td>
    </tr>
  </table>

  <p><strong>Catatan:</strong><br><?= nl2br(htmlspecialchars($data['note'] ?: '-')) ?></p>

  <!-- Tanda Tangan -->
  <div class="row mt-5">
    <div class="col-6 text-center">
      <p><strong>Penerima</strong></p>
      <br><br><br>
      <p>(<?= htmlspecialchars($_SESSION['name'] ?? 'Petugas') ?>)</p>
    </div>
    <div class="col-6 text-center">
      <p><strong>Pembayar</strong></p>
      <br><br><br>
      <p>(<?= htmlspecialchars($data['student_name']) ?>)</p>
    </div>
  </div>

  <!-- Footer -->
  <div class="footer">
    <p>Terima kasih telah melakukan pembayaran denda. Harap simpan bukti ini dengan baik.</p>
    <p class="no-print">
      <a href="javascript:window.print()" class="btn btn-sm btn-primary mt-2">
        <i class="bi bi-printer"></i> Cetak Ulang
      </a>
    </p>
  </div>
</div>

</body>
</html>
