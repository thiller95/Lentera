<?php
require_once __DIR__ . "/../config/session_guard.php";
require_once __DIR__ . "/../config/db_config.php";
require_once __DIR__ . "/../assets/vendor/fpdf/fpdf.php";

$conn = db();
$school_id = $_SESSION['school_id'];

$date_from = $_GET['from'] ?? date('Y-m-01');
$date_to   = $_GET['to'] ?? date('Y-m-d');
$keyword   = trim($_GET['q'] ?? '');

$where = "WHERE fp.school_id=$school_id AND DATE(fp.payment_date) BETWEEN '$date_from' AND '$date_to'";
if ($keyword !== '') {
  $safe = mysqli_real_escape_string($conn, $keyword);
  $where .= " AND (s.name LIKE '%$safe%' OR s.nis LIKE '%$safe%')";
}

$sql = "
  SELECT fp.*, s.name AS student_name, s.nis, l.loan_code
  FROM fine_payments fp
  JOIN students s ON s.id = fp.student_id
  JOIN book_loans l ON l.id = fp.loan_id
  $where
  ORDER BY fp.payment_date ASC
";
$res = $conn->query($sql);

// ------------------------------------------------------------
// PDF
// ------------------------------------------------------------
$pdf = new FPDF('P', 'mm', 'A4');
$pdf->AddPage();

$pdf->SetFont('Arial', 'B', 14);
$pdf->Cell(0, 10, 'Laporan Pembayaran Denda', 0, 1, 'C');

$pdf->SetFont('Arial', '', 11);
$pdf->Cell(0, 6, "Periode: ".date('d/m/Y',strtotime($date_from))." - ".date('d/m/Y',strtotime($date_to)), 0, 1, 'C');
$pdf->Ln(6);

$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(10,7,'No',1,0,'C');
$pdf->Cell(30,7,'Kode Loan',1,0,'C');
$pdf->Cell(50,7,'Nama Siswa',1,0,'C');
$pdf->Cell(25,7,'NIS',1,0,'C');
$pdf->Cell(30,7,'Tgl Bayar',1,0,'C');
$pdf->Cell(25,7,'Nominal',1,0,'C');
$pdf->Cell(20,7,'Metode',1,1,'C');

$pdf->SetFont('Arial','',10);
$no=1; $total=0;
while($r=$res->fetch_assoc()){
  $pdf->Cell(10,7,$no++,1,0,'C');
  $pdf->Cell(30,7,$r['loan_code'],1,0);
  $pdf->Cell(50,7,substr($r['student_name'],0,28),1,0);
  $pdf->Cell(25,7,$r['nis'],1,0);
  $pdf->Cell(30,7,date('d/m/Y',strtotime($r['payment_date'])),1,0);
  $pdf->Cell(25,7,number_format($r['amount'],0,',','.'),1,0,'R');
  $pdf->Cell(20,7,strtoupper($r['method']),1,1,'C');
  $total += $r['amount'];
}
$pdf->SetFont('Arial','B',10);
$pdf->Cell(145,7,'TOTAL',1,0,'R');
$pdf->Cell(25,7,number_format($total,0,',','.'),1,0,'R');
$pdf->Cell(20,7,'',1,1);

$pdf->Output('I','Laporan_Denda.pdf');
