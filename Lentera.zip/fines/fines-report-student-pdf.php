<?php
// ============================================================
// LENTERA LIBRARY SYSTEM – LAPORAN DENDA PER SISWA (PDF - FINAL HEADER SAFE)
// ============================================================

// 🔒 Pastikan tidak ada output sebelum PDF
ob_start();
if (session_status() === PHP_SESSION_NONE) session_start();
error_reporting(0);

require_once __DIR__ . "/../config/session_guard.php";
require_once __DIR__ . "/../config/db_config.php";
require_once __DIR__ . "/../assets/vendor/fpdf/fpdf.php";

$conn = db();
$school_id = $_SESSION['school_id'] ?? 0;

// ============================================================
// 🗓️ FILTER & PARAMETER
// ============================================================
$date_from = $_GET['from'] ?? date('Y-m-01');
$date_to   = $_GET['to'] ?? date('Y-m-d');
$keyword   = trim($_GET['q'] ?? '');

$where = "WHERE fp.school_id = $school_id AND DATE(fp.payment_date) BETWEEN '$date_from' AND '$date_to'";
if ($keyword !== '') {
  $safe = mysqli_real_escape_string($conn, $keyword);
  $where .= " AND (s.name LIKE '%$safe%' OR s.nis LIKE '%$safe%')";
}

// ============================================================
// 📊 DATA UTAMA
// ============================================================
$sql = "
  SELECT s.nis, s.name AS student_name,
         COUNT(fp.id) AS total_transaksi,
         SUM(fp.amount) AS total_denda
  FROM fine_payments fp
  JOIN students s ON s.id = fp.student_id
  $where
  GROUP BY s.id, s.name, s.nis
  ORDER BY total_denda DESC
";
$res = $conn->query($sql);

// ============================================================
// 🏫 DATA SEKOLAH
// ============================================================
$stmt = $conn->prepare("SELECT name, logo, address, phone, email FROM schools WHERE id = ? LIMIT 1");
$stmt->bind_param("i", $school_id);
$stmt->execute();
$school = $stmt->get_result()->fetch_assoc() ?? [
  'name' => 'Perpustakaan Sekolah',
  'address' => '',
  'phone' => '',
  'email' => '',
  'logo' => ''
];
$stmt->close();

// ============================================================
// 🖨️ SETUP PDF
// ============================================================
$pdf = new FPDF('P', 'mm', 'A4');
$pdf->AddPage();
$pdf->SetMargins(10, 10, 10);
$pdf->SetAutoPageBreak(true, 15);

// Logo Sekolah
$logoPath = "../assets/img/logo.png";
if (!empty($school['logo']) && file_exists(__DIR__ . "/../" . $school['logo'])) {
  $logoPath = __DIR__ . "/../" . $school['logo'];
}

// ============================================================
// 🏫 HEADER SEKOLAH (KOP SURAT)
// ============================================================
$pdf->SetY(10);
$pdf->Image($logoPath, 12, 10, 22);
$pdf->SetXY(38, 10);

$pdf->SetFont('Arial', 'B', 14);
$pdf->MultiCell(155, 7, iconv('UTF-8', 'ISO-8859-1//TRANSLIT', $school['name']), 0, 'L');

$pdf->SetFont('Arial', '', 9);
$alamat = trim($school['address'] ?? '');
if (!empty($school['phone']) || !empty($school['email'])) {
  $alamat .= "\nTelp: " . ($school['phone'] ?? '-') . " | Email: " . ($school['email'] ?? '-');
}
$pdf->SetX(38);
$pdf->MultiCell(155, 5, iconv('UTF-8', 'ISO-8859-1//TRANSLIT', $alamat), 0, 'L');

$pdf->Ln(3);
$pdf->SetDrawColor(0, 0, 0);
$pdf->Line(10, $pdf->GetY(), 200, $pdf->GetY());
$pdf->Ln(6);

// ============================================================
// 🧾 JUDUL LAPORAN
// ============================================================
$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(190, 8, iconv('UTF-8', 'ISO-8859-1//TRANSLIT', "LAPORAN DENDA PER SISWA"), 0, 1, 'C');
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(190, 6, iconv('UTF-8', 'ISO-8859-1//TRANSLIT',
  "Periode: " . date('d/m/Y', strtotime($date_from)) . " - " . date('d/m/Y', strtotime($date_to))
), 0, 1, 'C');
$pdf->Ln(6);

// ============================================================
// 📋 HEADER TABEL
// ============================================================
$pdf->SetFont('Arial', 'B', 10);
$pdf->SetFillColor(230, 230, 230);
$pdf->Cell(10, 8, 'No', 1, 0, 'C', true);
$pdf->Cell(25, 8, 'NIS', 1, 0, 'C', true);
$pdf->Cell(75, 8, 'Nama Siswa', 1, 0, 'C', true);
$pdf->Cell(30, 8, 'Transaksi', 1, 0, 'C', true);
$pdf->Cell(40, 8, 'Total Denda (Rp)', 1, 1, 'C', true);

// ============================================================
// 📄 DATA BARIS
// ============================================================
$pdf->SetFont('Arial', '', 9);
$no = 1;
$grand = 0;

if ($res->num_rows === 0) {
  $pdf->Cell(190, 10, iconv('UTF-8', 'ISO-8859-1//TRANSLIT', 'Tidak ada data denda untuk periode ini.'), 1, 1, 'C');
} else {
  while ($r = $res->fetch_assoc()) {
    $pdf->Cell(10, 8, $no++, 1, 0, 'C');
    $pdf->Cell(25, 8, iconv('UTF-8', 'ISO-8859-1//TRANSLIT', $r['nis']), 1, 0, 'L');
    $pdf->Cell(75, 8, iconv('UTF-8', 'ISO-8859-1//TRANSLIT', substr($r['student_name'], 0, 35)), 1, 0, 'L');
    $pdf->Cell(30, 8, $r['total_transaksi'], 1, 0, 'C');
    $pdf->Cell(40, 8, number_format($r['total_denda'], 0, ',', '.'), 1, 1, 'R');
    $grand += $r['total_denda'];
  }

  $pdf->SetFont('Arial', 'B', 10);
  $pdf->Cell(140, 8, iconv('UTF-8', 'ISO-8859-1//TRANSLIT', 'TOTAL'), 1, 0, 'R');
  $pdf->Cell(40, 8, number_format($grand, 0, ',', '.'), 1, 1, 'R');
}

// ============================================================
// 🕒 FOOTER
// ============================================================
$pdf->Ln(5);
$pdf->SetFont('Arial', 'I', 8);
$pdf->Cell(0, 8, iconv('UTF-8', 'ISO-8859-1//TRANSLIT', 'Dicetak pada: ' . date('d/m/Y H:i')), 0, 1, 'R');

// ============================================================
// 🧾 OUTPUT PDF
// ============================================================
$fileName = "Laporan_Denda_Siswa_" . date('Ymd_His') . ".pdf";

ob_end_clean(); // 🧹 Bersihkan semua output
header('Content-Type: application/pdf');
header('Content-Disposition: inline; filename="'.$fileName.'"');
$pdf->Output('I', $fileName);
exit;
