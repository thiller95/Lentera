<?php
// ============================================================
// LENTERA LIBRARY SYSTEM – CREATE PEMBAYARAN DENDA (FINAL)
// ============================================================
$pageTitle = "Tambah Pembayaran Denda";

if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . "/../config/session_guard.php";
require_once __DIR__ . "/../config/db_config.php";
require_once __DIR__ . "/../includes/header.php";
require_once __DIR__ . "/../includes/sidebar.php";
require_once __DIR__ . "/../includes/topbar.php";

$conn = db();
$school_id = $_SESSION['school_id'] ?? 0;
$msg = "";

// Ambil daftar siswa + peminjaman aktif
$stmt = $conn->prepare("
  SELECT l.id AS loan_id, l.loan_code, s.id AS student_id, s.name, s.nis
  FROM book_loans l
  JOIN students s ON s.id = l.student_id
  WHERE l.school_id = ? AND (l.status = 'late' OR l.status = 'borrowed')
  ORDER BY s.name ASC
");
$stmt->bind_param("i", $school_id);
$stmt->execute();
$loans = $stmt->get_result();

// Handle submit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $loan_id   = (int)$_POST['loan_id'];
  $student_id = (int)$_POST['student_id'];
  $amount    = (float)$_POST['amount'];
  $method    = $_POST['method'];
  $note      = trim($_POST['note']);

  if ($loan_id <= 0 || $amount <= 0) {
    $msg = "Data tidak lengkap.";
  } else {
    $stmtIn = $conn->prepare("
      INSERT INTO fine_payments (school_id, loan_id, student_id, amount, method, note)
      VALUES (?, ?, ?, ?, ?, ?)
    ");
    $stmtIn->bind_param("iiidss", $school_id, $loan_id, $student_id, $amount, $method, $note);
    if ($stmtIn->execute()) {
      $_SESSION['flash_success'] = "Pembayaran denda berhasil disimpan.";
      header("Location: fines-payments.php");
      exit;
    } else {
      $msg = "Gagal menyimpan data pembayaran.";
    }
  }
}
?>

<main id="mainContent" class="flex-grow-1 p-4">
  <div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-3">
      <h4 class="text-primary mb-0"><i class="bi bi-plus-circle me-2"></i> Tambah Pembayaran Denda</h4>
      <a href="fines-payments.php" class="btn btn-outline-secondary btn-sm"><i class="bi bi-arrow-left"></i> Kembali</a>
    </div>

    <div class="card shadow-sm border-0">
      <div class="card-body">
        <?php if ($msg): ?>
          <div class="alert alert-danger auto-dismiss"><?= htmlspecialchars($msg) ?></div>
        <?php endif; ?>

        <form method="post">
          <div class="row g-3">
            <div class="col-md-6">
              <label class="form-label fw-semibold">Pilih Siswa & Peminjaman</label>
              <select name="loan_id" class="form-select" required>
                <option value="">- Pilih -</option>
                <?php while($l = $loans->fetch_assoc()): ?>
                  <option value="<?= $l['loan_id'] ?>" data-student="<?= $l['student_id'] ?>">
                    <?= htmlspecialchars($l['name']) ?> (<?= htmlspecialchars($l['nis']) ?>) - <?= htmlspecialchars($l['loan_code']) ?>
                  </option>
                <?php endwhile; ?>
              </select>
              <input type="hidden" name="student_id" id="student_id">
            </div>

            <div class="col-md-3">
              <label class="form-label fw-semibold">Nominal (Rp)</label>
              <input type="number" step="0.01" name="amount" class="form-control" required>
            </div>

            <div class="col-md-3">
              <label class="form-label fw-semibold">Metode Pembayaran</label>
              <select name="method" class="form-select">
                <option value="cash">Tunai</option>
                <option value="transfer">Transfer</option>
                <option value="qris">QRIS</option>
              </select>
            </div>

            <div class="col-12">
              <label class="form-label fw-semibold">Catatan</label>
              <textarea name="note" class="form-control" rows="2" placeholder="Opsional"></textarea>
            </div>
          </div>

          <div class="text-end mt-4">
            <button type="submit" class="btn btn-primary px-4">
              <i class="bi bi-save me-1"></i> Simpan Pembayaran
            </button>
          </div>
        </form>
      </div>
    </div>
  </div>
</main>

<?php require_once __DIR__ . "/../includes/footer.php"; ?>

<script>
document.addEventListener("DOMContentLoaded", function() {
  const selectLoan = document.querySelector('select[name="loan_id"]');
  const hiddenStudent = document.getElementById('student_id');
  selectLoan.addEventListener('change', function() {
    const opt = this.selectedOptions[0];
    hiddenStudent.value = opt ? opt.dataset.student : '';
  });
});
</script>
