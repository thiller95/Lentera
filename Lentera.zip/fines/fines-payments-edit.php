<?php
// ============================================================
// LENTERA LIBRARY SYSTEM – PEMBAYARAN DENDA (EDIT / KONFIRMASI BAYAR - FINAL STABLE)
// ============================================================

$pageTitle = "Konfirmasi Pembayaran Denda";

if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . "/../config/session_guard.php";
require_once __DIR__ . "/../config/db_config.php";
require_once __DIR__ . "/../includes/header.php";
require_once __DIR__ . "/../includes/sidebar.php";
require_once __DIR__ . "/../includes/topbar.php";

$conn = db();
$school_id = $_SESSION['school_id'] ?? 0;

// ============================================================
// CEK AKSES
// ============================================================
if (($_SESSION['user_type'] ?? '') !== 'admin') {
    header("Location: ../dashboard.php");
    exit;
}

// ============================================================
// CEK PARAMETER ID
// ============================================================
$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
    die("<div style='margin:40px;color:red;font-weight:bold'>❌ ID tidak valid.</div>");
}

// ============================================================
// AMBIL DATA DENDA
// ============================================================
$stmt = $conn->prepare("
    SELECT 
        fp.*, 
        s.name AS student_name, 
        s.nis,
        l.loan_code
    FROM fine_payments fp
    JOIN students s ON s.id = fp.student_id
    JOIN book_loans l ON l.id = fp.loan_id
    WHERE fp.id = ? AND fp.school_id = ?
    LIMIT 1
");
$stmt->bind_param("ii", $id, $school_id);
$stmt->execute();
$res = $stmt->get_result();
$data = $res->fetch_assoc();

if (!$data) {
    die("<div style='margin:40px;color:red;font-weight:bold'>❌ Data pembayaran denda tidak ditemukan.</div>");
}

// ============================================================
// HANDLE FORM SUBMIT
// ============================================================
$success = $error = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $method = trim($_POST['method'] ?? '');
    $note   = trim($_POST['note'] ?? '');

    if ($method === '') {
        $error = "Metode pembayaran wajib dipilih.";
    } else {
        try {
            $stmtUp = $conn->prepare("
                UPDATE fine_payments
                SET is_paid = 1, method = ?, payment_date = NOW(), note = ?, updated_at = NOW()
                WHERE id = ? AND school_id = ?
            ");
            $stmtUp->bind_param("ssii", $method, $note, $id, $school_id);
            $stmtUp->execute();

            $success = "Pembayaran denda berhasil dikonfirmasi.";
        } catch (Exception $e) {
            $error = "Gagal menyimpan data: " . htmlspecialchars($e->getMessage());
        }
    }
}
?>

<!-- ============================================================ -->
<!-- MAIN CONTENT AREA -->
<!-- ============================================================ -->
<main id="mainContent" class="flex-grow-1 p-4">
  <div class="container-fluid">

    <div class="d-flex justify-content-between align-items-center mb-3">
      <h4 class="text-primary mb-0"><i class="bi bi-cash-coin me-2"></i> Konfirmasi Pembayaran Denda</h4>
      <a href="fines-payments.php" class="btn btn-outline-secondary btn-sm">
        <i class="bi bi-arrow-left"></i> Kembali
      </a>
    </div>

    <div class="card shadow-sm border-0">
      <div class="card-body">

        <?php if ($error): ?>
          <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php elseif ($success): ?>
          <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
        <?php endif; ?>

        <!-- INFO DENDA -->
        <table class="table table-sm mb-4">
          <tr>
            <th width="200">Kode Peminjaman</th>
            <td><?= htmlspecialchars($data['loan_code']) ?></td>
          </tr>
          <tr>
            <th>Nama Siswa</th>
            <td><?= htmlspecialchars($data['student_name']) ?> (<?= htmlspecialchars($data['nis']) ?>)</td>
          </tr>
          <tr>
            <th>Nominal Denda</th>
            <td>Rp <?= number_format($data['amount'], 2, ',', '.') ?></td>
          </tr>
          <tr>
            <th>Status Saat Ini</th>
            <td>
              <?php if ($data['is_paid']): ?>
                <span class="badge bg-success">Sudah Dibayar</span>
              <?php else: ?>
                <span class="badge bg-warning text-dark">Belum Dibayar</span>
              <?php endif; ?>
            </td>
          </tr>
        </table>

        <?php if (!$data['is_paid']): ?>
        <!-- FORM KONFIRMASI PEMBAYARAN -->
        <form method="post" autocomplete="off" class="mt-4">
          <div class="row mb-3">
            <div class="col-md-4">
              <label class="form-label fw-semibold">Metode Pembayaran</label>
              <select name="method" class="form-select" required>
                <option value="">- Pilih Metode -</option>
                <option value="cash" <?= $data['method'] === 'cash' ? 'selected' : '' ?>>Tunai</option>
                <option value="transfer" <?= $data['method'] === 'transfer' ? 'selected' : '' ?>>Transfer Bank</option>
                <option value="qris" <?= $data['method'] === 'qris' ? 'selected' : '' ?>>QRIS</option>
              </select>
            </div>
            <div class="col-md-8">
              <label class="form-label fw-semibold">Catatan Tambahan</label>
              <input type="text" name="note" class="form-control" value="<?= htmlspecialchars($data['note']) ?>" placeholder="Opsional...">
            </div>
          </div>

          <div class="text-end mt-4">
            <button type="submit" class="btn btn-success px-4">
              <i class="bi bi-check-circle me-1"></i> Tandai Sudah Dibayar
            </button>
          </div>
        </form>
        <?php else: ?>
        <div class="alert alert-info mt-3">
          <i class="bi bi-info-circle"></i> Denda ini sudah ditandai sebagai <strong>dibayar</strong>.
        </div>
        <?php endif; ?>

      </div>
    </div>

  </div>
</main>

<?php require_once __DIR__ . "/../includes/footer.php"; ?>

<!-- ============================================================ -->
<!-- SWEETALERT FEEDBACK -->
<!-- ============================================================ -->
<?php if ($success): ?>
<script>
Swal.fire({
  icon: 'success',
  title: 'Berhasil!',
  text: '<?= addslashes($success) ?>',
  confirmButtonColor: '#2563EB'
});
setTimeout(() => window.location.href = 'fines-payments.php', 1800);
</script>
<?php endif; ?>
