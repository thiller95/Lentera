<?php
// ============================================================
// LENTERA LIBRARY SYSTEM – DETAIL PEMBAYARAN DENDA (FINAL STABLE)
// ============================================================

$pageTitle = "Detail Pembayaran Denda";

if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . "/../config/session_guard.php";
require_once __DIR__ . "/../config/db_config.php";
require_once __DIR__ . "/../includes/header.php";
require_once __DIR__ . "/../includes/sidebar.php";
require_once __DIR__ . "/../includes/topbar.php";

$conn = db();
$school_id = $_SESSION['school_id'] ?? 0;
$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) die("Invalid ID");

// ============================================================
// AMBIL DATA PEMBAYARAN DENDA
// ============================================================
$stmt = $conn->prepare("
  SELECT 
    fp.id, fp.loan_id, fp.student_id, fp.payment_date, fp.amount, fp.method, fp.note,
    s.name AS student_name, s.nis,
    l.loan_code, l.loan_date, l.due_date, l.return_date
  FROM fine_payments fp
  JOIN students s ON s.id = fp.student_id
  JOIN book_loans l ON l.id = fp.loan_id
  WHERE fp.school_id = ? AND fp.id = ?
  LIMIT 1
");
$stmt->bind_param("ii", $school_id, $id);
$stmt->execute();
$res = $stmt->get_result();
$header = $res->fetch_assoc();
if (!$header) die("Data tidak ditemukan.");

// ============================================================
// AMBIL DAFTAR BUKU TERKAIT LOAN
// ============================================================
$stmtBooks = $conn->prepare("
  SELECT b.code, b.title, b.author, d.quantity, d.returned
  FROM book_loan_details d
  JOIN books b ON b.id = d.book_id
  WHERE d.loan_id = ?
");
$stmtBooks->bind_param("i", $header['loan_id']);
$stmtBooks->execute();
$resBooks = $stmtBooks->get_result();

// ============================================================
// HELPER FORMAT
// ============================================================
function safeDate($val, $format = "d M Y") {
  return $val ? date($format, strtotime($val)) : "-";
}
?>

<!-- ============================================================ -->
<!-- MAIN CONTENT -->
<!-- ============================================================ -->
<main id="mainContent" class="flex-grow-1 p-4">
  <div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-3">
      <h4 class="text-primary mb-0"><i class="bi bi-cash-coin me-2"></i> Detail Pembayaran Denda</h4>
      <a href="fines-payments.php" class="btn btn-outline-secondary btn-sm">
        <i class="bi bi-arrow-left"></i> Kembali
      </a>
    </div>

    <div class="card shadow-sm border-0">
      <div class="card-body">
        <!-- Informasi Utama -->
        <div class="row mb-4">
          <div class="col-md-6">
            <p><strong>Nama Siswa:</strong><br><?= htmlspecialchars($header['student_name']) ?> (<?= htmlspecialchars($header['nis']) ?>)</p>
            <p><strong>Kode Peminjaman:</strong><br><?= htmlspecialchars($header['loan_code']) ?></p>
            <p><strong>Tanggal Peminjaman:</strong><br><?= safeDate($header['loan_date']) ?></p>
            <p><strong>Jatuh Tempo:</strong><br><?= safeDate($header['due_date']) ?></p>
          </div>
          <div class="col-md-6">
            <p><strong>Tanggal Pengembalian:</strong><br><?= safeDate($header['return_date']) ?></p>
            <p><strong>Tanggal Pembayaran:</strong><br><?= safeDate($header['payment_date'], "d M Y H:i") ?></p>
            <p><strong>Nominal Denda:</strong><br><span class="fw-bold text-danger">Rp <?= number_format($header['amount'], 2, ',', '.') ?></span></p>
            <p><strong>Metode Pembayaran:</strong><br><?= strtoupper($header['method']) ?></p>
          </div>
        </div>

        <div class="mb-4">
          <strong>Catatan:</strong><br><?= nl2br(htmlspecialchars($header['note'] ?: '-')) ?>
        </div>

        <!-- Buku Terkait -->
        <h5 class="mb-3 text-primary"><i class="bi bi-book me-2"></i> Buku yang Dipinjam</h5>
        <div class="table-responsive mb-4">
          <table class="table table-bordered table-hover align-middle">
            <thead class="table-light">
              <tr>
                <th width="5%">#</th>
                <th>Kode Buku</th>
                <th>Judul Buku</th>
                <th>Pengarang</th>
                <th width="10%">Qty</th>
                <th width="15%">Status</th>
              </tr>
            </thead>
            <tbody>
              <?php $no=1; while($b = $resBooks->fetch_assoc()): ?>
              <tr>
                <td><?= $no++ ?></td>
                <td><?= htmlspecialchars($b['code']) ?></td>
                <td><?= htmlspecialchars($b['title']) ?></td>
                <td><?= htmlspecialchars($b['author']) ?></td>
                <td class="text-center"><?= (int)$b['quantity'] ?></td>
                <td class="text-center">
                  <?= $b['returned'] 
                      ? '<span class="badge bg-success">Dikembalikan</span>' 
                      : '<span class="badge bg-warning text-dark">Belum</span>' ?>
                </td>
              </tr>
              <?php endwhile; ?>
            </tbody>
          </table>
        </div>

        <div class="text-end">
          <a href="fines-payments-print.php?id=<?= $id ?>" target="_blank" class="btn btn-outline-success">
            <i class="bi bi-printer"></i> Cetak Bukti Pembayaran
          </a>
        </div>
      </div>
    </div>
  </div>
</main>

<?php require_once __DIR__ . "/../includes/footer.php"; ?>
