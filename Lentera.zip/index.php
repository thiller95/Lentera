<?php
// ============================================================
// LIBRARY SYSTEM - INDEX (Main Entry Point)
// ============================================================
// Cek session dan arahkan user ke halaman sesuai status login
// ============================================================

if (session_status() === PHP_SESSION_NONE) { session_start(); }

// Jika sudah login, langsung ke dashboard
if (!empty($_SESSION['auth']) && !empty($_SESSION['user_type'])) {
    header("Location: dashboard.php");
    exit;
}

// Jika belum login, arahkan ke login page
header("Location: login.php");
exit;
