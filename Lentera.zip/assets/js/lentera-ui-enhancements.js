/* ============================================================
   Lentera UI Enhancements – Smooth Animated & Responsive Layout
   ============================================================ */
(function () {
  const body = document.body;
  const KEY = "lentera.sidebar.collapsed";
  const toggler = document.querySelector('[data-toggle="sidebar-collapse"], .button-menu-mobile');

  // ==========================================================
  // 🧭 Sidebar collapse toggle persistence + animation
  // ==========================================================
  function applyState(collapsed) {
    body.classList.toggle("sidebar-collapsed", collapsed);
    body.classList.toggle("sidebar-enable", !collapsed);

    // Tambahkan animasi CSS
    const sidebar = document.getElementById("sidebar");
    if (sidebar) {
      sidebar.classList.add("sidebar-animating");
      sidebar.style.transition = "width .3s ease, opacity .3s ease";
      sidebar.style.opacity = collapsed ? "0.95" : "1";
      setTimeout(() => sidebar.classList.remove("sidebar-animating"), 350);
    }

    // Sesuaikan margin konten
    adjustMainMargin();

    // Trigger reflow DataTables & chart
    setTimeout(() => {
      if (window.jQuery && jQuery.fn && jQuery.fn.dataTable) {
        jQuery.fn.dataTable
          .tables({ visible: true, api: true })
          .columns.adjust()
          .responsive.recalc();
      }
      window.dispatchEvent(new Event("resize"));
    }, 400);
  }

  const saved = localStorage.getItem(KEY);
  if (saved !== null) applyState(saved === "1");

  if (toggler) {
    toggler.addEventListener("click", (e) => {
      e.preventDefault();
      const collapsed = !body.classList.contains("sidebar-collapsed");
      localStorage.setItem(KEY, collapsed ? "1" : "0");
      applyState(collapsed);
    });
  }

  // ==========================================================
  // 🔄 Auto-adjust margin main content
  // ==========================================================
  function adjustMainMargin() {
    const main = document.getElementById("mainContent");
    if (!main) return;

    const collapsed = localStorage.getItem(KEY) === "1";
    const size = localStorage.getItem("sidebar-size") || "lg";
    const isMobile = window.innerWidth < 992;

    let marginLeft = "250px";
    if (isMobile) marginLeft = "0";
    else if (collapsed || size === "sm") marginLeft = "70px";

    main.style.marginLeft = marginLeft;
  }

  document.addEventListener("DOMContentLoaded", adjustMainMargin);
  window.addEventListener("resize", adjustMainMargin);
  window.addEventListener("storage", (e) => {
    if (e.key === KEY || e.key === "sidebar-size") adjustMainMargin();
  });

  // ==========================================================
  // 📊 DataTables defaults – responsive + auto-init
  // ==========================================================
  if (window.jQuery && jQuery.fn && jQuery.fn.dataTable) {
    jQuery.extend(true, jQuery.fn.dataTable.defaults, {
      responsive: true,
      autoWidth: false,
      scrollX: true,
      pageLength: 25,
      lengthMenu: [[10, 25, 50, 100, -1], [10, 25, 50, 100, "All"]],
      language: { url: undefined }
    });
    jQuery(() => {
      jQuery("table.datatable-auto").each(function () {
        if (!jQuery(this).hasClass("dataTable")) jQuery(this).DataTable();
      });
      document.addEventListener("shown.bs.tab", () => {
        jQuery.fn.dataTable.tables({ visible: true, api: true })
          .columns.adjust().responsive.recalc();
      });
      document.addEventListener("shown.bs.collapse", () => {
        jQuery.fn.dataTable.tables({ visible: true, api: true })
          .columns.adjust().responsive.recalc();
      });
    });
  }

  // ==========================================================
  // 🧩 Fix content min-height (header/footer)
  // ==========================================================
  function resizeMain() {
    const header = document.querySelector(".navbar-custom") || document.querySelector("header");
    const footer = document.querySelector("footer");
    const h = (header?.offsetHeight || 0) + (footer?.offsetHeight || 0);
    const main = document.getElementById("mainContent") || document.querySelector("main");
    if (main) main.style.minHeight = `calc(100vh - ${h}px)`;
  }
  window.addEventListener("resize", resizeMain);
  document.addEventListener("DOMContentLoaded", resizeMain);

  // ==========================================================
  // 🌙 Tambahan animasi overlay mobile (fade-in/out)
  // ==========================================================
  const overlay = document.createElement("div");
  overlay.id = "sidebarOverlay";
  overlay.style.cssText =
    "position:fixed;inset:0;z-index:1039;background:rgba(0,0,0,.4);opacity:0;visibility:hidden;transition:opacity .3s ease;";
  document.body.appendChild(overlay);

  function showOverlay(show) {
    overlay.style.opacity = show ? "1" : "0";
    overlay.style.visibility = show ? "visible" : "hidden";
  }

  toggler?.addEventListener("click", () => {
    const isMobile = window.innerWidth < 992;
    if (isMobile) showOverlay(true);
  });
  overlay.addEventListener("click", () => {
    const isMobile = window.innerWidth < 992;
    if (isMobile) {
      body.classList.add("sidebar-collapsed");
      localStorage.setItem(KEY, "1");
      showOverlay(false);
      adjustMainMargin();
    }
  });

  // ==========================================================
  // 🌙 Smooth Dark Mode Toggle with Animation
  // ==========================================================
  (function () {
    const body = document.body;

    // Jalankan saat load
    document.addEventListener("DOMContentLoaded", () => {
      const dark = localStorage.getItem("darkMode") === "1";
      body.classList.toggle("dark-mode", dark);
    });

    // Dengarkan perubahan localStorage antar tab
    window.addEventListener("storage", (e) => {
      if (e.key === "darkMode") {
        const dark = e.newValue === "1";
        toggleDarkSmooth(dark);
      }
    });

    // Fungsi untuk transisi halus
    function toggleDarkSmooth(enable) {
      body.classList.add("dark-mode-fade");
      body.classList.toggle("dark-mode", enable);
      setTimeout(() => body.classList.remove("dark-mode-fade"), 350);
    }

    // Event global manual toggle (jika kamu tambahkan tombol)
    window.toggleDarkMode = function () {
      const current = body.classList.contains("dark-mode");
      const next = !current;
      localStorage.setItem("darkMode", next ? "1" : "0");
      toggleDarkSmooth(next);
    };
  })();


})();
