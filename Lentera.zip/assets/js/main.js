// ============================================================
// LENTERA LIBRARY SYSTEM - MAIN.JS (Final + Global Select2 Init)
// ============================================================
// SweetAlert helpers, Toast, Auto-dismiss alert, dan Select2 Auto Init
// ============================================================

$(function () {
    // ==========================================================
    // 💬 SWEETALERT & TOAST HELPERS
    // ==========================================================
    window.alertSuccess = function (message, title = "Berhasil") {
        Swal.fire({
            icon: "success",
            title,
            text: message,
            timer: 2000,
            showConfirmButton: false
        });
    };

    window.alertError = function (message, title = "Gagal") {
        Swal.fire({
            icon: "error",
            title,
            text: message,
            confirmButtonText: "OK"
        });
    };

    window.alertInfo = function (message, title = "Informasi") {
        Swal.fire({
            icon: "info",
            title,
            text: message
        });
    };

    // ⚠️ Confirm (callback-based) – FIXED: HTML rendering enabled
    window.confirmAction = function (message, callback, title = "Konfirmasi") {
        Swal.fire({
            title: title,
            icon: "warning",
            showCancelButton: true,
            confirmButtonColor: "#2563EB",
            cancelButtonColor: "#6B7280",
            confirmButtonText: "Ya, Lanjutkan",
            cancelButtonText: "Batal",
            // ✅ pakai HTML agar <strong>, <br>, dll dirender dengan benar
            html: `<div style="font-size:15px;">${message}</div>`
        }).then((r) => {
            if (r.isConfirmed && typeof callback === "function") callback();
        });
    };

    // 🔔 Toast Notification
    window.toast = function (message, type = "success") {
        const Toast = Swal.mixin({
            toast: true,
            position: "top-end",
            showConfirmButton: false,
            timer: 2500,
            timerProgressBar: true
        });
        Toast.fire({ icon: type, title: message });
    };

    // ==========================================================
    // ⏳ AUTO HIDE ALERTS / TOAST MESSAGES
    // ==========================================================
    $(".auto-dismiss").delay(3000).fadeOut(300);

    // ==========================================================
    // 🔍 GLOBAL SELECT2 INITIALIZER
    // ==========================================================
    if (typeof $.fn.select2 !== "undefined") {
        $("[data-select2='true']").each(function () {
            const $el = $(this);

            // Gunakan konfigurasi default, tapi bisa override via data-attr
            const ajaxUrl = $el.data("ajax-url") || null;
            const placeholder = $el.attr("placeholder") || "- Pilih Data -";

            const config = {
                placeholder: placeholder,
                allowClear: true,
                width: "100%",
                minimumInputLength: 2,
                language: {
                    inputTooShort: () => "Ketik minimal 2 huruf...",
                    noResults: () => "Tidak ditemukan data",
                    searching: () => "Mencari..."
                }
            };

            // Jika ada AJAX URL, aktifkan mode AJAX
            if (ajaxUrl) {
                config.ajax = {
                    url: ajaxUrl,
                    dataType: "json",
                    delay: 300,
                    data: (params) => ({ q: params.term }),
                    processResults: (data) => ({
                        results: data.map((item) => ({
                            id: item.id,
                            text: item.label || item.text
                        }))
                    })
                };
            }

            $el.select2(config);
        });
    }

});
