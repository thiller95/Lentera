// ============================================================
// LENTERA LIBRARY SYSTEM
// Global DataTables Auto-Resize Helper (v1.1 Stable)
// ============================================================
// Fungsi:
// ✅ Menyesuaikan DataTables otomatis saat sidebar collapse/expand
// ✅ Menangani resize jendela & animasi layout
// ✅ Tidak perlu lagi pakai setTimeout manual di setiap halaman
// ============================================================

(function () {
    "use strict";

    /**
     * Menyesuaikan semua DataTables aktif di halaman
     */
    function adjustAllTables() {
        if (window.jQuery && $.fn.dataTable) {
            $.fn.dataTable.tables({ visible: true, api: true })
                .columns.adjust()
                .responsive.recalc();
            // console.log("📏 DataTables auto-resized");
        }
    }

    /**
     * Menyesuaikan margin utama berdasarkan ukuran sidebar
     */
    function adjustMainMargin() {
        const size = localStorage.getItem('sidebar-size') || 'lg';
        const main = document.getElementById('mainContent');
        if (main) main.style.marginLeft = (size === 'sm' ? '70px' : '250px');
    }

    /**
     * Mengamati perubahan ukuran container utama (ResizeObserver)
     */
    function observeMainResize() {
        const main = document.getElementById('mainContent');
        if (!main || typeof ResizeObserver === "undefined") return;

        const observer = new ResizeObserver(() => {
            adjustAllTables();
        });
        observer.observe(main);
    }

    /**
     * Inisialisasi listener
     */
    function init() {
        // Pastikan DataTables siap
        if (!(window.jQuery && $.fn.dataTable)) {
            console.warn("⚠️ DataTables belum ter-load saat datatables-auto-resize.js dijalankan");
            return;
        }

        // Saat event custom dari layout.js
        window.addEventListener('sidebar:changed', () => {
            adjustMainMargin();
            setTimeout(() => adjustAllTables(), 350);
        });

        // Saat perubahan localStorage (tab lain)
        window.addEventListener('storage', e => {
            if (e.key === 'sidebar-size') {
                adjustMainMargin();
                setTimeout(() => adjustAllTables(), 350);
            }
        });

        // Saat browser di-resize
        window.addEventListener('resize', () => {
            adjustAllTables();
        });

        // Resize observer untuk container
        observeMainResize();

        // Jalankan awal
        adjustMainMargin();

        console.log("✅ DataTables Auto-Resize aktif (Lentera Library)");
    }

    // Jalankan setelah halaman siap
    document.addEventListener('DOMContentLoaded', init);

})();
