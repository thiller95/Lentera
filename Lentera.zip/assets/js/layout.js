// ============================================================
// Lentera Library System – layout.js (Final Clean Responsive)
// ============================================================
//
// ✅ Fitur Utama:
// 1. Toggle sidebar via #vertical-menu-btn (Minia compatible)
// 2. Simpan status di localStorage ('sidebar-size': 'lg' | 'sm')
// 3. Update <body data-sidebar-size="...">
// 4. Auto-adjust margin #mainContent + padding #topbar
// 5. Event broadcast "sidebar:changed" untuk DataTables & Chart.js
// ============================================================

(function () {
    const BODY = document.body;
    const STORAGE_KEY = "sidebar-size";
    const DEFAULT_SIZE = "lg"; // expanded by default

    // ============================================================
    // 📦 Apply saved state from localStorage
    // ============================================================
    function applySavedState() {
        const saved = localStorage.getItem(STORAGE_KEY) || DEFAULT_SIZE;
        BODY.setAttribute("data-sidebar-size", saved);
        adjustLayout(saved);
    }

    // ============================================================
    // 🧭 Toggle sidebar size
    // ============================================================
    function toggleSidebar() {
        const current = BODY.getAttribute("data-sidebar-size") || DEFAULT_SIZE;
        const next = current === "lg" ? "sm" : "lg";
        BODY.setAttribute("data-sidebar-size", next);
        localStorage.setItem(STORAGE_KEY, next);

        adjustLayout(next);

        // Event trigger agar komponen lain ikut reflow
        window.dispatchEvent(new CustomEvent("sidebar:changed", { detail: next }));

        // Reflow DataTables & Chart.js – with safe checks
        if (window.jQuery && $.fn.dataTable) {
            setTimeout(() => {
                const tables = $.fn.dataTable.tables({ visible: true, api: true });
                if (tables && tables.length) {
                    try {
                        tables.columns.adjust();
                        if (tables.responsive && typeof tables.responsive.recalc === "function") {
                            tables.responsive.recalc();
                        }
                    } catch (e) {
                        console.warn("DataTables reflow skipped:", e.message);
                    }
                }
            }, 350);
        }

        if (window.loanChart && typeof window.loanChart.resize === "function") {
            setTimeout(() => window.loanChart.resize(), 400);
        }

    }

    // ============================================================
    // 🧩 Adjust mainContent margin & topbar padding
    // ============================================================
    function adjustLayout(size) {
        const main = document.getElementById("mainContent");
        const topbar = document.getElementById("topbar");
        const isMobile = window.innerWidth < 992;

        // width berdasarkan data-sidebar-size
        const sidebarWidth = size === "sm" ? 70 : 250;

        // margin-left konten
        if (main) main.style.marginLeft = isMobile ? "0px" : `${sidebarWidth}px`;

        // padding-left topbar
        if (topbar) topbar.style.paddingLeft = isMobile ? "0px" : `${sidebarWidth}px`;
    }

    // ============================================================
    // 📱 Mobile overlay handling
    // ============================================================
    function handleOutsideClick(e) {
        if (!BODY.classList.contains("sidebar-enable")) return;
        const sidebar = document.getElementById("sidebar");
        const btn = document.getElementById("vertical-menu-btn");
        if (!sidebar) return;
        if (sidebar.contains(e.target) || (btn && btn.contains(e.target))) return;
        BODY.classList.remove("sidebar-enable");
    }

    // ============================================================
    // ⚙️ Init on DOM Ready
    // ============================================================
    document.addEventListener("DOMContentLoaded", () => {
        applySavedState();

        // tombol toggle
        const btn = document.getElementById("vertical-menu-btn");
        if (btn) btn.addEventListener("click", (e) => {
            e.preventDefault();
            toggleSidebar();
        });

        // klik luar sidebar di mobile
        document.addEventListener("click", handleOutsideClick);

        // kalau berubah dari tab lain
        window.addEventListener("storage", (e) => {
            if (e.key === STORAGE_KEY) applySavedState();
        });

        // responsif resize
        window.addEventListener("resize", () => {
            const size = BODY.getAttribute("data-sidebar-size") || DEFAULT_SIZE;
            adjustLayout(size);
        });

        console.log("✅ layout.js – Final Clean Responsive loaded");
    });
})();
