<?php
// ============================================================
// LENTERA LIBRARY SYSTEM – DOWNLOAD TEMPLATE / DATA BUKU (2 SHEET - FIX STRUCTURE)
// ============================================================

if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . "/../config/db_config.php";
require_once __DIR__ . "/../assets/vendor/autoload.php";

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Fill;

$conn = db();
$school_id = $_SESSION['school_id'] ?? 0;

// ============================================================
// SHEET 1: DATA BUKU
// ============================================================
$spreadsheet = new Spreadsheet();
$sheetBooks = $spreadsheet->getActiveSheet();
$sheetBooks->setTitle("Data Buku");

// Header kolom
$headers = ["Judul Buku", "Penulis", "Penerbit", "Kategori", "Lokasi (Rak)", "Stok Total"];
$sheetBooks->fromArray($headers, null, 'A1');

// Gaya header
$headerStyle = [
    'font' => ['bold' => true, 'color' => ['rgb' => 'FFFFFF']],
    'fill' => ['fillType' => Fill::FILL_SOLID, 'startColor' => ['rgb' => '4A90E2']],
    'alignment' => ['horizontal' => Alignment::HORIZONTAL_CENTER]
];
$sheetBooks->getStyle('A1:F1')->applyFromArray($headerStyle);

// Ambil data buku
$sqlBooks = "
  SELECT b.title, b.author, b.publisher, c.name AS category_name, l.name AS location_name, b.stock_total
  FROM books b
  LEFT JOIN categories c ON c.id = b.category_id
  LEFT JOIN book_locations l ON l.id = b.location_id
  WHERE b.school_id = ?
  ORDER BY b.title ASC
";
$stmtB = $conn->prepare($sqlBooks);
$stmtB->bind_param("i", $school_id);
$stmtB->execute();
$resB = $stmtB->get_result();

$row = 2;
if ($resB && $resB->num_rows > 0) {
    while ($r = $resB->fetch_assoc()) {
        $sheetBooks->fromArray([
            $r['title'],
            $r['author'],
            $r['publisher'],
            $r['category_name'],
            $r['location_name'],
            $r['stock_total']
        ], null, "A{$row}");
        $row++;
    }
} else {
    $sheetBooks->fromArray(["Contoh Buku", "Penulis A", "Penerbit B", "Fiksi", "Rak A1", "10"], null, "A2");
}

// Lebar kolom otomatis
foreach (range('A', 'F') as $col) {
    $sheetBooks->getColumnDimension($col)->setAutoSize(true);
}

// ============================================================
// SHEET 2: RAK BUKU
// ============================================================
$sheetRacks = $spreadsheet->createSheet();
$sheetRacks->setTitle("Rak Buku");
$sheetRacks->fromArray(["Kode Rak", "Nama Rak", "Ruangan", "Catatan"], null, 'A1');
$sheetRacks->getStyle('A1:D1')->applyFromArray($headerStyle);

// Ambil data lokasi
$sqlL = "SELECT code, name, room, notes FROM book_locations WHERE school_id=? ORDER BY name ASC";
$stmtL = $conn->prepare($sqlL);
$stmtL->bind_param("i", $school_id);
$stmtL->execute();
$resL = $stmtL->get_result();

$row = 2;
if ($resL && $resL->num_rows > 0) {
    while ($r = $resL->fetch_assoc()) {
        $sheetRacks->fromArray([$r['code'], $r['name'], $r['room'], $r['notes']], null, "A{$row}");
        $row++;
    }
} else {
    $sheetRacks->fromArray(["RAK001", "Rak A1", "Ruang Baca", "Rak utama di depan"], null, "A2");
    $sheetRacks->fromArray(["RAK002", "Rak B1", "Ruang Fiksi", "Novel & Komik"], null, "A3");
}

foreach (range('A', 'D') as $col) {
    $sheetRacks->getColumnDimension($col)->setAutoSize(true);
}

// ============================================================
// DOWNLOAD FILE
// ============================================================
$filename = "Template_Buku_dan_Rak_" . date("Ymd_His") . ".xlsx";
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header("Content-Disposition: attachment; filename=\"{$filename}\"");
header('Cache-Control: max-age=0');

$writer = new Xlsx($spreadsheet);
$writer->save('php://output');
exit;
