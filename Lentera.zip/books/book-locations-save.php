<?php
// ============================================================
// LENTERA LIBRARY SYSTEM – SAVE / UPDATE BOOK LOCATIONS (AUTO CODE)
// ============================================================

error_reporting(0);
ini_set('display_errors', 0);
header('Content-Type: application/json; charset=utf-8');

if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . "/../config/session_guard.php";
require_once __DIR__ . "/../config/db_config.php";
require_once __DIR__ . "/../config/doc_numbering_helper.php";

$conn = db();
$school_id = $_SESSION['school_id'] ?? 0;

// ============================================================
// INPUT VALIDATION
// ============================================================
$id    = (int)($_POST['id'] ?? 0);
$name  = trim($_POST['name'] ?? '');
$room  = trim($_POST['room'] ?? '');
$notes = trim($_POST['notes'] ?? '');

if ($name === '') {
  echo json_encode(["status" => "error", "message" => "Nama lokasi / rak wajib diisi."]);
  exit;
}

try {
  // ============================================================
  // TAMBAH BARU
  // ============================================================
  if ($id === 0) {
    $code = generate_doc_number($conn, $school_id, "RAK");

    $stmt = $conn->prepare("
      INSERT INTO book_locations (school_id, code, name, room, notes)
      VALUES (?, ?, ?, ?, ?)
    ");
    $stmt->bind_param("issss", $school_id, $code, $name, $room, $notes);
    $ok = $stmt->execute();

    if ($ok) {
      echo json_encode([
        "status" => "success",
        "message" => "Lokasi baru berhasil ditambahkan dengan kode: {$code}."
      ]);
    } else {
      echo json_encode(["status" => "error", "message" => "Gagal menambah lokasi."]);
    }
    exit;
  }

  // ============================================================
  // UPDATE DATA
  // ============================================================
  else {
    $stmt = $conn->prepare("
      UPDATE book_locations 
      SET name = ?, room = ?, notes = ? 
      WHERE id = ? AND school_id = ?
    ");
    $stmt->bind_param("sssii", $name, $room, $notes, $id, $school_id);
    $ok = $stmt->execute();

    echo json_encode([
      "status"  => $ok ? "success" : "error",
      "message" => $ok ? "Lokasi berhasil diperbarui." : "Gagal memperbarui lokasi."
    ]);
    exit;
  }

} catch (Exception $e) {
  echo json_encode([
    "status" => "error",
    "message" => "Terjadi kesalahan: " . $e->getMessage()
  ]);
  exit;
}
?>
