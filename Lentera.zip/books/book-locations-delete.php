<?php
// ============================================================
// LENTERA LIBRARY SYSTEM – DELETE BOOK LOCATION (FINAL SECURE)
// ============================================================
// Fitur:
// ✅ Validasi ID & hak akses sekolah
// ✅ Cek relasi ke tabel books (tidak bisa hapus jika masih dipakai)
// ✅ Prepared statement untuk keamanan
// ✅ Output JSON bersih & aman
// ============================================================

error_reporting(0);
ini_set('display_errors', 0);
header('Content-Type: application/json; charset=utf-8');

if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . "/../config/session_guard.php";
require_once __DIR__ . "/../config/db_config.php";

$conn = db();
$school_id = $_SESSION['school_id'] ?? 0;

// ============================================================
// INPUT VALIDATION
// ============================================================
$id = (int)($_POST['id'] ?? 0);
if ($id <= 0) {
    echo json_encode(["status" => "error", "message" => "ID lokasi tidak valid."]);
    exit;
}

try {
    // ============================================================
    // 1️⃣ CEK APAKAH MASIH DIGUNAKAN OLEH BUKU
    // ============================================================
    $stmtCheck = $conn->prepare("
        SELECT COUNT(*) AS cnt 
        FROM books 
        WHERE location_id = ? AND school_id = ?
    ");
    $stmtCheck->bind_param("ii", $id, $school_id);
    $stmtCheck->execute();
    $res = $stmtCheck->get_result();
    $row = $res->fetch_assoc();
    $stmtCheck->close();

    if (($row['cnt'] ?? 0) > 0) {
        echo json_encode([
            "status" => "error",
            "message" => "Lokasi tidak bisa dihapus karena masih digunakan oleh beberapa buku."
        ]);
        exit;
    }

    // ============================================================
    // 2️⃣ PROSES HAPUS
    // ============================================================
    $stmtDel = $conn->prepare("
        DELETE FROM book_locations 
        WHERE id = ? AND school_id = ?
        LIMIT 1
    ");
    $stmtDel->bind_param("ii", $id, $school_id);
    $ok = $stmtDel->execute();
    $stmtDel->close();

    // ============================================================
    // 3️⃣ OUTPUT JSON
    // ============================================================
    if ($ok && $conn->affected_rows > 0) {
        echo json_encode([
            "status" => "success",
            "message" => "Lokasi berhasil dihapus."
        ]);
    } else {
        echo json_encode([
            "status" => "error",
            "message" => "Gagal menghapus lokasi atau data tidak ditemukan."
        ]);
    }
    exit;

} catch (Exception $e) {
    echo json_encode([
        "status" => "error",
        "message" => "Terjadi kesalahan: " . $e->getMessage()
    ]);
    exit;
}
?>
