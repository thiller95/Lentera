<?php
// ============================================================
// LENTERA LIBRARY SYSTEM – UPLOAD DATA BUKU & RAK (EXCEL 2 SHEET - FINAL STABLE)
// ============================================================

error_reporting(0);
ini_set('display_errors', 0);
header('Content-Type: application/json; charset=utf-8');

if (session_status() === PHP_SESSION_NONE) session_start();

require_once __DIR__ . "/../config/db_config.php";
require_once __DIR__ . "/../assets/vendor/autoload.php";
require_once __DIR__ . "/../config/doc_numbering_helper.php";

use PhpOffice\PhpSpreadsheet\IOFactory;

$conn = db();
$school_id = $_SESSION['school_id'] ?? 0;

// ============================================================
// Validasi file
// ============================================================
if (!isset($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
    echo json_encode(["status" => "error", "message" => "File tidak valid atau gagal diunggah."]);
    exit;
}

$fileTmp = $_FILES['file']['tmp_name'];

// ============================================================
// Baca file Excel
// ============================================================
try {
    $spreadsheet = IOFactory::load($fileTmp);
} catch (Exception $e) {
    echo json_encode(["status" => "error", "message" => "Gagal membaca file Excel: " . $e->getMessage()]);
    exit;
}

// Pastikan sheet sesuai template
if (!$spreadsheet->getSheetByName("Data Buku")) {
    echo json_encode(["status" => "error", "message" => "Sheet 'Data Buku' tidak ditemukan. Pastikan nama sheet sesuai template."]);
    exit;
}
if (!$spreadsheet->getSheetByName("Rak Buku")) {
    echo json_encode(["status" => "error", "message" => "Sheet 'Rak Buku' tidak ditemukan."]);
    exit;
}

$insertedBooks = 0;
$updatedBooks = 0;
$insertedRacks = 0;
$updatedRacks = 0;

// ============================================================
// SHEET 1: DATA BUKU
// ============================================================
$sheetBooks = $spreadsheet->getSheetByName("Data Buku");
$rows = $sheetBooks->toArray(null, true, true, true);
foreach ($rows as $i => $r) {
    if ($i == 1) continue; // lewati header

    $title = trim($r['A'] ?? '');
    $author = trim($r['B'] ?? '');
    $publisher = trim($r['C'] ?? '');
    $category_name = trim($r['D'] ?? '');
    $location_name = trim($r['E'] ?? '');
    $stock_total = (int)($r['F'] ?? 0);

    if ($title === '') continue;

    // ---- CARI / BUAT KATEGORI ----
    $category_id = null;
    if ($category_name !== '') {
        $stmtC = $conn->prepare("SELECT id FROM categories WHERE name=? AND school_id=? LIMIT 1");
        $stmtC->bind_param("si", $category_name, $school_id);
        $stmtC->execute();
        $resC = $stmtC->get_result();
        if ($rowC = $resC->fetch_assoc()) {
            $category_id = $rowC['id'];
        } else {
            $stmtInsC = $conn->prepare("INSERT INTO categories (school_id, name) VALUES (?, ?)");
            $stmtInsC->bind_param("is", $school_id, $category_name);
            $stmtInsC->execute();
            $category_id = $stmtInsC->insert_id;
        }
    }

    // ---- CARI / BUAT LOKASI ----
    $location_id = null;
    if ($location_name !== '') {
        $stmtL = $conn->prepare("SELECT id FROM book_locations WHERE name=? AND school_id=? LIMIT 1");
        $stmtL->bind_param("si", $location_name, $school_id);
        $stmtL->execute();
        $resL = $stmtL->get_result();
        if ($rowL = $resL->fetch_assoc()) {
            $location_id = $rowL['id'];
        } else {
            $code = generate_doc_number($conn, $school_id, "RAK");
            $stmtInsL = $conn->prepare("INSERT INTO book_locations (school_id, code, name) VALUES (?, ?, ?)");
            $stmtInsL->bind_param("iss", $school_id, $code, $location_name);
            $stmtInsL->execute();
            $location_id = $stmtInsL->insert_id;
        }
    }

    // ---- CARI / UPDATE / INSERT BUKU ----
    $stmtCheck = $conn->prepare("SELECT id FROM books WHERE school_id=? AND title=? LIMIT 1");
    $stmtCheck->bind_param("is", $school_id, $title);
    $stmtCheck->execute();
    $resCheck = $stmtCheck->get_result();

    if ($resCheck && $resCheck->num_rows > 0) {
        $rowB = $resCheck->fetch_assoc();
        $stmtUp = $conn->prepare("
            UPDATE books 
            SET author=?, publisher=?, category_id=?, location_id=?, stock_total=?, stock_available=? 
            WHERE id=? AND school_id=?
        ");
        $stmtUp->bind_param("ssiiisii", $author, $publisher, $category_id, $location_id, $stock_total, $stock_total, $rowB['id'], $school_id);
        $stmtUp->execute();
        $updatedBooks++;
    } else {
        $code = generate_doc_number($conn, $school_id, "BOOK");
        $stmtIns = $conn->prepare("
            INSERT INTO books 
            (school_id, code, title, author, publisher, category_id, location_id, stock_total, stock_available)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        $stmtIns->bind_param("issssiiii", $school_id, $code, $title, $author, $publisher, $category_id, $location_id, $stock_total, $stock_total);
        $stmtIns->execute();
        $insertedBooks++;
    }
}

// ============================================================
// SHEET 2: RAK BUKU
// ============================================================
$sheetRacks = $spreadsheet->getSheetByName("Rak Buku");
$rows = $sheetRacks->toArray(null, true, true, true);
foreach ($rows as $i => $r) {
    if ($i == 1) continue; // header
    $code = trim($r['A'] ?? '');
    $name = trim($r['B'] ?? '');
    $room = trim($r['C'] ?? '');
    $notes = trim($r['D'] ?? '');

    if ($name === '') continue;

    $stmtCheck = $conn->prepare("SELECT id FROM book_locations WHERE school_id=? AND name=? LIMIT 1");
    $stmtCheck->bind_param("is", $school_id, $name);
    $stmtCheck->execute();
    $resCheck = $stmtCheck->get_result();

    if ($resCheck && $resCheck->num_rows > 0) {
        $rowL = $resCheck->fetch_assoc();
        $stmtUp = $conn->prepare("UPDATE book_locations SET room=?, notes=? WHERE id=? AND school_id=?");
        $stmtUp->bind_param("ssii", $room, $notes, $rowL['id'], $school_id);
        $stmtUp->execute();
        $updatedRacks++;
    } else {
        $rakCode = $code ?: generate_doc_number($conn, $school_id, "RAK");
        $stmtIns = $conn->prepare("
            INSERT INTO book_locations (school_id, code, name, room, notes)
            VALUES (?, ?, ?, ?, ?)
        ");
        $stmtIns->bind_param("issss", $school_id, $rakCode, $name, $room, $notes);
        $stmtIns->execute();
        $insertedRacks++;
    }
}

// ============================================================
// HASIL & OUTPUT JSON MURNI
// ============================================================
$message = "Upload selesai: {$insertedBooks} buku baru, {$updatedBooks} diperbarui, {$insertedRacks} rak baru, {$updatedRacks} rak diperbarui.";
echo json_encode(["status" => "success", "message" => $message]);
exit;
