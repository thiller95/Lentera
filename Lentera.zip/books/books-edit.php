<?php
// ============================================================
// LENTERA LIBRARY SYSTEM – BOOKS (EDIT EXISTING - FINAL FIX + BUFFERING)
// ============================================================
$pageTitle = "Edit Buku";

if (session_status() === PHP_SESSION_NONE) session_start();
ob_start(); // ✅ Tambahkan buffering agar header() aman

require_once __DIR__ . "/../config/session_guard.php";
require_once __DIR__ . "/../config/db_config.php";
require_once __DIR__ . "/../includes/header.php";
require_once __DIR__ . "/../includes/sidebar.php";
require_once __DIR__ . "/../includes/topbar.php";

$conn = db();
$school_id = $_SESSION['school_id'] ?? 0;

// Pastikan hanya admin yang bisa akses
if ($_SESSION['user_type'] !== 'admin') {
    header("Location: ../dashboard.php");
    exit;
}

// ============================================================
// VALIDASI PARAMETER
// ============================================================
$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
    die("ID buku tidak valid.");
}

// ============================================================
// AMBIL DATA BUKU
// ============================================================
$stmt = $conn->prepare("
    SELECT b.*, c.name AS category_name, l.name AS location_name
    FROM books b
    LEFT JOIN categories c ON c.id = b.category_id
    LEFT JOIN book_locations l ON l.id = b.location_id
    WHERE b.id = ? AND b.school_id = ?
    LIMIT 1
");
$stmt->bind_param("ii", $id, $school_id);
$stmt->execute();
$res = $stmt->get_result();
$book = $res->fetch_assoc();
$stmt->close();

if (!$book) {
    die("Data buku tidak ditemukan.");
}

// ============================================================
// AMBIL DAFTAR KATEGORI DAN LOKASI
// ============================================================
$categories = $conn->query("
    SELECT id, name
    FROM categories
    WHERE school_id = $school_id
    ORDER BY name ASC
");

$locations = $conn->query("
    SELECT id, CONCAT(code, ' - ', name) AS fullname
    FROM book_locations
    WHERE school_id = $school_id
    ORDER BY code ASC
");

// ============================================================
// HANDLE SUBMIT
// ============================================================
$msg = "";
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title           = trim($_POST['title'] ?? '');
    $author          = trim($_POST['author'] ?? '');
    $publisher       = trim($_POST['publisher'] ?? '');
    $year            = (int)($_POST['year'] ?? 0);
    $isbn            = trim($_POST['isbn'] ?? '');
    $category_id     = (int)($_POST['category_id'] ?? 0);
    $location_id     = (int)($_POST['location_id'] ?? 0);
    $stock_total     = (int)($_POST['stock_total'] ?? 0);
    $stock_available = (int)($_POST['stock_available'] ?? 0);

    if ($title === '') {
        $msg = "Judul Buku wajib diisi.";
    } else {
        $stmt2 = $conn->prepare("
            UPDATE books
            SET category_id=?, location_id=?, title=?, author=?, publisher=?, year=?, isbn=?, stock_total=?, stock_available=?
            WHERE id=? AND school_id=?
        ");
        $stmt2->bind_param(
            "iisssssiiii",
            $category_id, $location_id, $title, $author, $publisher, $year, $isbn,
            $stock_total, $stock_available, $id, $school_id
        );

        if ($stmt2->execute()) {
            $_SESSION['flash_success'] = "Perubahan buku '$title' berhasil disimpan.";
            ob_clean(); // ✅ Bersihkan buffer sebelum redirect
            header("Location: books.php");
            exit;
        } else {
            $msg = "Gagal menyimpan perubahan data buku.";
        }
        $stmt2->close();
    }
}
?>

<!-- ============================================================ -->
<!-- MAIN CONTENT AREA -->
<!-- ============================================================ -->
<main id="mainContent" class="flex-grow-1 p-4">
  <div class="container-fluid">

    <div class="d-flex justify-content-between align-items-center mb-3">
      <h4 class="text-primary mb-0"><i class="bi bi-pencil-square me-2"></i>Edit Buku</h4>
      <a href="books.php" class="btn btn-outline-secondary btn-sm">
        <i class="bi bi-arrow-left"></i> Kembali
      </a>
    </div>

    <div class="card shadow-sm border-0">
      <div class="card-body">
        <?php if (!empty($msg)): ?>
          <div class="alert alert-danger auto-dismiss"><?= htmlspecialchars($msg) ?></div>
        <?php endif; ?>

        <form method="post" autocomplete="off">
          <div class="row g-3">

            <div class="col-md-4">
              <label class="form-label fw-semibold">Kode Buku</label>
              <input type="text" name="code" class="form-control bg-light"
                     value="<?= htmlspecialchars($book['code']) ?>" readonly>
            </div>

            <div class="col-md-8">
              <label class="form-label fw-semibold">Judul Buku</label>
              <input type="text" name="title" class="form-control"
                     value="<?= htmlspecialchars($book['title']) ?>" required>
            </div>

            <div class="col-md-6">
              <label class="form-label fw-semibold">Penulis</label>
              <input type="text" name="author" class="form-control"
                     value="<?= htmlspecialchars($book['author']) ?>">
            </div>

            <div class="col-md-6">
              <label class="form-label fw-semibold">Penerbit</label>
              <input type="text" name="publisher" class="form-control"
                     value="<?= htmlspecialchars($book['publisher']) ?>">
            </div>

            <div class="col-md-4">
              <label class="form-label fw-semibold">Tahun</label>
              <input type="number" name="year" class="form-control"
                     value="<?= htmlspecialchars($book['year']) ?>">
            </div>

            <div class="col-md-4">
              <label class="form-label fw-semibold">ISBN</label>
              <input type="text" name="isbn" class="form-control"
                     value="<?= htmlspecialchars($book['isbn']) ?>">
            </div>

            <div class="col-md-4">
              <label class="form-label fw-semibold">Kategori</label>
              <select name="category_id" class="form-select">
                <option value="0">- Pilih Kategori -</option>
                <?php while ($cat = $categories->fetch_assoc()): ?>
                  <option value="<?= $cat['id'] ?>"
                          <?= ($book['category_id'] == $cat['id']) ? 'selected' : '' ?>>
                    <?= htmlspecialchars($cat['name']) ?>
                  </option>
                <?php endwhile; ?>
              </select>
            </div>

            <div class="col-md-6">
              <label class="form-label fw-semibold">Lokasi / Rak Buku</label>
              <select name="location_id" class="form-select">
                <option value="0">- Pilih Lokasi -</option>
                <?php while ($loc = $locations->fetch_assoc()): ?>
                  <option value="<?= $loc['id'] ?>"
                          <?= ($book['location_id'] == $loc['id']) ? 'selected' : '' ?>>
                    <?= htmlspecialchars($loc['fullname']) ?>
                  </option>
                <?php endwhile; ?>
              </select>
            </div>

            <div class="col-md-3">
              <label class="form-label fw-semibold">Jumlah Stok Total</label>
              <input type="number" name="stock_total" class="form-control"
                     value="<?= (int)$book['stock_total'] ?>" required>
            </div>

            <div class="col-md-3">
              <label class="form-label fw-semibold">Stok Tersedia</label>
              <input type="number" name="stock_available" class="form-control"
                     value="<?= (int)$book['stock_available'] ?>" required>
            </div>

          </div>

          <div class="text-end mt-4">
            <button type="submit" class="btn btn-primary px-4">
              <i class="bi bi-save me-1"></i> Simpan Perubahan
            </button>
          </div>
        </form>
      </div>
    </div>
  </div>
</main>

<?php require_once __DIR__ . "/../includes/footer.php"; ?>

<!-- SweetAlert notifikasi -->
<?php if (!empty($_SESSION['flash_success'])): ?>
<script> alertSuccess("<?= addslashes($_SESSION['flash_success']); ?>"); </script>
<?php unset($_SESSION['flash_success']); endif; ?>

<?php ob_end_flush(); // ✅ Kirim semua output ke browser ?>
