<?php
// ============================================================
// LENTERA LIBRARY SYSTEM – BOOKS (CREATE NEW - FINAL DENGAN LOKASI)
// ============================================================

$pageTitle = "Tambah Buku";

if (session_status() === PHP_SESSION_NONE) session_start();
ob_start(); // Buffering agar header() aman

require_once __DIR__ . "/../config/session_guard.php";
require_once __DIR__ . "/../config/db_config.php";
require_once __DIR__ . "/../config/doc_numbering_helper.php";   // ✅ pakai helper global
require_once __DIR__ . "/../includes/header.php";
require_once __DIR__ . "/../includes/sidebar.php";
require_once __DIR__ . "/../includes/topbar.php";

// ============================================================
// Hanya admin yang boleh
// ============================================================
if (($_SESSION['user_type'] ?? '') !== 'admin') {
    header("Location: ../dashboard.php");
    exit;
}

$conn = db();
$school_id = (int)($_SESSION['school_id'] ?? 0);
$msg = "";

// ============================================================
// HANDLE SUBMIT
// ============================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title        = trim($_POST['title'] ?? '');
    $author       = trim($_POST['author'] ?? '');
    $publisher    = trim($_POST['publisher'] ?? '');
    $year         = (int)($_POST['year'] ?? 0);
    $isbn         = trim($_POST['isbn'] ?? '');
    $category_id  = (int)($_POST['category_id'] ?? 0);
    $location_id  = (int)($_POST['location_id'] ?? 0);
    $stock_total  = (int)($_POST['stock_total'] ?? 0);

    if ($title === '') {
        $msg = "Judul Buku wajib diisi.";
    } else {
        try {
            // ✅ generate nomor dokumen dari helper global (module_code = BOOK, prefix default = BOOK)
            $code = generate_doc_number($conn, $school_id, 'BOOK', 'BOOK');
        } catch (Exception $e) {
            $msg = $e->getMessage();
            $code = null;
        }

        if ($code) {
            $stmt = $conn->prepare("
                INSERT INTO books 
                (school_id, category_id, location_id, code, title, author, publisher, year, isbn, stock_total, stock_available)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");
            // i i i s s s s i s i i
            $stmt->bind_param(
                "iiiisssisii",
                $school_id,          // i
                $category_id,        // i
                $location_id,        // i
                $code,               // s
                $title,              // s
                $author,             // s
                $publisher,          // s
                $year,               // i
                $isbn,               // s
                $stock_total,        // i
                $stock_total         // i (stock_available awal = stock_total)
            );

            if ($stmt->execute()) {
                $_SESSION['flash_success'] = "Buku '$title' berhasil ditambahkan dengan kode $code.";
                ob_clean(); // bersihkan buffer sebelum redirect
                header("Location: books.php");
                exit;
            } else {
                $msg = "Gagal menambahkan buku. Pastikan data valid dan kode unik.";
            }
            $stmt->close();
        }
    }
}

// Ambil kategori buku
$categories = $conn->query("
    SELECT id, name 
    FROM categories 
    WHERE school_id = {$school_id}
    ORDER BY name ASC
");

// Ambil daftar lokasi buku
$locations = $conn->query("
    SELECT id, CONCAT(code, ' - ', name) AS fullname
    FROM book_locations
    WHERE school_id = {$school_id}
    ORDER BY code ASC
");
?>

<!-- ============================================================ -->
<!-- MAIN CONTENT AREA -->
<!-- ============================================================ -->
<main id="mainContent" class="flex-grow-1 p-4">
  <div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-3">
      <h4 class="text-primary mb-0"><i class="bi bi-plus-lg me-2"></i> Tambah Buku Baru</h4>
      <a href="books.php" class="btn btn-outline-secondary btn-sm"><i class="bi bi-arrow-left"></i> Kembali</a>
    </div>

    <div class="card shadow-sm border-0">
      <div class="card-body">
        <?php if ($msg): ?>
          <div class="alert alert-danger auto-dismiss"><?= htmlspecialchars($msg) ?></div>
        <?php endif; ?>

        <form method="post" autocomplete="off">
          <div class="row g-3">

            <div class="col-md-8">
              <label class="form-label fw-semibold">Judul Buku</label>
              <input type="text" name="title" class="form-control" placeholder="Judul lengkap buku" required>
            </div>

            <div class="col-md-4">
              <label class="form-label fw-semibold">Kategori</label>
              <select name="category_id" class="form-select">
                <option value="0">- Pilih Kategori -</option>
                <?php while ($cat = $categories->fetch_assoc()): ?>
                  <option value="<?= (int)$cat['id'] ?>"><?= htmlspecialchars($cat['name']) ?></option>
                <?php endwhile; ?>
              </select>
            </div>

            <div class="col-md-6">
              <label class="form-label fw-semibold">Penulis</label>
              <input type="text" name="author" class="form-control" placeholder="Nama penulis">
            </div>

            <div class="col-md-6">
              <label class="form-label fw-semibold">Penerbit</label>
              <input type="text" name="publisher" class="form-control" placeholder="Nama penerbit">
            </div>

            <div class="col-md-4">
              <label class="form-label fw-semibold">Tahun</label>
              <input type="number" name="year" class="form-control" placeholder="2025">
            </div>

            <div class="col-md-4">
              <label class="form-label fw-semibold">ISBN</label>
              <input type="text" name="isbn" class="form-control" placeholder="Nomor ISBN">
            </div>

            <div class="col-md-4">
              <label class="form-label fw-semibold">Jumlah Stok</label>
              <input type="number" name="stock_total" class="form-control" min="1" value="1" required>
            </div>

            <div class="col-md-6">
              <label class="form-label fw-semibold">Lokasi / Rak Buku</label>
              <select name="location_id" class="form-select">
                <option value="0">- Pilih Lokasi Buku -</option>
                <?php while ($loc = $locations->fetch_assoc()): ?>
                  <option value="<?= (int)$loc['id'] ?>"><?= htmlspecialchars($loc['fullname']) ?></option>
                <?php endwhile; ?>
              </select>
            </div>

          </div>

          <div class="text-end mt-4">
            <button type="submit" class="btn btn-primary px-4">
              <i class="bi bi-save me-1"></i> Simpan
            </button>
          </div>
        </form>
      </div>
    </div>
  </div>
</main>

<?php require_once __DIR__ . "/../includes/footer.php"; ?>

<?php ob_end_flush(); // Kirim semua output ke browser ?>
