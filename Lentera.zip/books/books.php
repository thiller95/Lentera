<?php
// ============================================================
// LENTERA LIBRARY SYSTEM – BOOKS (LIST VIEW - FINAL + UPLOAD & DOWNLOAD EXCEL)
// ============================================================

$pageTitle = "Data Buku";

if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . "/../config/session_guard.php";
require_once __DIR__ . "/../config/db_config.php";
require_once __DIR__ . "/../includes/header.php";
require_once __DIR__ . "/../includes/sidebar.php";
require_once __DIR__ . "/../includes/topbar.php";

$conn = db();
$school_id = $_SESSION['school_id'] ?? 0;

// Pastikan hanya admin
if ($_SESSION['user_type'] !== 'admin') {
  header("Location: ../dashboard.php");
  exit;
}
?>

<!-- ============================================================ -->
<!-- MAIN CONTENT AREA -->
<!-- ============================================================ -->
<main id="mainContent" class="flex-grow-1 p-4">
  <div class="container-fluid">

    <!-- Header -->
    <div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
      <h4 class="text-primary mb-0">
        <i class="bi bi-book me-2"></i> Daftar Buku
      </h4>
      <div class="d-flex gap-2">
        <a href="books-template-download.php" class="btn btn-outline-success btn-sm">
          <i class="bi bi-download"></i> Download Data
        </a>
        <button type="button" class="btn btn-outline-secondary btn-sm" data-bs-toggle="modal" data-bs-target="#uploadModal">
          <i class="bi bi-upload"></i> Upload Data
        </button>
        <a href="books-create.php" class="btn btn-primary btn-sm">
          <i class="bi bi-plus-lg"></i> Tambah Buku
        </a>
      </div>
    </div>

    <!-- Card -->
    <div class="card shadow-sm border-0">
      <div class="card-body">
        <div class="table-responsive">
          <table id="booksTable" class="table table-bordered align-middle table-hover w-100">
            <thead class="table-light">
              <tr>
                <th width="50">No</th>
                <th>Kode</th>
                <th>Judul Buku</th>
                <th>Penulis</th>
                <th>Penerbit</th>
                <th>Kategori</th>
                <th>Lokasi</th>
                <th>Stok</th>
                <th width="100">Aksi</th>
              </tr>
            </thead>
            <tbody>
              <?php
              $sql = "
                SELECT 
                  b.*, 
                  c.name AS category_name,
                  l.name AS location_name
                FROM books b
                LEFT JOIN categories c ON c.id = b.category_id
                LEFT JOIN book_locations l ON l.id = b.location_id
                WHERE b.school_id = $school_id
                ORDER BY b.title ASC
              ";
              $res = $conn->query($sql);
              $no = 1;
              if ($res && $res->num_rows > 0):
                while ($row = $res->fetch_assoc()):
              ?>
              <tr>
                <td><?= $no++ ?></td>
                <td><?= htmlspecialchars($row['code']) ?></td>
                <td><?= htmlspecialchars($row['title']) ?></td>
                <td><?= htmlspecialchars($row['author']) ?></td>
                <td><?= htmlspecialchars($row['publisher']) ?></td>
                <td><?= htmlspecialchars($row['category_name'] ?? '-') ?></td>
                <td><?= htmlspecialchars($row['location_name'] ?? '-') ?></td>
                <td><?= (int)$row['stock_available'] ?>/<?= (int)$row['stock_total'] ?></td>
                <td class="text-center">
                  <a href="books-edit.php?id=<?= $row['id'] ?>" 
                     class="btn btn-sm btn-outline-primary me-1" 
                     title="Edit Buku">
                    <i class="bi bi-pencil-square"></i>
                  </a>
                  <button class="btn btn-sm btn-outline-danger btn-delete"
                          data-id="<?= $row['id'] ?>"
                          data-title="<?= htmlspecialchars($row['title']) ?>"
                          title="Hapus Buku">
                    <i class="bi bi-trash"></i>
                  </button>
                </td>
              </tr>
              <?php endwhile; else: ?>
              <tr><td colspan="9" class="text-center text-muted">Belum ada data buku.</td></tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>

  </div>
</main>

<!-- ============================================================ -->
<!-- MODAL UPLOAD EXCEL -->
<!-- ============================================================ -->
<div class="modal fade" id="uploadModal" tabindex="-1" aria-labelledby="uploadModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <form id="uploadForm" enctype="multipart/form-data">
      <div class="modal-content">
        <div class="modal-header bg-light">
          <h5 class="modal-title" id="uploadModalLabel">
            <i class="bi bi-upload me-2"></i> Upload Data Buku (Excel)
          </h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Tutup"></button>
        </div>
        <div class="modal-body">
          <p class="small text-muted mb-2">
            Unggah file Excel (.xlsx) sesuai format template.<br>
            <strong>Sheet 1:</strong> Data Buku (Judul, Penulis, Penerbit, Kategori, Lokasi, Stok)<br>
            <strong>Sheet 2:</strong> Rak Buku (Kode, Nama, Ruangan, Catatan)
          </p>
          <input type="file" name="file" class="form-control" accept=".xlsx,.xls" required>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-light" data-bs-dismiss="modal">Batal</button>
          <button type="submit" class="btn btn-primary">
            <i class="bi bi-upload"></i> Upload
          </button>
        </div>
      </div>
    </form>
  </div>
</div>

<?php require_once __DIR__ . "/../includes/footer.php"; ?>

<!-- ============================================================ -->
<!-- DATATABLES -->
<!-- ============================================================ -->
<link rel="stylesheet" href="../assets/css/dataTables.bootstrap5.min.css">
<script src="../assets/js/jquery.dataTables.min.js"></script>
<script src="../assets/js/dataTables.bootstrap5.min.js"></script>

<!-- ============================================================ -->
<!-- CUSTOM SCRIPT -->
<!-- ============================================================ -->
<script>
$(document).ready(function() {

  // ===============================
  // 📋 Inisialisasi DataTables
  // ===============================
  const table = $('#booksTable').DataTable({
    responsive: true,
    autoWidth: false,
    pageLength: 10,
    language: { url: "../assets/lang/indonesian.json" }
  });

  // ===============================
  // 🗑️ Hapus Buku
  // ===============================
  $(".btn-delete").on("click", function() {
    const id = $(this).data("id");
    const title = $(this).data("title");
    confirmAction(`Apakah Anda yakin ingin menghapus buku "${title}"?`, function() {
      $.post("books-delete.php", { id }, function(res) {
        try {
          const data = JSON.parse(res);
          if (data.status === "success") {
            toast("Buku berhasil dihapus");
            setTimeout(() => location.reload(), 800);
          } else {
            alertError(data.message || "Gagal menghapus buku.");
          }
        } catch {
          alertError("Respon server tidak valid.");
        }
      });
    });
  });

  // ===============================
  // 📤 Upload Data Buku (Excel)
  // ===============================
  $("#uploadForm").on("submit", function(e) {
    e.preventDefault();
    const formData = new FormData(this);

    $.ajax({
      url: "books-upload.php",
      type: "POST",
      data: formData,
      contentType: false,
      processData: false,
      dataType: "json", // ⬅️ biar respon otomatis di-parse
      beforeSend: function() {
        $("#uploadForm button[type=submit]")
          .prop("disabled", true)
          .html('<span class="spinner-border spinner-border-sm me-1"></span> Mengunggah...');
      },
      success: function(data) {
        console.log("Server Response:", data);
        if (data.status === "success") {
          toast(data.message);
          setTimeout(() => location.reload(), 1000);
        } else {
          alertError(data.message || "Terjadi kesalahan saat upload.");
        }
      },
      error: function(xhr, status, err) {
        console.error("AJAX Error:", status, err);
        alertError("Tidak dapat menghubungi server atau respon tidak valid.");
      },
      complete: function() {
        $("#uploadForm button[type=submit]")
          .prop("disabled", false)
          .html('<i class="bi bi-upload"></i> Upload');
      }
    });
  });

  // ===============================
  // 🔄 Sidebar margin fix
  // ===============================
  function adjustMargin() {
    const size = localStorage.getItem('sidebar-size') || 'lg';
    $('#mainContent').css('margin-left', size === 'sm' ? '70px' : '250px');
  }
  adjustMargin();
});
</script>
