<?php
// ============================================================
// LIBRARY SYSTEM - BOOK DELETE ACTION
// ============================================================
require_once __DIR__ . "/config/session_guard.php";
require_once __DIR__ . "/config/db_config.php";

if ($_SESSION['user_type'] !== 'admin') {
    echo json_encode(["status" => "error", "message" => "Akses ditolak."]);
    exit;
}

$id = (int)($_POST['id'] ?? 0);
if ($id <= 0) {
    echo json_encode(["status" => "error", "message" => "ID tidak valid."]);
    exit;
}

$conn = db();
$stmt = $conn->prepare("DELETE FROM books WHERE id = ? AND school_id = ?");
$stmt->bind_param("ii", $id, $_SESSION['school_id']);

if ($stmt->execute()) {
    echo json_encode(["status" => "success"]);
} else {
    echo json_encode(["status" => "error", "message" => "Gagal menghapus data."]);
}
$stmt->close();
