<?php
// ============================================================
// LENTERA LIBRARY SYSTEM – BOOK LOCATIONS (LIST + AUTO CODE)
// ============================================================

$pageTitle = "Rak / Lokasi Buku";

if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . "/../config/session_guard.php";
require_once __DIR__ . "/../config/db_config.php";
require_once __DIR__ . "/../includes/header.php";
require_once __DIR__ . "/../includes/sidebar.php";
require_once __DIR__ . "/../includes/topbar.php";

$conn = db();
$school_id = $_SESSION['school_id'] ?? 0;

// Hanya admin
if ($_SESSION['user_type'] !== 'admin') {
  header("Location: ../dashboard.php");
  exit;
}

// ============================================================
// QUERY DATA
// ============================================================
$sql = "SELECT * FROM book_locations WHERE school_id = $school_id ORDER BY code ASC";
$res = $conn->query($sql);
$no = 1;
$hasData = $res && $res->num_rows > 0;
?>

<!-- ============================================================ -->
<!-- MAIN CONTENT -->
<!-- ============================================================ -->
<main id="mainContent" class="flex-grow-1 p-4">
  <div class="container-fluid">

    <!-- Header -->
    <div class="d-flex justify-content-between align-items-center mb-3">
      <h4 class="text-primary mb-0">
        <i class="bi bi-bookshelf me-2"></i> Rak / Lokasi Buku
      </h4>
      <button class="btn btn-primary btn-sm" id="btnAdd">
        <i class="bi bi-plus-lg"></i> Tambah Lokasi
      </button>
    </div>

    <!-- Alert kalau belum ada data -->
    <?php if (!$hasData): ?>
      <div class="alert alert-warning alert-dismissible fade show mb-3">
        <i class="bi bi-exclamation-circle me-2"></i>
        Belum ada data lokasi buku. Klik <b>Tambah Lokasi</b> untuk menambahkan rak pertama.
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
      </div>
    <?php endif; ?>

    <!-- Card -->
    <div class="card shadow-sm border-0">
      <div class="card-body">
        <div class="table-responsive">
          <table id="locationTable" class="table table-bordered align-middle table-hover w-100">
            <thead class="table-light">
              <tr>
                <th width="50">No</th>
                <th>Kode</th>
                <th>Nama Lokasi</th>
                <th>Ruang</th>
                <th>Keterangan</th>
                <th width="100">Aksi</th>
              </tr>
            </thead>
            <tbody>
              <?php if ($hasData): ?>
                <?php while ($row = $res->fetch_assoc()): ?>
                <tr>
                  <td><?= $no++ ?></td>
                  <td><?= htmlspecialchars($row['code']) ?></td>
                  <td><?= htmlspecialchars($row['name']) ?></td>
                  <td><?= htmlspecialchars($row['room'] ?? '-') ?></td>
                  <td><?= htmlspecialchars($row['notes'] ?? '-') ?></td>
                  <td class="text-center">
                    <button class="btn btn-sm btn-outline-primary btn-edit"
                            data-id="<?= $row['id'] ?>"
                            data-code="<?= htmlspecialchars($row['code']) ?>"
                            data-name="<?= htmlspecialchars($row['name']) ?>"
                            data-room="<?= htmlspecialchars($row['room']) ?>"
                            data-notes="<?= htmlspecialchars($row['notes']) ?>">
                      <i class="bi bi-pencil-square"></i>
                    </button>
                    <button class="btn btn-sm btn-outline-danger btn-delete" data-id="<?= $row['id'] ?>">
                      <i class="bi bi-trash"></i>
                    </button>
                  </td>
                </tr>
                <?php endwhile; ?>
              <?php else: ?>
                <!-- Jika tidak ada data -->
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>

  </div>
</main>

<?php require_once __DIR__ . "/../includes/footer.php"; ?>

<!-- ============================================================ -->
<!-- MODAL TAMBAH / EDIT -->
<!-- ============================================================ -->
<div class="modal fade" id="modalForm" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <form id="formLocation">
        <div class="modal-header">
          <h5 class="modal-title"><i class="bi bi-bookshelf me-2"></i> <span id="modalTitle">Tambah Lokasi</span></h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body">
          <input type="hidden" name="id" id="loc_id">

          <div class="mb-3">
            <label class="form-label">Kode Rak (Otomatis)</label>
            <input type="text" class="form-control" name="code" id="loc_code" readonly placeholder="(Akan dibuat otomatis)">
          </div>

          <div class="mb-3">
            <label class="form-label">Nama Lokasi</label>
            <input type="text" class="form-control" name="name" id="loc_name" required>
          </div>

          <div class="mb-3">
            <label class="form-label">Ruang</label>
            <input type="text" class="form-control" name="room" id="loc_room">
          </div>

          <div class="mb-3">
            <label class="form-label">Keterangan</label>
            <textarea class="form-control" name="notes" id="loc_notes" rows="2"></textarea>
          </div>
        </div>

        <div class="modal-footer">
          <button type="submit" class="btn btn-primary">Simpan</button>
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- ============================================================ -->
<!-- DATATABLES -->
<!-- ============================================================ -->
<link rel="stylesheet" href="../assets/css/dataTables.bootstrap5.min.css">
<script src="../assets/js/jquery.dataTables.min.js"></script>
<script src="../assets/js/dataTables.bootstrap5.min.js"></script>

<!-- ============================================================ -->
<!-- CUSTOM SCRIPT -->
<!-- ============================================================ -->
<script>
$(function() {
  const table = $('#locationTable').DataTable({
    responsive: true,
    autoWidth: false,
    pageLength: 10,
    language: { url: "../assets/lang/indonesian.json" }
  });

  const modal = new bootstrap.Modal(document.getElementById('modalForm'));

  // ===============================
  // ➕ Tambah lokasi baru
  // ===============================
  $('#btnAdd').on('click', function() {
    $('#formLocation')[0].reset();
    $('#loc_id').val('');
    $('#loc_code').val('(otomatis)');
    $('#modalTitle').text('Tambah Lokasi');
    modal.show();
  });

  // ===============================
  // ✏️ Edit lokasi
  // ===============================
  $('.btn-edit').on('click', function() {
    $('#loc_id').val($(this).data('id'));
    $('#loc_code').val($(this).data('code'));
    $('#loc_name').val($(this).data('name'));
    $('#loc_room').val($(this).data('room'));
    $('#loc_notes').val($(this).data('notes'));
    $('#modalTitle').text('Edit Lokasi');
    modal.show();
  });

  // ===============================
  // 💾 Simpan (Tambah / Edit)
  // ===============================
  $('#formLocation').on('submit', function(e) {
    e.preventDefault();
    $.ajax({
      url: "book-locations-save.php",
      method: "POST",
      data: $(this).serialize(),
      success: function(res) {
        try {
          const data = JSON.parse(res);
          if (data.status === 'success') {
            toast(data.message);
            setTimeout(() => location.reload(), 800);
          } else {
            alertError(data.message || 'Terjadi kesalahan saat menyimpan data.');
          }
        } catch {
          alertError('Gagal membaca respon server.');
        }
      },
      error: () => alertError('Gagal terhubung ke server.')
    });
  });

  // ===============================
  // 🗑️ Hapus lokasi
  // ===============================
  $('.btn-delete').on('click', function() {
    const id = $(this).data('id');
    confirmAction('Hapus lokasi ini?', function() {
      $.post('book-locations-delete.php', { id }, function(res) {
        try {
          const data = JSON.parse(res);
          if (data.status === 'success') {
            toast(data.message);
            setTimeout(() => location.reload(), 800);
          } else {
            alertError(data.message);
          }
        } catch {
          alertError('Respon server tidak valid.');
        }
      });
    });
  });
});
</script>
