<?php
// ============================================================
// LENTERA LIBRARY SYSTEM – PROFILE USER (Admin / Staff)
// ============================================================
$pageTitle = "Profil Pengguna";

if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . "/config/session_guard.php";
require_once __DIR__ . "/config/db_config.php";
require_once __DIR__ . "/includes/header.php";
require_once __DIR__ . "/includes/sidebar.php";
require_once __DIR__ . "/includes/topbar.php";

$conn = db();
$user_id   = $_SESSION['user_id'] ?? 0;
$school_id = $_SESSION['school_id'] ?? 0;

// ============================================================
// CEK DATA USER
// ============================================================
$stmt = $conn->prepare("
  SELECT a.*, s.name AS school_name
  FROM admins a
  JOIN schools s ON s.id = a.school_id
  WHERE a.id=? AND a.school_id=? LIMIT 1
");
$stmt->bind_param("ii", $user_id, $school_id);
$stmt->execute();
$res  = $stmt->get_result();
$user = $res->fetch_assoc();
if (!$user) {
  die("<div style='margin:40px;color:red;font-weight:bold'>❌ Data pengguna tidak ditemukan.</div>");
}

// ============================================================
// HANDLE FORM SUBMIT
// ============================================================
$success = $error = "";
if (isset($_GET['success']) && $_GET['success'] == 1) {
    $success = "Profil berhasil diperbarui.";
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name      = trim($_POST['name']);
    $password  = trim($_POST['password']);
    $confirm   = trim($_POST['confirm']);
    $photoFile = $_FILES['photo'] ?? null;

    if ($name === "") {
        $error = "Nama tidak boleh kosong.";
    } elseif ($password !== "" && $password !== $confirm) {
        $error = "Konfirmasi password tidak sesuai.";
    } else {
        $photoName = $user['photo'];

        // Upload foto baru jika ada
        if (!empty($photoFile['name'])) {
            $ext = strtolower(pathinfo($photoFile['name'], PATHINFO_EXTENSION));
            $allowedExt = ['jpg', 'jpeg', 'png', 'gif'];

            if (!in_array($ext, $allowedExt)) {
                $error = "Format foto tidak valid (hanya JPG, PNG, GIF).";
            } elseif ($photoFile['size'] > 2 * 1024 * 1024) {
                $error = "Ukuran foto terlalu besar (maksimum 2MB).";
            } else {
                $photoName = "user_" . $user_id . "_" . time() . "." . $ext;
                $uploadDir = __DIR__ . "/assets/img/uploads/user/";
                if (!is_dir($uploadDir)) mkdir($uploadDir, 0777, true);
                move_uploaded_file($photoFile['tmp_name'], $uploadDir . $photoName);
            }
        }

        // Simpan perubahan jika tidak ada error
        if ($error === "") {
            if ($password !== "") {
                $hashed = password_hash($password, PASSWORD_BCRYPT);
                $stmt = $conn->prepare("UPDATE admins SET name=?, password=?, photo=? WHERE id=? AND school_id=?");
                $stmt->bind_param("sssii", $name, $hashed, $photoName, $user_id, $school_id);
            } else {
                $stmt = $conn->prepare("UPDATE admins SET name=?, photo=? WHERE id=? AND school_id=?");
                $stmt->bind_param("ssii", $name, $photoName, $user_id, $school_id);
            }
            $stmt->execute();

            // Update session data
            $_SESSION['name']  = $name;
            $_SESSION['photo'] = $photoName;

            $success = "Profil berhasil diperbarui.";

            // redirect ringan untuk hapus POST agar tidak reload terus
            echo "<meta http-equiv='refresh' content='0;url=profile.php?success=1'>";
            exit;

        }
    }
}
?>

<!-- ============================================================ -->
<!-- MAIN CONTENT AREA -->
<!-- ============================================================ -->
<main id="mainContent" class="flex-grow-1 p-4">
  <div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-3">
      <h4 class="text-primary mb-0"><i class="bi bi-person-circle me-2"></i> Profil Pengguna</h4>
    </div>

    <div class="card shadow-sm border-0 p-4">
      <?php if ($error): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
      <?php elseif ($success): ?>
        <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
      <?php endif; ?>

      <form method="post" enctype="multipart/form-data">
        <div class="row">
          <!-- FOTO PROFIL -->
          <div class="col-md-4 text-center">
            <?php
              $photoPath = __DIR__ . "/assets/img/uploads/user/" . $user['photo'];
              $photoUrl = (!empty($user['photo']) && file_exists($photoPath))
                ? BASE_URL . "/assets/img/uploads/user/" . $user['photo']
                : BASE_URL . "/assets/img/user-default.png";
            ?>
            <div class="position-relative d-inline-block mb-3">
              <img id="photoPreview" src="<?= $photoUrl ?>" class="rounded-circle border shadow-sm" width="140" height="140" style="object-fit:cover;">
            </div>
            <div>
              <input type="file" name="photo" accept="image/*" class="form-control mt-2" onchange="previewPhoto(this)">
              <small class="text-muted d-block mt-1">Format: JPG, PNG, GIF (maks 2MB)</small>
            </div>
          </div>

          <!-- FORM DETAIL -->
          <div class="col-md-8">
            <div class="mb-3">
              <label class="form-label fw-semibold">Nama Lengkap</label>
              <input type="text" name="name" class="form-control" value="<?= htmlspecialchars($user['name']) ?>" required>
            </div>
            <div class="mb-3">
              <label class="form-label fw-semibold">Username</label>
              <input type="text" class="form-control bg-light" value="<?= htmlspecialchars($user['username']) ?>" disabled>
            </div>
            <div class="mb-3">
              <label class="form-label fw-semibold">Sekolah</label>
              <input type="text" class="form-control bg-light" value="<?= htmlspecialchars($user['school_name']) ?>" disabled>
            </div>
            <div class="mb-3">
              <label class="form-label fw-semibold">Role</label>
              <input type="text" class="form-control bg-light" value="<?= htmlspecialchars(ucfirst($user['role'])) ?>" disabled>
            </div>

            <hr>
            <h6 class="text-muted mb-3"><i class="bi bi-key"></i> Ganti Password (opsional)</h6>
            <div class="row">
              <div class="col-md-6 mb-3">
                <label>Password Baru</label>
                <input type="password" name="password" class="form-control" placeholder="Kosongkan jika tidak diubah">
              </div>
              <div class="col-md-6 mb-3">
                <label>Konfirmasi Password</label>
                <input type="password" name="confirm" class="form-control" placeholder="Ulangi password baru">
              </div>
            </div>

            <div class="text-end">
              <button type="submit" class="btn btn-primary px-4">
                <i class="bi bi-save me-1"></i> Simpan Perubahan
              </button>
            </div>
          </div>
        </div>
      </form>
    </div>
  </div>
</main>

<?php require_once __DIR__ . "/includes/footer.php"; ?>

<!-- ============================================================ -->
<!-- JS PREVIEW & ALERT -->
<!-- ============================================================ -->
<script>
function previewPhoto(input) {
  if (input.files && input.files[0]) {
    const reader = new FileReader();
    reader.onload = e => document.getElementById('photoPreview').src = e.target.result;
    reader.readAsDataURL(input.files[0]);
  }
}
</script>

<?php if ($success): ?>
<script>
Swal.fire({
  icon: 'success',
  title: 'Berhasil!',
  text: '<?= addslashes($success) ?>',
  confirmButtonColor: '#2563EB'
});

</script>
<?php endif; ?>
