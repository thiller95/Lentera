<?php
// ============================================================
// LENTERA LIBRARY SYSTEM – SCHOOLS CREATE (ADMIN MASTER + LOGO UPLOAD)
// ============================================================

$pageTitle = "Tambah Sekolah";

if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . "/../config/session_guard.php";
require_once __DIR__ . "/../config/db_config.php";
require_once __DIR__ . "/../includes/header.php";
require_once __DIR__ . "/../includes/sidebar.php";
require_once __DIR__ . "/../includes/topbar.php";

$conn = db();

if ($_SESSION['user_type'] !== 'admin') {
    header("Location: ../dashboard.php");
    exit;
}

// ============================================================
// 🔧 PROSES SIMPAN DATA
// ============================================================
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $code       = trim($_POST["code"] ?? "");
    $name       = trim($_POST["name"] ?? "");
    $address    = trim($_POST["address"] ?? "");
    $phone      = trim($_POST["phone"] ?? "");
    $email      = trim($_POST["email"] ?? "");
    $headmaster = trim($_POST["headmaster"] ?? "");
    $logoPath   = null;

    if ($code === "" || $name === "") {
        $error = "Kode dan Nama Sekolah wajib diisi.";
    } else {
        // Cek kode unik
        $stmt = $conn->prepare("SELECT id FROM schools WHERE code = ?");
        $stmt->bind_param("s", $code);
        $stmt->execute();
        if ($stmt->get_result()->num_rows > 0) {
            $error = "Kode sekolah sudah digunakan.";
        } else {
            // ============================================================
            // 🖼️ UPLOAD LOGO (optional)
            // ============================================================
            if (!empty($_FILES['logo']['name'])) {
                $uploadDir = __DIR__ . "/../uploads/schools/";
                if (!is_dir($uploadDir)) mkdir($uploadDir, 0777, true);

                $fileTmp  = $_FILES['logo']['tmp_name'];
                $fileName = basename($_FILES['logo']['name']);
                $ext      = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
                $newName  = "logo_" . preg_replace('/[^a-zA-Z0-9]/', '', $code) . "_" . time() . "." . $ext;
                $target   = $uploadDir . $newName;

                // Validasi file
                $allowed = ['jpg', 'jpeg', 'png', 'gif'];
                if (in_array($ext, $allowed) && move_uploaded_file($fileTmp, $target)) {
                    $logoPath = "uploads/schools/" . $newName;
                } else {
                    $error = "Gagal mengunggah logo. Pastikan format gambar benar (jpg, png, gif).";
                }
            }

            // ============================================================
            // 💾 INSERT DATA
            // ============================================================
            if (empty($error)) {
                $stmt = $conn->prepare("
                    INSERT INTO schools (code, name, address, phone, email, headmaster, logo)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                ");
                $stmt->bind_param("sssssss", $code, $name, $address, $phone, $email, $headmaster, $logoPath);

                if ($stmt->execute()) {
                    $success = "Data sekolah berhasil ditambahkan.";
                } else {
                    $error = "Gagal menambah data sekolah.";
                }
            }
        }
    }
}
?>

<!-- ============================================================ -->
<!-- MAIN CONTENT -->
<!-- ============================================================ -->
<main id="mainContent" class="flex-grow-1 p-4">
  <div class="container-fluid" style="max-width:800px;">
    <div class="d-flex justify-content-between align-items-center mb-3">
      <h4 class="text-primary mb-0"><i class="bi bi-plus-circle me-2"></i> Tambah Sekolah</h4>
      <a href="schools.php" class="btn btn-secondary btn-sm"><i class="bi bi-arrow-left"></i> Kembali</a>
    </div>

    <?php if (!empty($error)): ?>
      <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
    <?php if (!empty($success)): ?>
      <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
    <?php endif; ?>

    <div class="card shadow-sm border-0">
      <div class="card-body">
        <form method="POST" enctype="multipart/form-data" class="needs-validation" novalidate>
          <div class="row">
            <div class="col-md-4 mb-3">
              <label class="form-label fw-semibold">Kode Sekolah <span class="text-danger">*</span></label>
              <input type="text" name="code" class="form-control" placeholder="Misal: SMP01" required>
            </div>
            <div class="col-md-8 mb-3">
              <label class="form-label fw-semibold">Nama Sekolah <span class="text-danger">*</span></label>
              <input type="text" name="name" class="form-control" placeholder="Nama lengkap sekolah" required>
            </div>
          </div>

          <div class="mb-3">
            <label class="form-label fw-semibold">Alamat</label>
            <textarea name="address" class="form-control" rows="2"></textarea>
          </div>

          <div class="row">
            <div class="col-md-6 mb-3">
              <label class="form-label fw-semibold">Telepon</label>
              <input type="text" name="phone" class="form-control">
            </div>
            <div class="col-md-6 mb-3">
              <label class="form-label fw-semibold">Email</label>
              <input type="email" name="email" class="form-control">
            </div>
          </div>

          <div class="mb-3">
            <label class="form-label fw-semibold">Kepala Sekolah</label>
            <input type="text" name="headmaster" class="form-control">
          </div>

          <div class="mb-3">
            <label class="form-label fw-semibold">Logo Sekolah</label>
            <input type="file" name="logo" accept=".jpg,.jpeg,.png,.gif" class="form-control">
            <div class="form-text text-muted">Format: JPG, PNG, GIF. Maksimal 2MB.</div>
          </div>

          <div class="text-end">
            <button type="submit" class="btn btn-primary"><i class="bi bi-save me-1"></i> Simpan</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</main>

<?php require_once __DIR__ . "/../includes/footer.php"; ?>
