<?php
// ============================================================
// LENTERA LIBRARY SYSTEM – SCHOOLS EDIT (ADMIN MASTER + LOGO UPLOAD)
// ============================================================

$pageTitle = "Edit Sekolah";

if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . "/../config/session_guard.php";
require_once __DIR__ . "/../config/db_config.php";
require_once __DIR__ . "/../includes/header.php";
require_once __DIR__ . "/../includes/sidebar.php";
require_once __DIR__ . "/../includes/topbar.php";

$conn = db();
if ($_SESSION['user_type'] !== 'admin') {
    header("Location: ../dashboard.php");
    exit;
}

$id = (int)($_GET["id"] ?? 0);
if ($id <= 0) die("ID tidak valid.");

// ============================================================
// 🔍 Ambil data sekolah
// ============================================================
$stmt = $conn->prepare("SELECT * FROM schools WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$data = $stmt->get_result()->fetch_assoc();
if (!$data) die("Data sekolah tidak ditemukan.");

// ============================================================
// 💾 PROSES UPDATE
// ============================================================
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name       = trim($_POST["name"] ?? "");
    $address    = trim($_POST["address"] ?? "");
    $phone      = trim($_POST["phone"] ?? "");
    $email      = trim($_POST["email"] ?? "");
    $headmaster = trim($_POST["headmaster"] ?? "");
    $deleteLogo = isset($_POST["delete_logo"]);
    $logoPath   = $data["logo"];

    if ($name === "") {
        $error = "Nama sekolah wajib diisi.";
    } else {
        // ============================================================
        // 🖼️ Upload Logo Baru (jika ada)
        // ============================================================
        if (!empty($_FILES['logo']['name'])) {
            $uploadDir = __DIR__ . "/../uploads/schools/";
            if (!is_dir($uploadDir)) mkdir($uploadDir, 0777, true);

            $fileTmp  = $_FILES['logo']['tmp_name'];
            $fileName = basename($_FILES['logo']['name']);
            $ext      = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
            $newName  = "logo_" . preg_replace('/[^a-zA-Z0-9]/', '', $data['code']) . "_" . time() . "." . $ext;
            $target   = $uploadDir . $newName;

            $allowed = ['jpg', 'jpeg', 'png', 'gif'];
            if (in_array($ext, $allowed)) {
                if (move_uploaded_file($fileTmp, $target)) {
                    // Hapus logo lama jika ada
                    if (!empty($data['logo']) && file_exists(__DIR__ . "/../" . $data['logo'])) {
                        unlink(__DIR__ . "/../" . $data['logo']);
                    }
                    $logoPath = "uploads/schools/" . $newName;
                } else {
                    $error = "Gagal mengunggah file logo.";
                }
            } else {
                $error = "Format logo tidak valid. Gunakan JPG, PNG, atau GIF.";
            }
        } elseif ($deleteLogo) {
            // ============================================================
            // 🗑️ Hapus Logo Lama
            // ============================================================
            if (!empty($data['logo']) && file_exists(__DIR__ . "/../" . $data['logo'])) {
                unlink(__DIR__ . "/../" . $data['logo']);
            }
            $logoPath = null;
        }

        // ============================================================
        // 💾 Update ke Database
        // ============================================================
        if (empty($error)) {
            $stmtUpd = $conn->prepare("
                UPDATE schools
                SET name=?, address=?, phone=?, email=?, headmaster=?, logo=?
                WHERE id=?
            ");
            $stmtUpd->bind_param("ssssssi", $name, $address, $phone, $email, $headmaster, $logoPath, $id);

            if ($stmtUpd->execute()) {
                $success = "Data sekolah berhasil diperbarui.";
                // Refresh data agar tampilan ikut berubah
                $stmt = $conn->prepare("SELECT * FROM schools WHERE id = ?");
                $stmt->bind_param("i", $id);
                $stmt->execute();
                $data = $stmt->get_result()->fetch_assoc();
            } else {
                $error = "Gagal memperbarui data sekolah.";
            }
        }
    }
}
?>

<!-- ============================================================ -->
<!-- MAIN CONTENT -->
<!-- ============================================================ -->
<main id="mainContent" class="flex-grow-1 p-4">
  <div class="container-fluid" style="max-width:800px;">
    <div class="d-flex justify-content-between align-items-center mb-3">
      <h4 class="text-primary mb-0"><i class="bi bi-pencil-square me-2"></i> Edit Sekolah</h4>
      <a href="schools.php" class="btn btn-secondary btn-sm"><i class="bi bi-arrow-left"></i> Kembali</a>
    </div>

    <?php if (!empty($error)): ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>
    <?php if (!empty($success)): ?><div class="alert alert-success"><?= htmlspecialchars($success) ?></div><?php endif; ?>

    <div class="card shadow-sm border-0">
      <div class="card-body">
        <form method="POST" enctype="multipart/form-data">
          <div class="mb-3">
            <label class="form-label fw-semibold">Kode Sekolah</label>
            <input type="text" class="form-control" value="<?= htmlspecialchars($data['code']) ?>" disabled>
          </div>

          <div class="mb-3">
            <label class="form-label fw-semibold">Nama Sekolah</label>
            <input type="text" name="name" class="form-control" value="<?= htmlspecialchars($data['name']) ?>" required>
          </div>

          <div class="mb-3">
            <label class="form-label fw-semibold">Alamat</label>
            <textarea name="address" class="form-control" rows="2"><?= htmlspecialchars($data['address']) ?></textarea>
          </div>

          <div class="row">
            <div class="col-md-6 mb-3">
              <label class="form-label fw-semibold">Telepon</label>
              <input type="text" name="phone" class="form-control" value="<?= htmlspecialchars($data['phone']) ?>">
            </div>
            <div class="col-md-6 mb-3">
              <label class="form-label fw-semibold">Email</label>
              <input type="email" name="email" class="form-control" value="<?= htmlspecialchars($data['email']) ?>">
            </div>
          </div>

          <div class="mb-3">
            <label class="form-label fw-semibold">Kepala Sekolah</label>
            <input type="text" name="headmaster" class="form-control" value="<?= htmlspecialchars($data['headmaster']) ?>">
          </div>

          <!-- ============================================================ -->
          <!-- 🖼️ LOGO SEKOLAH -->
          <!-- ============================================================ -->
          <div class="mb-3">
            <label class="form-label fw-semibold">Logo Sekolah</label>
            <?php if (!empty($data['logo']) && file_exists(__DIR__ . "/../" . $data['logo'])): ?>
              <div class="mb-2">
                <img src="../<?= htmlspecialchars($data['logo']) ?>" alt="Logo Sekolah" class="border rounded shadow-sm" style="max-height:100px;">
              </div>
              <div class="form-check mb-2">
                <input class="form-check-input" type="checkbox" name="delete_logo" id="delete_logo">
                <label class="form-check-label" for="delete_logo">Hapus logo ini</label>
              </div>
            <?php endif; ?>
            <input type="file" name="logo" accept=".jpg,.jpeg,.png,.gif" class="form-control">
            <div class="form-text text-muted">Biarkan kosong jika tidak ingin mengubah logo. Format: JPG, PNG, GIF.</div>
          </div>

          <div class="text-end">
            <button type="submit" class="btn btn-primary"><i class="bi bi-save me-1"></i> Simpan Perubahan</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</main>

<?php require_once __DIR__ . "/../includes/footer.php"; ?>
