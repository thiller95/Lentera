<?php
// ============================================================
// LENTERA LIBRARY SYSTEM – DOC NUMBERING (ADMIN ONLY - FINAL CLEAN RESPONSIVE)
// ============================================================

$pageTitle = "Penomoran Dokumen";

if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . "/../config/session_guard.php";
require_once __DIR__ . "/../config/db_config.php";
require_once __DIR__ . "/../includes/header.php";
require_once __DIR__ . "/../includes/sidebar.php";
require_once __DIR__ . "/../includes/topbar.php";

$conn = db();
$school_id = $_SESSION['school_id'] ?? 0;

// ============================================================
// 🔒 VALIDASI HAK AKSES
// ============================================================
if ($_SESSION['user_type'] !== 'admin') {
    header("Location: ../dashboard.php");
    exit;
}

if ($school_id <= 0) {
    die("<div style='margin:40px;color:red;font-weight:bold'>
        ❌ Data sekolah tidak ditemukan di sesi login. Silakan login ulang.
    </div>");
}
?>

<!-- ============================================================ -->
<!-- MAIN CONTENT AREA -->
<!-- ============================================================ -->
<main id="mainContent" class="flex-grow-1 p-4">
  <div class="container-fluid">

    <!-- Header -->
    <div class="d-flex justify-content-between align-items-center mb-3">
      <h4 class="text-primary mb-0">
        <i class="bi bi-hash me-2"></i> Penomoran Dokumen
      </h4>
      <a href="doc-numbering-create.php" class="btn btn-primary btn-sm">
        <i class="bi bi-plus-lg"></i> Tambah Konfigurasi
      </a>
    </div>

    <!-- Card -->
    <div class="card shadow-sm border-0">
      <div class="card-body">
        <div class="table-responsive">
          <table id="docNumberTable" class="table table-bordered align-middle table-hover w-100">
            <thead class="table-light">
              <tr>
                <th width="50">No</th>
                <th>Kode Modul</th>
                <th>Prefix</th>
                <th>Format</th>
                <th>Panjang Digit</th>
                <th>Auto Reset</th>
                <th>Terakhir Digunakan</th>
                <th width="100">Aksi</th>
              </tr>
            </thead>
            <tbody>
              <?php
              $sql = "
                SELECT *
                FROM doc_numbering
                WHERE school_id = $school_id
                ORDER BY module_code ASC
              ";
              $res = $conn->query($sql);
              $no = 1;

              if ($res && $res->num_rows > 0):
                while ($row = $res->fetch_assoc()):
              ?>
              <tr>
                <td><?= $no++ ?></td>
                <td><strong><?= htmlspecialchars($row['module_code']) ?></strong></td>
                <td><?= htmlspecialchars($row['prefix']) ?></td>
                <td class="text-muted"><?= htmlspecialchars($row['format_pattern']) ?></td>
                <td class="text-center"><?= (int)$row['pad_length'] ?></td>
                <td class="text-capitalize text-center"><?= htmlspecialchars($row['auto_reset']) ?></td>
                <td class="text-center">
                  <?= $row['last_year'] && $row['last_month']
                        ? "{$row['last_year']}/" . str_pad($row['last_month'], 2, '0', STR_PAD_LEFT) . " (#{$row['last_number']})"
                        : "-" ?>
                </td>
                <td class="text-center">
                  <a href="doc-numbering-edit.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-outline-primary me-1" title="Edit Konfigurasi">
                    <i class="bi bi-pencil-square"></i>
                  </a>
                  <button class="btn btn-sm btn-outline-danger btn-delete"
                          data-id="<?= $row['id'] ?>"
                          data-code="<?= htmlspecialchars($row['module_code']) ?>"
                          title="Hapus Konfigurasi">
                    <i class="bi bi-trash"></i>
                  </button>
                </td>
              </tr>
              <?php
                endwhile;
              else:
              ?>
              <tr>
                <td colspan="8" class="text-center text-muted">Belum ada konfigurasi penomoran dokumen.</td>
              </tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>

  </div>
</main>

<?php require_once __DIR__ . "/../includes/footer.php"; ?>

<!-- ============================================================ -->
<!-- DATATABLES (LOCAL MODE) -->
<!-- ============================================================ -->
<link rel="stylesheet" href="../assets/css/dataTables.bootstrap5.min.css">
<script src="../assets/js/jquery.dataTables.min.js"></script>
<script src="../assets/js/dataTables.bootstrap5.min.js"></script>

<!-- ============================================================ -->
<!-- CUSTOM SCRIPT -->
<!-- ============================================================ -->
<script>
$(document).ready(function() {

  // ===============================
  // 📊 Inisialisasi DataTables
  // ===============================
  const table = $('#docNumberTable').DataTable({
    responsive: true,
    autoWidth: false,
    pageLength: 10,
    language: {
      url: "../assets/lang/indonesian.json"
    }
  });

  // ===============================
  // 🗑️ Aksi Hapus Konfigurasi
  // ===============================
  $(".btn-delete").on("click", function() {
    const id = $(this).data("id");
    const code = $(this).data("code");

    confirmAction(`Apakah Anda yakin ingin menghapus konfigurasi "${code}"?`, function() {
      $.ajax({
        url: "doc-numbering-delete.php",
        type: "POST",
        data: { id },
        success: function(res) {
          try {
            const data = JSON.parse(res);
            if (data.status === "success") {
              toast("✅ Konfigurasi berhasil dihapus");
              setTimeout(() => location.reload(), 1000);
            } else {
              alertError(data.message || "Gagal menghapus konfigurasi");
            }
          } catch {
            alertError("Terjadi kesalahan pada server.");
          }
        },
        error: () => alertError("Gagal terhubung ke server.")
      });
    });
  });

  // ===============================
  // 🔄 Sinkronisasi margin MainContent
  // ===============================
  function adjustMargin() {
    const size = localStorage.getItem('sidebar-size') || 'lg';
    $('#mainContent').css('margin-left', size === 'sm' ? '70px' : '250px');
  }
  adjustMargin();

  // ===============================
  // 🧩 ResizeObserver untuk auto adjust DataTables (FIXED)
  // ===============================
  const observer = new ResizeObserver(() => {
    if (table && table.columns && table.responsive) {
      try {
        table.columns.adjust();
        if (table.responsive.recalc) table.responsive.recalc();
      } catch (err) {
        console.warn("⚠️ ResizeObserver skipped:", err.message);
      }
    }
  });
  const mainContent = document.getElementById('mainContent');
  if (mainContent) observer.observe(mainContent);

  // ===============================
  // 📢 Event Listener Sidebar Toggle
  // ===============================
  window.addEventListener('sidebar:changed', () => {
    adjustMargin();
    setTimeout(() => {
      if (table && table.columns && table.responsive) {
        table.columns.adjust();
        if (table.responsive.recalc) table.responsive.recalc();
      }
    }, 400);
  });

  // Fallback jika berubah dari tab lain
  window.addEventListener('storage', e => {
    if (e.key === 'sidebar-size') {
      adjustMargin();
      setTimeout(() => {
        if (table && table.columns && table.responsive) {
          table.columns.adjust();
          if (table.responsive.recalc) table.responsive.recalc();
        }
      }, 400);
    }
  });
});
</script>
