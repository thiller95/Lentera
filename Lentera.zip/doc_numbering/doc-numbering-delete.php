<?php
// ============================================================
// LENTERA LIBRARY SYSTEM – DOC NUMBERING DELETE (AJAX)
// ============================================================

if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . "/config/session_guard.php";
require_once __DIR__ . "/config/db_config.php";

header("Content-Type: application/json; charset=UTF-8");

$conn = db();
$school_id = $_SESSION['school_id'] ?? 0;

// ============================================================
// 🔒 Validasi Hak Akses
// ============================================================
if ($_SESSION['user_type'] !== 'admin') {
    echo json_encode([
        "status" => "error",
        "message" => "Akses ditolak. Hanya admin yang dapat menghapus data."
    ]);
    exit;
}

// ============================================================
// 🧩 Validasi Input
// ============================================================
$id = isset($_POST['id']) ? (int)$_POST['id'] : 0;

if ($id <= 0 || $school_id <= 0) {
    echo json_encode([
        "status" => "error",
        "message" => "Parameter tidak valid."
    ]);
    exit;
}

// ============================================================
// 🔍 Cek Data
// ============================================================
$stmt = $conn->prepare("SELECT * FROM doc_numbering WHERE id = ? AND school_id = ?");
$stmt->bind_param("ii", $id, $school_id);
$stmt->execute();
$res = $stmt->get_result();
$data = $res->fetch_assoc();

if (!$data) {
    echo json_encode([
        "status" => "error",
        "message" => "Data tidak ditemukan atau bukan milik sekolah ini."
    ]);
    exit;
}

// ============================================================
// 🗑️ Hapus Data
// ============================================================
$stmtDel = $conn->prepare("DELETE FROM doc_numbering WHERE id = ? AND school_id = ?");
$stmtDel->bind_param("ii", $id, $school_id);

if ($stmtDel->execute()) {

    // ========================================================
    // ✍️ Tambahkan ke activity_logs
    // ========================================================
    $action = "delete_doc_numbering";
    $desc = "Hapus konfigurasi penomoran: " . $data['module_code'];
    $stmtLog = $conn->prepare("
        INSERT INTO activity_logs (school_id, user_type, user_id, action, description)
        VALUES (?, 'admin', ?, ?, ?)
    ");
    $stmtLog->bind_param("iiss", $school_id, $_SESSION['user_id'], $action, $desc);
    $stmtLog->execute();

    echo json_encode([
        "status" => "success",
        "message" => "Konfigurasi penomoran berhasil dihapus."
    ]);
} else {
    echo json_encode([
        "status" => "error",
        "message" => "Gagal menghapus data: " . $conn->error
    ]);
}
?>
