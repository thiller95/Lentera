<?php
// ============================================================
// LENTERA LIBRARY SYSTEM – DOC NUMBERING CREATE (ADMIN ONLY)
// ============================================================

$pageTitle = "Tambah Penomoran Dokumen";

if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . "/../config/session_guard.php";
require_once __DIR__ . "/../config/db_config.php";
require_once __DIR__ . "/../includes/header.php";
require_once __DIR__ . "/../includes/sidebar.php";
require_once __DIR__ . "/../includes/topbar.php";

$conn = db();
$school_id = $_SESSION['school_id'] ?? 0;

// Pastikan hanya admin yang boleh akses
if ($_SESSION['user_type'] !== 'admin') {
    header("Location: ../dashboard.php");
    exit;
}

// Jika school_id belum terisi
if ($school_id <= 0) {
    die("<div style='margin:40px;color:red;font-weight:bold'>
        ❌ Data sekolah tidak ditemukan di sesi login. Silakan login ulang.
    </div>");
}

// ============================================================
// PROSES SUBMIT FORM
// ============================================================
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $module_code   = trim($_POST["module_code"] ?? "");
    $prefix        = trim($_POST["prefix"] ?? "");
    $format_pattern = trim($_POST["format_pattern"] ?? "{PREFIX}/{YEAR}/{MONTH}/{NUM}");
    $pad_length    = (int)($_POST["pad_length"] ?? 4);
    $auto_reset    = trim($_POST["auto_reset"] ?? "monthly");

    if ($module_code === "" || $prefix === "") {
        $error = "Kode Modul dan Prefix wajib diisi.";
    } else {
        // Cek duplikat
        $stmt = $conn->prepare("SELECT id FROM doc_numbering WHERE school_id = ? AND module_code = ?");
        $stmt->bind_param("is", $school_id, $module_code);
        $stmt->execute();
        $res = $stmt->get_result();

        if ($res && $res->num_rows > 0) {
            $error = "Kode modul sudah ada. Gunakan kode lain.";
        } else {
            $stmt = $conn->prepare("
                INSERT INTO doc_numbering 
                    (school_id, module_code, prefix, format_pattern, pad_length, auto_reset, last_number, last_year, last_month)
                VALUES (?, ?, ?, ?, ?, ?, 0, YEAR(CURDATE()), MONTH(CURDATE()))
            ");
            $stmt->bind_param("isssis", $school_id, $module_code, $prefix, $format_pattern, $pad_length, $auto_reset);
            if ($stmt->execute()) {
                $success = "Konfigurasi penomoran berhasil ditambahkan.";
            } else {
                $error = "Gagal menyimpan data. " . $conn->error;
            }
        }
    }
}
?>

<!-- ============================================================ -->
<!-- MAIN CONTENT AREA -->
<!-- ============================================================ -->
<main id="mainContent" class="flex-grow-1 p-4">
  <div class="container-fluid" style="max-width: 800px;">

    <!-- Header -->
    <div class="d-flex justify-content-between align-items-center mb-3">
      <h4 class="text-primary mb-0">
        <i class="bi bi-plus-circle me-2"></i> Tambah Penomoran Dokumen
      </h4>
      <a href="doc-numbering.php" class="btn btn-secondary btn-sm">
        <i class="bi bi-arrow-left"></i> Kembali
      </a>
    </div>

    <!-- Alert -->
    <?php if (!empty($error)): ?>
      <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php elseif (!empty($success)): ?>
      <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
    <?php endif; ?>

    <!-- Card -->
    <div class="card shadow-sm border-0">
      <div class="card-body">
        <form method="POST" class="needs-validation" novalidate>

          <div class="mb-3">
            <label class="form-label fw-semibold">Kode Modul <span class="text-danger">*</span></label>
            <input type="text" name="module_code" class="form-control" placeholder="Misal: BOOK_LOAN, BOOK_RETURN" required>
            <div class="form-text">Kode unik modul. Misal untuk peminjaman buku: <code>BOOK_LOAN</code></div>
          </div>

          <div class="mb-3">
            <label class="form-label fw-semibold">Prefix <span class="text-danger">*</span></label>
            <input type="text" name="prefix" class="form-control" placeholder="Misal: LOAN atau RTRN" required>
            <div class="form-text">Prefix muncul di awal nomor dokumen.</div>
          </div>

          <div class="mb-3">
            <label class="form-label fw-semibold">Format Nomor</label>
            <input type="text" name="format_pattern" class="form-control" 
                   value="{PREFIX}/{YEAR}/{MONTH}/{NUM}">
            <div class="form-text">
              Gunakan token:
              <code>{PREFIX}</code>, <code>{YEAR}</code>, <code>{MONTH}</code>, <code>{NUM}</code>
            </div>
          </div>

          <div class="row">
            <div class="col-md-6 mb-3">
              <label class="form-label fw-semibold">Panjang Digit Angka</label>
              <input type="number" name="pad_length" class="form-control" value="4" min="1" max="10">
            </div>
            <div class="col-md-6 mb-3">
              <label class="form-label fw-semibold">Auto Reset</label>
              <select name="auto_reset" class="form-select">
                <option value="monthly">Bulanan</option>
                <option value="yearly">Tahunan</option>
                <option value="none">Tidak Pernah Reset</option>
              </select>
            </div>
          </div>

          <div class="d-flex justify-content-end mt-4">
            <button type="submit" class="btn btn-primary">
              <i class="bi bi-save me-1"></i> Simpan
            </button>
          </div>
        </form>
      </div>
    </div>

  </div>
</main>

<?php require_once __DIR__ . "/../includes/footer.php"; ?>

<!-- ============================================================ -->
<!-- FORM VALIDATION -->
<!-- ============================================================ -->
<script>
(() => {
  'use strict';
  const forms = document.querySelectorAll('.needs-validation');
  Array.from(forms).forEach(form => {
    form.addEventListener('submit', event => {
      if (!form.checkValidity()) {
        event.preventDefault();
        event.stopPropagation();
      }
      form.classList.add('was-validated');
    }, false);
  });
})();
</script>
