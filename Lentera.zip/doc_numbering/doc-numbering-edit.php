<?php
// ============================================================
// LENTERA LIBRARY SYSTEM – DOC NUMBERING EDIT (ADMIN ONLY)
// ============================================================

$pageTitle = "Edit Penomoran Dokumen";

if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . "/../config/session_guard.php";
require_once __DIR__ . "/../config/db_config.php";
require_once __DIR__ . "/../includes/header.php";
require_once __DIR__ . "/../includes/sidebar.php";
require_once __DIR__ . "/../includes/topbar.php";

$conn = db();
$school_id = $_SESSION['school_id'] ?? 0;

// ============================================================
// 🔒 HAK AKSES DAN VALIDASI
// ============================================================
if ($_SESSION['user_type'] !== 'admin') {
    header("Location: /../dashboard.php");
    exit;
}

if (empty($school_id)) {
    die("<div style='margin:40px;color:red;font-weight:bold'>
        ❌ Data sekolah tidak ditemukan di sesi login. Silakan login ulang.
    </div>");
}

$id = (int)($_GET["id"] ?? 0);
if ($id <= 0) {
    die("<div style='margin:40px;color:red;font-weight:bold'>
        ⚠️ ID konfigurasi tidak valid.
    </div>");
}

// ============================================================
// 🔍 AMBIL DATA
// ============================================================
$stmt = $conn->prepare("SELECT * FROM doc_numbering WHERE id = ? AND school_id = ?");
$stmt->bind_param("ii", $id, $school_id);
$stmt->execute();
$res = $stmt->get_result();
$data = $res->fetch_assoc();

if (!$data) {
    die("<div style='margin:40px;color:red;font-weight:bold'>
        ⚠️ Data tidak ditemukan atau bukan milik sekolah ini.
    </div>");
}

// ============================================================
// 💾 PROSES UPDATE
// ============================================================
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $prefix         = trim($_POST["prefix"] ?? "");
    $format_pattern = trim($_POST["format_pattern"] ?? "{PREFIX}/{YEAR}/{MONTH}/{NUM}");
    $pad_length     = (int)($_POST["pad_length"] ?? 4);
    $auto_reset     = trim($_POST["auto_reset"] ?? "monthly");

    if ($prefix === "") {
        $error = "Prefix wajib diisi.";
    } else {
        $stmtUpdate = $conn->prepare("
            UPDATE doc_numbering 
            SET prefix = ?, format_pattern = ?, pad_length = ?, auto_reset = ?
            WHERE id = ? AND school_id = ?
        ");
        // ✅ perbaikan di sini: "sssiii"
        $stmtUpdate->bind_param("ssisis", $prefix, $format_pattern, $pad_length, $auto_reset, $id, $school_id);

        if ($stmtUpdate->execute()) {
            $success = "Konfigurasi berhasil diperbarui.";

            // refresh data setelah update
            $stmt = $conn->prepare("SELECT * FROM doc_numbering WHERE id = ? AND school_id = ?");
            $stmt->bind_param("ii", $id, $school_id);
            $stmt->execute();
            $data = $stmt->get_result()->fetch_assoc();
        } else {
            $error = "Gagal memperbarui data: " . $conn->error;
        }
    }
}
?>

<!-- ============================================================ -->
<!-- MAIN CONTENT AREA -->
<!-- ============================================================ -->
<main id="mainContent" class="flex-grow-1 p-4">
  <div class="container-fluid" style="max-width: 800px;">

    <!-- Header -->
    <div class="d-flex justify-content-between align-items-center mb-3">
      <h4 class="text-primary mb-0">
        <i class="bi bi-pencil-square me-2"></i> Edit Penomoran Dokumen
      </h4>
      <a href="doc-numbering.php" class="btn btn-secondary btn-sm">
        <i class="bi bi-arrow-left"></i> Kembali
      </a>
    </div>

    <!-- Alert -->
    <?php if (!empty($error)): ?>
      <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php elseif (!empty($success)): ?>
      <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
    <?php endif; ?>

    <!-- Card -->
    <div class="card shadow-sm border-0">
      <div class="card-body">
        <form method="POST" class="needs-validation" novalidate>

          <div class="mb-3">
            <label class="form-label fw-semibold">Kode Modul</label>
            <input type="text" class="form-control" value="<?= htmlspecialchars($data['module_code']) ?>" disabled>
            <div class="form-text text-muted">Kode modul tidak dapat diubah.</div>
          </div>

          <div class="mb-3">
            <label class="form-label fw-semibold">Prefix <span class="text-danger">*</span></label>
            <input type="text" name="prefix" class="form-control" 
                   value="<?= htmlspecialchars($data['prefix']) ?>" required>
          </div>

          <div class="mb-3">
            <label class="form-label fw-semibold">Format Nomor</label>
            <input type="text" name="format_pattern" class="form-control" 
                   value="<?= htmlspecialchars($data['format_pattern']) ?>">
            <div class="form-text">
              Gunakan token:
              <code>{PREFIX}</code>, <code>{YEAR}</code>, <code>{MONTH}</code>, <code>{NUM}</code>
            </div>
          </div>

          <div class="row">
            <div class="col-md-6 mb-3">
              <label class="form-label fw-semibold">Panjang Digit Angka</label>
              <input type="number" name="pad_length" class="form-control" 
                     value="<?= (int)$data['pad_length'] ?>" min="1" max="10">
            </div>
            <div class="col-md-6 mb-3">
              <label class="form-label fw-semibold">Auto Reset</label>
              <select name="auto_reset" class="form-select">
                <option value="monthly" <?= $data['auto_reset'] === 'monthly' ? 'selected' : '' ?>>Bulanan</option>
                <option value="yearly" <?= $data['auto_reset'] === 'yearly' ? 'selected' : '' ?>>Tahunan</option>
                <option value="none" <?= $data['auto_reset'] === 'none' ? 'selected' : '' ?>>Tidak Pernah Reset</option>
              </select>
            </div>
          </div>

          <div class="mt-4 d-flex justify-content-end">
            <button type="submit" class="btn btn-primary">
              <i class="bi bi-save me-1"></i> Simpan Perubahan
            </button>
          </div>

        </form>
      </div>
    </div>

  </div>
</main>

<?php require_once __DIR__ . "/../includes/footer.php"; ?>

<!-- ============================================================ -->
<!-- FORM VALIDATION -->
<!-- ============================================================ -->
<script>
(() => {
  'use strict';
  const forms = document.querySelectorAll('.needs-validation');
  Array.from(forms).forEach(form => {
    form.addEventListener('submit', event => {
      if (!form.checkValidity()) {
        event.preventDefault();
        event.stopPropagation();
      }
      form.classList.add('was-validated');
    }, false);
  });
})();
</script>
