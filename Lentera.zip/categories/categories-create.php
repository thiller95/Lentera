<?php
// ============================================================
// LENTERA LIBRARY SYSTEM – CATEGORIES CREATE (ADMIN ONLY)
// ============================================================

$pageTitle = "Tambah Kategori";

if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . "/../config/session_guard.php";
require_once __DIR__ . "/../config/db_config.php";
require_once __DIR__ . "/../includes/header.php";
require_once __DIR__ . "/../includes/sidebar.php";
require_once __DIR__ . "/../includes/topbar.php";

$conn = db();
$school_id = $_SESSION['school_id'] ?? 0;

// Pastikan hanya admin
if ($_SESSION['user_type'] !== 'admin') {
    header("Location: ../dashboard.php");
    exit;
}

// Cek sesi sekolah
if ($school_id <= 0) {
    die("<div style='margin:40px;color:red;font-weight:bold'>
        ❌ Data sekolah tidak ditemukan di sesi login. Silakan login ulang.
    </div>");
}

// ============================================================
// 🧾 PROSES SIMPAN DATA
// ============================================================
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name = trim($_POST['name'] ?? '');
    $desc = trim($_POST['description'] ?? '');

    if ($name === "") {
        $error = "Nama kategori wajib diisi.";
    } else {
        // Cek duplikat kategori di sekolah yang sama
        $stmt = $conn->prepare("SELECT id FROM categories WHERE school_id = ? AND name = ?");
        $stmt->bind_param("is", $school_id, $name);
        $stmt->execute();
        $res = $stmt->get_result();

        if ($res && $res->num_rows > 0) {
            $error = "Kategori dengan nama tersebut sudah ada.";
        } else {
            $stmt = $conn->prepare("INSERT INTO categories (school_id, name, description) VALUES (?, ?, ?)");
            $stmt->bind_param("iss", $school_id, $name, $desc);
            if ($stmt->execute()) {
                $success = "Kategori berhasil ditambahkan.";
            } else {
                $error = "Gagal menyimpan data kategori: " . $conn->error;
            }
        }
    }
}
?>

<!-- ============================================================ -->
<!-- MAIN CONTENT AREA -->
<!-- ============================================================ -->
<main id="mainContent" class="flex-grow-1 p-4">
  <div class="container-fluid" style="max-width:700px;">

    <!-- Header -->
    <div class="d-flex justify-content-between align-items-center mb-3">
      <h4 class="text-primary mb-0">
        <i class="bi bi-plus-circle me-2"></i> Tambah Kategori Buku
      </h4>
      <a href="categories.php" class="btn btn-secondary btn-sm">
        <i class="bi bi-arrow-left"></i> Kembali
      </a>
    </div>

    <!-- Alert -->
    <?php if (!empty($error)): ?>
      <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php elseif (!empty($success)): ?>
      <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
    <?php endif; ?>

    <!-- Card -->
    <div class="card shadow-sm border-0">
      <div class="card-body">
        <form method="POST" class="needs-validation" novalidate>
          <div class="mb-3">
            <label class="form-label fw-semibold">Nama Kategori <span class="text-danger">*</span></label>
            <input type="text" name="name" class="form-control" placeholder="Misal: Novel, Pelajaran, Komik" required>
          </div>

          <div class="mb-3">
            <label class="form-label fw-semibold">Deskripsi</label>
            <textarea name="description" class="form-control" rows="3" placeholder="Keterangan kategori (opsional)"></textarea>
          </div>

          <div class="d-flex justify-content-end">
            <button type="submit" class="btn btn-primary">
              <i class="bi bi-save me-1"></i> Simpan
            </button>
          </div>
        </form>
      </div>
    </div>

  </div>
</main>

<?php require_once __DIR__ . "/../includes/footer.php"; ?>

<!-- ============================================================ -->
<!-- FORM VALIDATION -->
<!-- ============================================================ -->
<script>
(() => {
  'use strict';
  const forms = document.querySelectorAll('.needs-validation');
  Array.from(forms).forEach(form => {
    form.addEventListener('submit', event => {
      if (!form.checkValidity()) {
        event.preventDefault();
        event.stopPropagation();
      }
      form.classList.add('was-validated');
    }, false);
  });
})();
</script>
