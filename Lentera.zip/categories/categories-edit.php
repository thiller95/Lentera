<?php
// ============================================================
// LENTERA LIBRARY SYSTEM – CATEGORIES EDIT (ADMIN ONLY)
// ============================================================

$pageTitle = "Edit Kategori";

if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . "/../config/session_guard.php";
require_once __DIR__ . "/../config/db_config.php";
require_once __DIR__ . "/../includes/header.php";
require_once __DIR__ . "/../includes/sidebar.php";
require_once __DIR__ . "/../includes/topbar.php";

$conn = db();
$school_id = $_SESSION['school_id'] ?? 0;

// Pastikan hanya admin
if ($_SESSION['user_type'] !== 'admin') {
    header("Location: ../dashboard.php");
    exit;
}

if ($school_id <= 0) {
    die("<div style='margin:40px;color:red;font-weight:bold'>
        ❌ Data sekolah tidak ditemukan di sesi login. Silakan login ulang.
    </div>");
}

// ============================================================
// 🔍 Ambil Data
// ============================================================
$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
    die("<div style='margin:40px;color:red;font-weight:bold'>
        ⚠️ ID kategori tidak valid.
    </div>");
}

$stmt = $conn->prepare("SELECT * FROM categories WHERE id = ? AND school_id = ?");
$stmt->bind_param("ii", $id, $school_id);
$stmt->execute();
$res = $stmt->get_result();
$data = $res->fetch_assoc();

if (!$data) {
    die("<div style='margin:40px;color:red;font-weight:bold'>
        ⚠️ Data kategori tidak ditemukan.
    </div>");
}

// ============================================================
// 💾 Proses Update
// ============================================================
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name = trim($_POST['name'] ?? '');
    $desc = trim($_POST['description'] ?? '');

    if ($name === "") {
        $error = "Nama kategori wajib diisi.";
    } else {
        // Cek duplikat selain diri sendiri
        $stmtDup = $conn->prepare("SELECT id FROM categories WHERE school_id = ? AND name = ? AND id <> ?");
        $stmtDup->bind_param("isi", $school_id, $name, $id);
        $stmtDup->execute();
        $dup = $stmtDup->get_result();

        if ($dup && $dup->num_rows > 0) {
            $error = "Kategori dengan nama tersebut sudah ada.";
        } else {
            $stmtUpd = $conn->prepare("UPDATE categories SET name = ?, description = ? WHERE id = ? AND school_id = ?");
            $stmtUpd->bind_param("ssii", $name, $desc, $id, $school_id);
            if ($stmtUpd->execute()) {
                $success = "Kategori berhasil diperbarui.";
                $data['name'] = $name;
                $data['description'] = $desc;
            } else {
                $error = "Gagal memperbarui data kategori.";
            }
        }
    }
}
?>

<!-- ============================================================ -->
<!-- MAIN CONTENT AREA -->
<!-- ============================================================ -->
<main id="mainContent" class="flex-grow-1 p-4">
  <div class="container-fluid" style="max-width:700px;">
    <div class="d-flex justify-content-between align-items-center mb-3">
      <h4 class="text-primary mb-0"><i class="bi bi-pencil-square me-2"></i> Edit Kategori Buku</h4>
      <a href="categories.php" class="btn btn-secondary btn-sm"><i class="bi bi-arrow-left"></i> Kembali</a>
    </div>

    <?php if (!empty($error)): ?>
      <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php elseif (!empty($success)): ?>
      <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
    <?php endif; ?>

    <div class="card shadow-sm border-0">
      <div class="card-body">
        <form method="POST" class="needs-validation" novalidate>
          <div class="mb-3">
            <label class="form-label fw-semibold">Nama Kategori <span class="text-danger">*</span></label>
            <input type="text" name="name" class="form-control" 
                   value="<?= htmlspecialchars($data['name']) ?>" required>
          </div>

          <div class="mb-3">
            <label class="form-label fw-semibold">Deskripsi</label>
            <textarea name="description" class="form-control" rows="3"><?= htmlspecialchars($data['description'] ?? '') ?></textarea>
          </div>

          <div class="d-flex justify-content-end mt-3">
            <button type="submit" class="btn btn-primary">
              <i class="bi bi-save me-1"></i> Simpan Perubahan
            </button>
          </div>
        </form>
      </div>
    </div>
  </div>
</main>

<?php require_once __DIR__ . "/../includes/footer.php"; ?>

<!-- ============================================================ -->
<!-- FORM VALIDATION -->
<!-- ============================================================ -->
<script>
(() => {
  'use strict';
  const forms = document.querySelectorAll('.needs-validation');
  Array.from(forms).forEach(form => {
    form.addEventListener('submit', event => {
      if (!form.checkValidity()) {
        event.preventDefault();
        event.stopPropagation();
      }
      form.classList.add('was-validated');
    }, false);
  });
})();
</script>
