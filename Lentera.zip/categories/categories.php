<?php
// ============================================================
// LENTERA LIBRARY SYSTEM – CATEGORIES (LIST VIEW - FINAL FULL VERSION)
// ============================================================

$pageTitle = "Kategori Buku";

if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . "/../config/session_guard.php";
require_once __DIR__ . "/../config/db_config.php";
require_once __DIR__ . "/../includes/header.php";
require_once __DIR__ . "/../includes/sidebar.php";
require_once __DIR__ . "/../includes/topbar.php";

$conn = db();
$school_id = $_SESSION['school_id'] ?? 0;

if ($_SESSION['user_type'] !== 'admin') {
    header("Location: ../dashboard.php");
    exit;
}

if ($school_id <= 0) {
    die("<div style='margin:40px;color:red;font-weight:bold'>
        ❌ Data sekolah tidak ditemukan di sesi login. Silakan login ulang.
    </div>");
}
?>

<main id="mainContent" class="flex-grow-1 p-4">
  <div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-3">
      <h4 class="text-primary mb-0"><i class="bi bi-tags me-2"></i> Kategori Buku</h4>
      <a href="categories-create.php" class="btn btn-primary btn-sm"><i class="bi bi-plus-lg"></i> Tambah Kategori</a>
    </div>

    <div class="card shadow-sm border-0">
      <div class="card-body">
        <div class="table-responsive">
          <table id="categoriesTable" class="table table-bordered align-middle table-hover w-100">
            <thead class="table-light">
              <tr>
                <th width="50">No</th>
                <th>Nama Kategori</th>
                <th>Deskripsi</th>
                <th width="100">Aksi</th>
              </tr>
            </thead>
            <tbody>
              <?php
              $stmt = $conn->prepare("SELECT * FROM categories WHERE school_id = ? ORDER BY name ASC");
              $stmt->bind_param("i", $school_id);
              $stmt->execute();
              $res = $stmt->get_result();
              $no = 1;

              if ($res && $res->num_rows > 0):
                while ($row = $res->fetch_assoc()):
              ?>
              <tr>
                <td><?= $no++ ?></td>
                <td><?= htmlspecialchars($row['name']) ?></td>
                <td><?= htmlspecialchars($row['description'] ?? '-') ?></td>
                <td class="text-center">
                  <a href="categories-edit.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-outline-primary me-1" title="Edit Kategori"><i class="bi bi-pencil-square"></i></a>
                  <button class="btn btn-sm btn-outline-danger btn-delete"
                          data-id="<?= $row['id'] ?>"
                          data-name="<?= htmlspecialchars($row['name']) ?>"
                          title="Hapus Kategori">
                    <i class="bi bi-trash"></i>
                  </button>
                </td>
              </tr>
              <?php endwhile; else: ?>
              <tr><td colspan="4" class="text-center text-muted">Belum ada kategori.</td></tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</main>

<?php require_once __DIR__ . "/../includes/footer.php"; ?>

<link rel="stylesheet" href="../assets/css/dataTables.bootstrap5.min.css">
<script src="../assets/js/jquery.dataTables.min.js"></script>
<script src="../assets/js/dataTables.bootstrap5.min.js"></script>

<script>
$(document).ready(function() {
  const table = $('#categoriesTable').DataTable({
    responsive: true,
    autoWidth: false,
    language: { url: "../assets/lang/indonesian.json" }
  });

  $(".btn-delete").on("click", function() {
    const id = $(this).data("id");
    const name = $(this).data("name");
    confirmAction(`Apakah Anda yakin ingin menghapus kategori "${name}"?`, function() {
      $.ajax({
        url: "categories-delete.php",
        type: "POST",
        data: { id },
        success: function(res) {
          const data = JSON.parse(res);
          if (data.status === "success") {
            toast("Kategori berhasil dihapus");
            setTimeout(() => location.reload(), 1000);
          } else alertError(data.message);
        },
        error: () => alertError("Gagal menghubungi server.")
      });
    });
  });
});
</script>
