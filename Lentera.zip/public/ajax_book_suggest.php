<?php
// ============================================================
// LENTERA LIBRARY SYSTEM – AJAX BOOK AUTO-SUGGEST (WITH LOCATION - FINAL)
// ============================================================

require_once __DIR__ . "/../config/db_config.php";
header('Content-Type: application/json; charset=utf-8');

$conn = db();
$school_id = 1; // default school, ubah kalau multi sekolah

// ============================================================
// INPUT VALIDATION
// ============================================================
$q = trim($_GET['q'] ?? '');
if ($q === '') {
    echo json_encode([]);
    exit;
}

// ============================================================
// FLEXIBLE SEARCH QUERY + LOKASI BUKU
// ============================================================
$like = '%' . $q . '%';
$sql = "
  SELECT b.title, b.author, b.publisher, b.isbn,
         l.name AS location_name, l.room AS location_room
  FROM books b
  LEFT JOIN book_locations l ON l.id = b.location_id
  WHERE b.school_id = ?
    AND (
        b.title LIKE ? 
        OR b.author LIKE ? 
        OR b.publisher LIKE ? 
        OR b.isbn LIKE ?
    )
  ORDER BY b.title ASC
  LIMIT 10
";

$stmt = $conn->prepare($sql);
$stmt->bind_param("issss", $school_id, $like, $like, $like, $like);
$stmt->execute();
$res = $stmt->get_result();

// ============================================================
// OUTPUT JSON
// ============================================================
$suggestions = [];
while ($r = $res->fetch_assoc()) {
    // Susun label tampilan (judul — penulis [lokasi])
    $label = $r['title'];
    if (!empty($r['author'])) $label .= " — " . $r['author'];
    if (!empty($r['location_name'])) {
        $label .= " (" . $r['location_name'];
        if (!empty($r['location_room'])) $label .= " - " . $r['location_room'];
        $label .= ")";
    }

    $suggestions[] = [
        'title'        => $r['title'],
        'author'       => $r['author'],
        'location'     => $r['location_name'],
        'room'         => $r['location_room'],
        'display'      => $label
    ];
}

echo json_encode($suggestions, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
