<?php
// ============================================================
// LENTERA LIBRARY SYSTEM – PUBLIC BOOK SEARCH (WITH LOCATION + AUTOCOMPLETE FINAL)
// ============================================================
require_once __DIR__ . "/../config/db_config.php";
$conn = db();
$school_id = 1;

$keyword = trim($_GET['q'] ?? '');
$filter  = trim($_GET['f'] ?? 'title');

$where = "";
$params = [];
$types  = "";

if ($keyword !== '') {
    $keywordLike = "%" . $keyword . "%";
    switch ($filter) {
        case 'author': $where = "AND b.author LIKE ?"; break;
        case 'isbn':   $where = "AND b.isbn LIKE ?"; break;
        case 'code':   $where = "AND b.code LIKE ?"; break;
        default:       $where = "AND b.title LIKE ?"; break;
    }
    $params[] = $keywordLike;
    $types .= "s";
}

// ============================================================
// Tambahkan lokasi buku dari tabel book_locations
// ============================================================
$sql = "
  SELECT b.code, b.title, b.author, b.publisher, b.year, 
         b.stock_total, b.stock_available,
         c.name AS category_name,
         l.name AS location_name, l.code AS location_code, l.room AS location_room
  FROM books b
  LEFT JOIN categories c ON c.id = b.category_id
  LEFT JOIN book_locations l ON l.id = b.location_id
  WHERE b.school_id = ? $where
  ORDER BY b.title ASC
  LIMIT 200
";

$stmt = $conn->prepare($sql);
if ($where !== "") {
    $types = "i" . $types;
    $stmt->bind_param($types, $school_id, ...$params);
} else {
    $stmt->bind_param("i", $school_id);
}
$stmt->execute();
$res = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Pencarian Buku | Lentera Library System</title>
<link href="../assets/css/bootstrap.min.css" rel="stylesheet">
<link href="../assets/css/bootstrap-icons.css" rel="stylesheet">
<script src="../assets/js/jquery.min.js"></script>
<script src="../assets/js/bootstrap.bundle.min.js"></script>
<style>
body { background:#f8fafc; font-family:'Inter',sans-serif; }
.header { background:#2563EB; color:#fff; padding:24px 10px; text-align:center; }
.header h3 { font-weight:600; margin-bottom:5px; }
.card { border:none; border-radius:12px; box-shadow:0 6px 20px rgba(0,0,0,0.05); }
.badge-available { background-color:#16A34A; }
.badge-borrowed { background-color:#DC2626; }
.footer { text-align:center; font-size:13px; color:#6B7280; margin-top:40px; }
.table th, .table td { vertical-align:middle; }
/* --- Suggestion Box --- */
#suggestBox {
  position:absolute;
  z-index:1000;
  background:#fff;
  border:1px solid #ddd;
  border-radius:6px;
  box-shadow:0 4px 10px rgba(0,0,0,0.1);
  width:100%;
  max-height:250px;
  overflow-y:auto;
  display:none;
}
.suggestion-item {
  padding:8px 12px;
  cursor:pointer;
  transition:background 0.15s;
}
.suggestion-item:hover {
  background:#f3f4f6;
}
</style>
</head>
<body>

<div class="header">
  <h3>📚 Pencarian Buku Perpustakaan</h3>
  <p class="mb-0 small">Cari berdasarkan judul, penulis, kode, atau ISBN</p>
</div>

<div class="container my-5">
  <div class="card p-4 mb-4">
    <form method="get" class="row g-2 position-relative">
      <div class="col-md-3 col-sm-12">
        <select name="f" class="form-select">
          <option value="title" <?= $filter=='title'?'selected':'' ?>>Judul Buku</option>
          <option value="author" <?= $filter=='author'?'selected':'' ?>>Penulis</option>
          <option value="isbn" <?= $filter=='isbn'?'selected':'' ?>>ISBN</option>
          <option value="code" <?= $filter=='code'?'selected':'' ?>>Kode Buku</option>
        </select>
      </div>
      <div class="col-md-7 col-sm-12 position-relative">
        <input type="text" name="q" id="searchInput" value="<?= htmlspecialchars($keyword) ?>"
               class="form-control" placeholder="Masukkan kata kunci pencarian..." autocomplete="off">
        <div id="suggestBox"></div>
      </div>
      <div class="col-md-2 col-sm-12 d-grid">
        <button type="submit" class="btn btn-primary">
          <i class="bi bi-search"></i> Cari
        </button>
      </div>
    </form>
  </div>

  <?php if ($keyword !== ''): ?>
    <?php if ($res->num_rows > 0): ?>
      <div class="card p-3">
        <h5 class="text-primary mb-3"><i class="bi bi-list-ul"></i> Hasil untuk: <em><?= htmlspecialchars($keyword) ?></em></h5>
        <div class="table-responsive">
          <table class="table table-bordered table-hover align-middle">
            <thead class="table-light">
              <tr>
                <th width="5%">No</th>
                <th>Kode</th>
                <th>Judul</th>
                <th>Penulis</th>
                <th>Penerbit</th>
                <th>Kategori</th>
                <th>Lokasi</th>
                <th>Tahun</th>
                <th width="120" class="text-center">Status</th>
              </tr>
            </thead>
            <tbody>
              <?php $no=1; while($b=$res->fetch_assoc()): 
                $isAvailable = ($b['stock_available'] > 0);
                $lokasi = '-';
                if ($b['location_name']) {
                    $lokasi = htmlspecialchars($b['location_name']);
                    if (!empty($b['location_room'])) $lokasi .= " (" . htmlspecialchars($b['location_room']) . ")";
                }
              ?>
              <tr>
                <td><?= $no++ ?></td>
                <td><?= htmlspecialchars($b['code']) ?></td>
                <td><?= htmlspecialchars($b['title']) ?></td>
                <td><?= htmlspecialchars($b['author']) ?></td>
                <td><?= htmlspecialchars($b['publisher']) ?></td>
                <td><?= htmlspecialchars($b['category_name'] ?? '-') ?></td>
                <td><?= $lokasi ?></td>
                <td><?= htmlspecialchars($b['year']) ?></td>
                <td class="text-center">
                  <?php if ($isAvailable): ?>
                    <span class="badge badge-available">Tersedia</span>
                  <?php else: ?>
                    <span class="badge badge-borrowed">Dipinjam</span>
                  <?php endif; ?>
                </td>
              </tr>
              <?php endwhile; ?>
            </tbody>
          </table>
        </div>
      </div>
    <?php else: ?>
      <div class="alert alert-warning text-center">
        Tidak ada hasil ditemukan untuk <strong><?= htmlspecialchars($keyword) ?></strong>.
      </div>
    <?php endif; ?>
  <?php else: ?>
    <div class="alert alert-info text-center">
      Masukkan kata kunci untuk mencari buku.
    </div>
  <?php endif; ?>
</div>

<div class="footer">
  &copy; <?= date('Y') ?> Lentera Library System | Akses Publik
</div>

<script>
$(function(){
  const input = $("#searchInput");
  const suggestBox = $("#suggestBox");
  let timer;

  input.on("input", function(){
    clearTimeout(timer);
    const q = $(this).val().trim();
    if (q.length < 2) {
      suggestBox.hide();
      return;
    }
    timer = setTimeout(() => {
      $.getJSON("ajax_book_suggest.php", { q }, function(data){
        suggestBox.empty();
        if (data.length === 0) { suggestBox.hide(); return; }
        data.forEach(item => {
          const el = $("<div>").addClass("suggestion-item")
                     .text(item.title + (item.author ? " — " + item.author : ""));
          el.on("click", function(){
            input.val(item.title);
            suggestBox.hide();
          });
          suggestBox.append(el);
        });
        suggestBox.show();
      });
    }, 300);
  });

  $(document).on("click", function(e){
    if (!$(e.target).closest("#searchInput, #suggestBox").length) suggestBox.hide();
  });
});
</script>
</body>
</html>
