<?php
// ============================================================
// LENTERA LIBRARY SYSTEM – AJAX SAVE SETTINGS (FOR MODAL)
// ============================================================
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . "/../config/session_guard.php";
require_once __DIR__ . "/../config/db_config.php";

header('Content-Type: application/json; charset=utf-8');
$conn = db();
$school_id = $_SESSION['school_id'] ?? 0;

$type = $_POST['type'] ?? '';
$key  = trim($_POST['key'] ?? '');
$value = trim($_POST['value'] ?? '');

if ($school_id <= 0 || $key === '' || $value === '') {
  echo json_encode(['status'=>'error','message'=>'Data tidak lengkap.']); exit;
}

try {
  if ($type === 'settings') {
    // Update or insert setting
    $stmt = $conn->prepare("
      INSERT INTO settings (school_id, key_name, key_value, updated_at)
      VALUES (?, ?, ?, NOW())
      ON DUPLICATE KEY UPDATE key_value=VALUES(key_value), updated_at=NOW()
    ");
    $stmt->bind_param("iss", $school_id, $key, $value);
    $stmt->execute();
    echo json_encode([
      'status'=>'success',
      'message'=>'Pengaturan berhasil diperbarui.',
      'key'=>$key,
      'value'=>$value
    ]);
  } elseif ($type === 'fines') {
    // Update fines_rules
    if ($key === 'fine_per_day') $field = 'fine_per_day';
    elseif ($key === 'max_days') $field = 'max_days';
    else throw new Exception("Field tidak dikenali");

    $stmt = $conn->prepare("
      INSERT INTO fines_rules (school_id, $field)
      VALUES (?, ?)
      ON DUPLICATE KEY UPDATE $field=VALUES($field), updated_at=NOW()
    ");
    $stmt->bind_param("id", $school_id, $value);
    $stmt->execute();
    echo json_encode([
      'status'=>'success',
      'message'=>'Pengaturan denda berhasil diperbarui.',
      'key'=>$key,
      'value'=>$value
    ]);
  } else {
    throw new Exception("Jenis pengaturan tidak valid.");
  }
} catch (Exception $e) {
  echo json_encode(['status'=>'error','message'=>$e->getMessage()]);
}
