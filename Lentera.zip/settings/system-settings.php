<?php
// ============================================================
// LENTERA LIBRARY SYSTEM – PENGATURAN SISTEM (FINAL TAB + MODAL AJAX)
// ============================================================
$pageTitle = "Pengaturan Sistem";

if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . "/../config/session_guard.php";
require_once __DIR__ . "/../config/db_config.php";
require_once __DIR__ . "/../includes/header.php";
require_once __DIR__ . "/../includes/sidebar.php";
require_once __DIR__ . "/../includes/topbar.php";

if ($_SESSION['user_type'] !== 'admin') {
    header("Location: ../dashboard.php");
    exit;
}

$conn = db();
$school_id = $_SESSION['school_id'] ?? 0;

// ============================================================
// AMBIL DATA SETTINGS
// ============================================================
$settings = [];
$stmt = $conn->prepare("SELECT key_name, key_value FROM settings WHERE school_id = ?");
$stmt->bind_param("i", $school_id);
$stmt->execute();
$res = $stmt->get_result();
while ($row = $res->fetch_assoc()) {
    $settings[$row['key_name']] = $row['key_value'];
}
$stmt->close();

// Default jika belum ada data
$settings += [
    'max_loan_days' => 7,
    'library_name' => 'Perpustakaan Sekolah',
    'print_footer_text' => 'Harap mengembalikan buku tepat waktu.',
];

// ============================================================
// AMBIL DATA FINES RULES
// ============================================================
$stmtF = $conn->prepare("SELECT fine_per_day, max_days FROM fines_rules WHERE school_id = ? LIMIT 1");
$stmtF->bind_param("i", $school_id);
$stmtF->execute();
$rule = $stmtF->get_result()->fetch_assoc() ?? ['fine_per_day'=>500,'max_days'=>30];
$stmtF->close();
?>
<!-- ============================================================ -->
<!-- MAIN CONTENT -->
<!-- ============================================================ -->
<main id="mainContent" class="flex-grow-1 p-4">
  <div class="container-fluid">

    <div class="d-flex justify-content-between align-items-center mb-4">
      <h4 class="text-primary mb-0"><i class="bi bi-gear me-2"></i> Pengaturan Sistem</h4>
    </div>

    <div class="card shadow-sm border-0">
      <div class="card-body">
        <!-- Tabs -->
        <ul class="nav nav-tabs mb-3" id="settingsTab" role="tablist">
          <li class="nav-item" role="presentation">
            <button class="nav-link active" id="tab-general" data-bs-toggle="tab" data-bs-target="#generalTab" type="button" role="tab">
              <i class="bi bi-house-gear me-1"></i> Umum
            </button>
          </li>
          <li class="nav-item" role="presentation">
            <button class="nav-link" id="tab-fines" data-bs-toggle="tab" data-bs-target="#finesTab" type="button" role="tab">
              <i class="bi bi-cash-coin me-1"></i> Denda
            </button>
          </li>
        </ul>

        <div class="tab-content">
          <!-- ============================================================ -->
          <!-- TAB UMUM -->
          <!-- ============================================================ -->
          <div class="tab-pane fade show active" id="generalTab" role="tabpanel">
            <div class="table-responsive">
              <table class="table table-bordered align-middle">
                <thead class="table-light">
                  <tr>
                    <th style="width:35%">Nama Pengaturan</th>
                    <th>Nilai Saat Ini</th>
                    <th style="width:10%">Aksi</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>Lama Peminjaman Maksimal (hari)</td>
                    <td><span id="val_max_loan_days"><?= htmlspecialchars($settings['max_loan_days']) ?></span></td>
                    <td class="text-center">
                      <button class="btn btn-sm btn-outline-primary" 
                              onclick="openEdit('settings','max_loan_days','Lama Peminjaman Maksimal (hari)', 'number', <?= (int)$settings['max_loan_days'] ?>)">
                        <i class="bi bi-pencil-square"></i>
                      </button>
                    </td>
                  </tr>
                  <tr>
                    <td>Nama Perpustakaan</td>
                    <td><span id="val_library_name"><?= htmlspecialchars($settings['library_name']) ?></span></td>
                    <td class="text-center">
                      <button class="btn btn-sm btn-outline-primary" 
                              onclick="openEdit('settings','library_name','Nama Perpustakaan', 'text', '<?= addslashes($settings['library_name']) ?>')">
                        <i class="bi bi-pencil-square"></i>
                      </button>
                    </td>
                  </tr>
                  <tr>
                    <td>Teks Footer Cetakan</td>
                    <td><span id="val_print_footer_text"><?= htmlspecialchars($settings['print_footer_text']) ?></span></td>
                    <td class="text-center">
                      <button class="btn btn-sm btn-outline-primary" 
                              onclick="openEdit('settings','print_footer_text','Teks Footer Cetakan', 'textarea', '<?= addslashes($settings['print_footer_text']) ?>')">
                        <i class="bi bi-pencil-square"></i>
                      </button>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          <!-- ============================================================ -->
          <!-- TAB DENDA -->
          <!-- ============================================================ -->
          <div class="tab-pane fade" id="finesTab" role="tabpanel">
            <div class="table-responsive">
              <table class="table table-bordered align-middle">
                <thead class="table-light">
                  <tr>
                    <th style="width:35%">Nama Pengaturan</th>
                    <th>Nilai Saat Ini</th>
                    <th style="width:10%">Aksi</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>Denda per Hari (Rp)</td>
                    <td><span id="val_fine_per_day"><?= htmlspecialchars($rule['fine_per_day']) ?></span></td>
                    <td class="text-center">
                      <button class="btn btn-sm btn-outline-primary"
                              onclick="openEdit('fines','fine_per_day','Denda per Hari (Rp)', 'number', <?= (float)$rule['fine_per_day'] ?>)">
                        <i class="bi bi-pencil-square"></i>
                      </button>
                    </td>
                  </tr>
                  <tr>
                    <td>Maksimal Hari Denda</td>
                    <td><span id="val_max_days"><?= htmlspecialchars($rule['max_days']) ?></span></td>
                    <td class="text-center">
                      <button class="btn btn-sm btn-outline-primary"
                              onclick="openEdit('fines','max_days','Maksimal Hari Denda', 'number', <?= (int)$rule['max_days'] ?>)">
                        <i class="bi bi-pencil-square"></i>
                      </button>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div> <!-- tab-content -->
      </div>
    </div>
  </div>
</main>

<!-- ============================================================ -->
<!-- MODAL EDIT -->
<!-- ============================================================ -->
<div class="modal fade" id="editModal" tabindex="-1">
  <div class="modal-dialog">
    <form id="editForm" class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Ubah Pengaturan</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <input type="hidden" name="type" id="setType">
        <input type="hidden" name="key" id="setKey">
        <div class="mb-3">
          <label id="setLabel" class="form-label fw-semibold"></label>
          <div id="inputWrapper"></div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
        <button type="submit" class="btn btn-primary">Simpan</button>
      </div>
    </form>
  </div>
</div>

<?php require_once __DIR__ . "/../includes/footer.php"; ?>

<!-- ============================================================ -->
<!-- SCRIPT -->
<!-- ============================================================ -->
<script src="../assets/js/jquery.min.js"></script>
<script>
let modal = new bootstrap.Modal(document.getElementById('editModal'));

function openEdit(type, key, label, inputType, value){
  $("#setType").val(type);
  $("#setKey").val(key);
  $("#setLabel").text(label);

  let inputHTML = "";
  if(inputType === 'textarea'){
    inputHTML = `<textarea name="value" class="form-control" rows="3" required>${value}</textarea>`;
  } else {
    inputHTML = `<input type="${inputType}" name="value" class="form-control" value="${value}" required>`;
  }
  $("#inputWrapper").html(inputHTML);
  modal.show();
}

$("#editForm").on("submit", function(e){
  e.preventDefault();
  $.post("ajax_save_setting.php", $(this).serialize(), function(res){
    if(res.status === 'success'){
      modal.hide();
      $(`#val_${res.key}`).text(res.value);
      Swal.fire({
        icon: 'success',
        title: 'Berhasil',
        text: res.message,
        confirmButtonColor: '#2563EB'
      });
    } else {
      Swal.fire({ icon:'error', title:'Gagal', text:res.message });
    }
  }, 'json').fail(()=>Swal.fire({icon:'error',title:'Error',text:'Gagal terhubung ke server.'}));
});
</script>
