<?php
// ============================================================
// LENTERA LIBRARY SYSTEM – STUDENTS (CREATE VIEW - FINAL STABLE)
// ============================================================

$pageTitle = "Tambah Siswa";

if (session_status() === PHP_SESSION_NONE) session_start();
ob_start(); // ✅ supaya header() aman

require_once __DIR__ . "/../config/session_guard.php";
require_once __DIR__ . "/../config/db_config.php";
require_once __DIR__ . "/../includes/header.php";
require_once __DIR__ . "/../includes/sidebar.php";
require_once __DIR__ . "/../includes/topbar.php";

$conn = db();
$school_id = $_SESSION['school_id'] ?? 0;
$msg = "";

// ============================================================
// FORM SUBMIT HANDLER
// ============================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nis      = trim($_POST['nis']);
    $name     = trim($_POST['name']);
    $year     = (int)($_POST['entry_year'] ?? 0);
    $gender   = $_POST['gender'] ?? 'L';
    $phone    = trim($_POST['phone']);
    $email    = trim($_POST['email']);
    $password = password_hash($_POST['password'] ?? '123456', PASSWORD_DEFAULT);

    // Validasi minimal
    if ($nis === '' || $name === '') {
        $msg = "NIS dan Nama wajib diisi.";
    } else {
        // Cek duplikat NIS
        $check = $conn->prepare("SELECT id FROM students WHERE school_id = ? AND nis = ? LIMIT 1");
        $check->bind_param("is", $school_id, $nis);
        $check->execute();
        $checkRes = $check->get_result();
        if ($checkRes->num_rows > 0) {
            $msg = "NIS sudah terdaftar. Gunakan NIS lain.";
        } else {
            // Insert data baru
            $stmt = $conn->prepare("
                INSERT INTO students 
                (school_id, nis, name, entry_year, gender, phone, email, password)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ");
            $stmt->bind_param("ississss", $school_id, $nis, $name, $year, $gender, $phone, $email, $password);

            if ($stmt->execute()) {
                $_SESSION['flash_success'] = "Siswa '$name' berhasil ditambahkan.";
                ob_clean();
                header("Location: students.php");
                exit;
            } else {
                $msg = "Gagal menambahkan siswa. Pastikan data valid.";
            }
            $stmt->close();
        }
        $check->close();
    }
}
?>

<!-- ============================================================ -->
<!-- MAIN CONTENT AREA -->
<!-- ============================================================ -->
<main id="mainContent" class="flex-grow-1 p-4">
  <div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-3">
      <h4 class="text-primary mb-0"><i class="bi bi-person-plus me-2"></i> Tambah Siswa Baru</h4>
      <a href="students.php" class="btn btn-outline-secondary btn-sm">
        <i class="bi bi-arrow-left"></i> Kembali
      </a>
    </div>

    <div class="card shadow-sm border-0">
      <div class="card-body">
        <?php if ($msg): ?>
          <div class="alert alert-danger auto-dismiss"><?= htmlspecialchars($msg) ?></div>
        <?php endif; ?>

        <form method="post" autocomplete="off">
          <div class="row g-3">
            <div class="col-md-4">
              <label class="form-label fw-semibold">NIS <span class="text-danger">*</span></label>
              <input type="text" name="nis" class="form-control" maxlength="30" required>
            </div>
            <div class="col-md-8">
              <label class="form-label fw-semibold">Nama Lengkap <span class="text-danger">*</span></label>
              <input type="text" name="name" class="form-control" maxlength="150" required>
            </div>

            <div class="col-md-4">
              <label class="form-label fw-semibold">Tahun Masuk</label>
              <input type="number" name="entry_year" class="form-control" value="<?= date('Y') ?>" min="2000" max="<?= date('Y') + 1 ?>">
            </div>
            <div class="col-md-4">
              <label class="form-label fw-semibold">Jenis Kelamin <span class="text-danger">*</span></label>
              <select name="gender" class="form-select" required>
                <option value="L">Laki-laki</option>
                <option value="P">Perempuan</option>
              </select>
            </div>
            <div class="col-md-4">
              <label class="form-label fw-semibold">No. Telepon</label>
              <input type="text" name="phone" class="form-control" maxlength="20">
            </div>

            <div class="col-md-6">
              <label class="form-label fw-semibold">Email</label>
              <input type="email" name="email" class="form-control" maxlength="150">
            </div>
            <div class="col-md-6">
              <label class="form-label fw-semibold">Password Awal <span class="text-danger">*</span></label>
              <input type="text" name="password" class="form-control" value="123456" maxlength="100" required>
              <small class="text-muted">Password bisa diubah nanti oleh siswa.</small>
            </div>
          </div>

          <div class="text-end mt-4">
            <button type="submit" class="btn btn-primary px-4">
              <i class="bi bi-save me-1"></i> Simpan
            </button>
            <a href="students.php" class="btn btn-outline-secondary">Batal</a>
          </div>
        </form>
      </div>
    </div>
  </div>
</main>

<?php require_once __DIR__ . "/../includes/footer.php"; ?>
<?php ob_end_flush(); ?>
