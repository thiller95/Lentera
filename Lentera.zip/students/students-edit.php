<?php
// ============================================================
// LENTERA LIBRARY SYSTEM – STUDENTS (EDIT VIEW - FINAL STABLE)
// ============================================================

$pageTitle = "Edit Siswa";

if (session_status() === PHP_SESSION_NONE) session_start();
ob_start(); // agar header() aman

require_once __DIR__ . "/../config/session_guard.php";
require_once __DIR__ . "/../config/db_config.php";
require_once __DIR__ . "/../includes/header.php";
require_once __DIR__ . "/../includes/sidebar.php";
require_once __DIR__ . "/../includes/topbar.php";

$conn = db();
$school_id = $_SESSION['school_id'] ?? 0;

// ============================================================
// VALIDASI PARAMETER
// ============================================================
$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) die("ID tidak valid.");

// ============================================================
// AMBIL DATA SISWA
// ============================================================
$stmt = $conn->prepare("SELECT * FROM students WHERE id=? AND school_id=? LIMIT 1");
$stmt->bind_param("ii", $id, $school_id);
$stmt->execute();
$res = $stmt->get_result();
$student = $res->fetch_assoc();
$stmt->close();

if (!$student) {
    die("Data siswa tidak ditemukan.");
}

$msg = "";

// ============================================================
// FORM SUBMIT HANDLER
// ============================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nis    = trim($_POST['nis']);
    $name   = trim($_POST['name']);
    $year   = (int)($_POST['entry_year'] ?? 0);
    $gender = $_POST['gender'] ?? 'L';
    $phone  = trim($_POST['phone']);
    $email  = trim($_POST['email']);

    if ($nis === '' || $name === '') {
        $msg = "NIS dan Nama wajib diisi.";
    } else {
        // Cek NIS unik
        $check = $conn->prepare("
            SELECT COUNT(*) 
            FROM students 
            WHERE school_id=? AND nis=? AND id<>?
        ");
        $check->bind_param("isi", $school_id, $nis, $id);
        $check->execute();
        $check->bind_result($exists);
        $check->fetch();
        $check->close();

        if ($exists > 0) {
            $msg = "NIS sudah digunakan oleh siswa lain.";
        } else {
            $stmt = $conn->prepare("
                UPDATE students 
                SET nis=?, name=?, entry_year=?, gender=?, phone=?, email=?
                WHERE id=? AND school_id=?
            ");
            $stmt->bind_param("ssisssii", $nis, $name, $year, $gender, $phone, $email, $id, $school_id);

            if ($stmt->execute()) {
                $_SESSION['flash_success'] = "Perubahan data siswa '$name' berhasil disimpan.";
                ob_clean();
                header("Location: students.php");
                exit;
            } else {
                $msg = "Gagal menyimpan perubahan data siswa.";
            }
            $stmt->close();
        }
    }
}
?>

<!-- ============================================================ -->
<!-- MAIN CONTENT AREA -->
<!-- ============================================================ -->
<main id="mainContent" class="flex-grow-1 p-4">
  <div class="container-fluid">

    <div class="d-flex justify-content-between align-items-center mb-3">
      <h4 class="text-primary mb-0">
        <i class="bi bi-pencil-square me-2"></i>Edit Data Siswa
      </h4>
      <a href="students.php" class="btn btn-outline-secondary btn-sm">
        <i class="bi bi-arrow-left"></i> Kembali
      </a>
    </div>

    <div class="card shadow-sm border-0">
      <div class="card-body">
        <?php if ($msg): ?>
          <div class="alert alert-danger auto-dismiss"><?= htmlspecialchars($msg) ?></div>
        <?php endif; ?>

        <form method="post" autocomplete="off">
          <div class="row g-3">
            <div class="col-md-4">
              <label class="form-label fw-semibold">NIS <span class="text-danger">*</span></label>
              <input type="text" name="nis" class="form-control" maxlength="30" value="<?= htmlspecialchars($student['nis']) ?>" required>
            </div>

            <div class="col-md-8">
              <label class="form-label fw-semibold">Nama Lengkap <span class="text-danger">*</span></label>
              <input type="text" name="name" class="form-control" maxlength="150" value="<?= htmlspecialchars($student['name']) ?>" required>
            </div>

            <div class="col-md-4">
              <label class="form-label fw-semibold">Tahun Masuk</label>
              <input type="number" name="entry_year" class="form-control" value="<?= htmlspecialchars($student['entry_year']) ?>" min="2000" max="<?= date('Y') + 1 ?>">
            </div>

            <div class="col-md-4">
              <label class="form-label fw-semibold">Jenis Kelamin <span class="text-danger">*</span></label>
              <select name="gender" class="form-select" required>
                <option value="L" <?= $student['gender'] == 'L' ? 'selected' : '' ?>>Laki-laki</option>
                <option value="P" <?= $student['gender'] == 'P' ? 'selected' : '' ?>>Perempuan</option>
              </select>
            </div>

            <div class="col-md-4">
              <label class="form-label fw-semibold">No. Telepon</label>
              <input type="text" name="phone" class="form-control" maxlength="20" value="<?= htmlspecialchars($student['phone']) ?>">
            </div>

            <div class="col-md-6">
              <label class="form-label fw-semibold">Email</label>
              <input type="email" name="email" class="form-control" maxlength="150" value="<?= htmlspecialchars($student['email']) ?>">
            </div>
          </div>

          <div class="text-end mt-4">
            <button type="submit" class="btn btn-primary px-4">
              <i class="bi bi-save me-1"></i> Simpan Perubahan
            </button>
            <a href="students.php" class="btn btn-outline-secondary">Batal</a>
          </div>
        </form>
      </div>
    </div>

  </div>
</main>

<?php require_once __DIR__ . "/../includes/footer.php"; ?>
<?php ob_end_flush(); ?>
