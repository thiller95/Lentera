<?php
// ============================================================
// LENTERA LIBRARY SYSTEM – DATA SISWA (LIST VIEW + UPLOAD/DOWNLOAD MODAL)
// ============================================================

$pageTitle = "Data Siswa";

if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . "/../config/session_guard.php";
require_once __DIR__ . "/../config/db_config.php";
require_once __DIR__ . "/../includes/header.php";
require_once __DIR__ . "/../includes/sidebar.php";
require_once __DIR__ . "/../includes/topbar.php";

$conn = db();
$school_id = $_SESSION['school_id'] ?? 0;
$keyword   = trim($_GET['q'] ?? '');
$where = "WHERE s.school_id = ?";
$params = [$school_id];
$types  = "i";

if ($keyword !== '') {
  $like = "%{$keyword}%";
  $where .= " AND (s.name LIKE ? OR s.nis LIKE ? OR s.entry_year LIKE ?)";
  array_push($params, $like, $like, $like);
  $types .= "sss";
}

$sql = "
  SELECT s.*, COUNT(l.id) AS total_loans
  FROM students s
  LEFT JOIN book_loans l ON l.student_id = s.id
  $where
  GROUP BY s.id
  ORDER BY s.name ASC
";
$stmt = $conn->prepare($sql);
$stmt->bind_param($types, ...$params);
$stmt->execute();
$res = $stmt->get_result();
?>

<main id="mainContent" class="flex-grow-1 p-4">
  <div class="container-fluid">

    <!-- Header -->
    <div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
      <h4 class="text-primary mb-0"><i class="bi bi-people me-2"></i> Data Siswa</h4>
      <div class="d-flex gap-2">
        <a href="students-template.php" class="btn btn-outline-secondary btn-sm">
          <i class="bi bi-file-earmark"></i> Template Excel
        </a>
        <a href="students-export.php" class="btn btn-outline-success btn-sm">
          <i class="bi bi-download"></i> Download Data
        </a>
        <button type="button" class="btn btn-outline-secondary btn-sm" data-bs-toggle="modal" data-bs-target="#uploadModal">
          <i class="bi bi-upload"></i> Upload Data
        </button>
        <a href="students-create.php" class="btn btn-primary btn-sm">
          <i class="bi bi-plus-circle"></i> Tambah Siswa
        </a>
      </div>
    </div>

    <!-- Filter -->
    <form class="row g-2 mb-4" method="get" autocomplete="off">
      <div class="col-md-10">
        <input type="text" name="q" class="form-control" placeholder="Cari nama / NIS / tahun masuk..." value="<?= htmlspecialchars($keyword) ?>">
      </div>
      <div class="col-md-2 d-grid">
        <button type="submit" class="btn btn-outline-primary"><i class="bi bi-search"></i> Cari</button>
      </div>
    </form>

    <!-- Table -->
    <div class="card shadow-sm border-0">
      <div class="card-body table-responsive">
        <table id="tblStudents" class="table table-bordered table-hover align-middle mb-0">
          <thead class="table-light">
            <tr>
              <th width="5%">#</th>
              <th>NIS</th>
              <th>Nama Siswa</th>
              <th>Tahun Masuk</th>
              <th>Jenis Kelamin</th>
              <th>Telp</th>
              <th>Email</th>
              <th>Total Pinjam</th>
              <th width="13%">Aksi</th>
            </tr>
          </thead>
          <tbody>
            <?php $no=1; while($r=$res->fetch_assoc()): ?>
              <tr>
                <td><?= $no++ ?></td>
                <td><?= htmlspecialchars($r['nis']) ?></td>
                <td><?= htmlspecialchars($r['name']) ?></td>
                <td><?= htmlspecialchars($r['entry_year']) ?></td>
                <td><?= ($r['gender']==='L'?'Laki-laki':'Perempuan') ?></td>
                <td><?= htmlspecialchars($r['phone']) ?></td>
                <td><?= htmlspecialchars($r['email']) ?></td>
                <td class="text-center"><?= (int)$r['total_loans'] ?></td>
                <td class="text-center">
                  <a href="students-edit.php?id=<?= $r['id'] ?>" class="btn btn-sm btn-outline-warning" title="Edit"><i class="bi bi-pencil"></i></a>
                  <a href="students-delete.php?id=<?= $r['id'] ?>" class="btn btn-sm btn-outline-danger btn-delete" title="Hapus"><i class="bi bi-trash"></i></a>
                </td>
              </tr>
            <?php endwhile; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</main>

<!-- ============================================================ -->
<!-- MODAL UPLOAD EXCEL SISWA -->
<!-- ============================================================ -->
<div class="modal fade" id="uploadModal" tabindex="-1" aria-labelledby="uploadModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <form id="uploadForm" enctype="multipart/form-data">
      <div class="modal-content">
        <div class="modal-header bg-light">
          <h5 class="modal-title" id="uploadModalLabel">
            <i class="bi bi-upload me-2"></i> Upload Data Siswa (Excel)
          </h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Tutup"></button>
        </div>
        <div class="modal-body">
          <p class="small text-muted mb-2">
            Unggah file Excel (.xlsx) sesuai format template.<br>
            <strong>Kolom wajib:</strong> NIS, Nama, Tahun Masuk, Gender (L/P), Telp, Email.
          </p>
          <input type="file" name="file_excel" class="form-control" accept=".xlsx,.xls" required>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-light" data-bs-dismiss="modal">Batal</button>
          <button type="submit" class="btn btn-primary">
            <i class="bi bi-upload"></i> Upload
          </button>
        </div>
      </div>
    </form>
  </div>
</div>

<?php require_once __DIR__ . "/../includes/footer.php"; ?>

<script>
$(function(){
  // ===============================
  // 📋 Inisialisasi DataTables
  // ===============================
  $("#tblStudents").DataTable({
    pageLength: 10,
    language: { url: "../assets/lang/indonesian.json" }
  });

  // ===============================
  // 🗑️ Konfirmasi Hapus
  // ===============================
  $(".btn-delete").on("click", function(e){
    e.preventDefault();
    const url = $(this).attr("href");
    Swal.fire({
      title: "Hapus Siswa?",
      text: "Data ini akan dihapus permanen!",
      icon: "warning",
      showCancelButton: true,
      confirmButtonText: "Ya, Hapus",
      cancelButtonText: "Batal",
      confirmButtonColor: "#DC2626"
    }).then(res => { if (res.isConfirmed) window.location.href = url; });
  });

  // ===============================
  // 📤 Upload Data (Excel)
  // ===============================
  $("#uploadForm").on("submit", function(e){
    e.preventDefault();
    const formData = new FormData(this);
    $.ajax({
      url: "students-import.php",
      type: "POST",
      data: formData,
      contentType: false,
      processData: false,
      dataType: "json",
      beforeSend: function(){
        $("#uploadForm button[type=submit]")
          .prop("disabled", true)
          .html('<span class="spinner-border spinner-border-sm me-1"></span> Mengunggah...');
      },
      success: function(data){
        if(data.status === "success"){
          toast(data.message);
          setTimeout(()=>location.reload(),1000);
        } else {
          alertError(data.message || "Terjadi kesalahan saat upload.");
        }
      },
      error: function(){
        alertError("Tidak dapat menghubungi server atau respon tidak valid.");
      },
      complete: function(){
        $("#uploadForm button[type=submit]")
          .prop("disabled", false)
          .html('<i class="bi bi-upload"></i> Upload');
      }
    });
  });
});
</script>
