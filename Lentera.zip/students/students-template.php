<?php
require_once __DIR__ . '/../config/db_config.php';
require_once __DIR__ . '/../assets/vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

$spreadsheet = new Spreadsheet();
$sheet = $spreadsheet->getActiveSheet();
$sheet->fromArray(['NIS','Nama','Tahun Masuk','Gender (L/P)','Telp','Email'], NULL, 'A1');
$sheet->getStyle('A1:F1')->getFont()->setBold(true);

$filename = "Template_Data_Siswa.xlsx";
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header("Content-Disposition: attachment; filename=\"$filename\"");

$writer = new Xlsx($spreadsheet);
$writer->save("php://output");
exit;
