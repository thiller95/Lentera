<?php
// ============================================================
// LENTERA LIBRARY SYSTEM – STUDENTS (DELETE VIEW - FINAL STABLE)
// ============================================================

if (session_status() === PHP_SESSION_NONE) session_start();
ob_start(); // pastikan aman dari header() warning

require_once __DIR__ . "/../config/session_guard.php";
require_once __DIR__ . "/../config/db_config.php";

$conn = db();
$school_id = $_SESSION['school_id'] ?? 0;
$id = (int)($_GET['id'] ?? 0);

// ============================================================
// VALIDASI ID
// ============================================================
if ($id <= 0) {
    $_SESSION['flash_error'] = "ID siswa tidak valid.";
    header("Location: students.php");
    exit;
}

// ============================================================
// CEK TRANSAKSI PEMINJAMAN
// ============================================================
$stmt = $conn->prepare("
    SELECT COUNT(*) AS jml 
    FROM book_loans 
    WHERE student_id = ? AND school_id = ?
");
$stmt->bind_param("ii", $id, $school_id);
$stmt->execute();
$res = $stmt->get_result();
$row = $res->fetch_assoc();
$stmt->close();

if ($row && $row['jml'] > 0) {
    $_SESSION['flash_error'] = "Tidak dapat menghapus: siswa ini sudah memiliki transaksi peminjaman.";
    header("Location: students.php");
    exit;
}

// ============================================================
// HAPUS DATA SISWA
// ============================================================
$stmt2 = $conn->prepare("DELETE FROM students WHERE id = ? AND school_id = ? LIMIT 1");
$stmt2->bind_param("ii", $id, $school_id);

if ($stmt2->execute()) {
    $_SESSION['flash_success'] = "Data siswa berhasil dihapus.";
} else {
    $_SESSION['flash_error'] = "Gagal menghapus data siswa.";
}
$stmt2->close();

// Redirect ke daftar siswa
header("Location: students.php");
exit;

ob_end_flush();
