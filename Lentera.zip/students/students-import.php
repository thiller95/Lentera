<?php
// ============================================================
// IMPORT DATA SISWA (JSON RESPONSE UNTUK AJAX UPLOAD MODAL)
// ============================================================
if (session_status() === PHP_SESSION_NONE) session_start();
header('Content-Type: application/json; charset=utf-8');

require_once __DIR__ . '/../config/db_config.php';
require_once __DIR__ . '/../assets/vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\IOFactory;

$conn = db();
$school_id = $_SESSION['school_id'] ?? 0;

if (!isset($_FILES['file_excel']) || $_FILES['file_excel']['error'] !== UPLOAD_ERR_OK) {
  echo json_encode(["status"=>"error","message"=>"File tidak valid atau gagal diunggah."]); exit;
}

try {
  $spreadsheet = IOFactory::load($_FILES['file_excel']['tmp_name']);
} catch (Exception $e) {
  echo json_encode(["status"=>"error","message"=>"Gagal membaca file: ".$e->getMessage()]); exit;
}

$sheet = $spreadsheet->getActiveSheet();
$rows = $sheet->toArray();
if (count($rows)<=1) {
  echo json_encode(["status"=>"error","message"=>"File Excel kosong."]); exit;
}

$inserted=0; $skipped=0;
$stmtCheck=$conn->prepare("SELECT id FROM students WHERE school_id=? AND nis=? LIMIT 1");
$stmtInsert=$conn->prepare("INSERT INTO students (school_id, nis, name, entry_year, gender, phone, email) VALUES (?,?,?,?,?,?,?)");

foreach($rows as $i=>$r){
  if($i===0) continue;
  [$nis,$name,$entry_year,$gender,$phone,$email]=array_pad($r,6,'');
  if(trim($nis)==''||trim($name)=='') continue;
  $stmtCheck->bind_param("is",$school_id,$nis);
  $stmtCheck->execute();
  $exists=$stmtCheck->get_result()->num_rows>0;
  if($exists){$skipped++;continue;}
  $stmtInsert->bind_param("issssss",$school_id,$nis,$name,$entry_year,$gender,$phone,$email);
  if($stmtInsert->execute()) $inserted++;
}

echo json_encode(["status"=>"success","message"=>"Import selesai: $inserted data baru, $skipped duplikat diabaikan."]);
exit;
