<?php
// ============================================================
// EXPORT DATA SISWA (FIXED VERSION - XLSX VALID)
// ============================================================
require_once __DIR__ . '/../config/db_config.php';
require_once __DIR__ . '/../assets/vendor/autoload.php';
session_start();

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

$conn = db();
$school_id = $_SESSION['school_id'] ?? 0;

$sql = "SELECT nis, name, entry_year, gender, phone, email FROM students WHERE school_id=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $school_id);
$stmt->execute();
$res = $stmt->get_result();

$spreadsheet = new Spreadsheet();
$sheet = $spreadsheet->getActiveSheet();

// Header
$sheet->fromArray(['NIS','Nama','Tahun Masuk','Gender','Telp','Email'], NULL, 'A1');
$sheet->getStyle('A1:F1')->getFont()->setBold(true);

// Isi data
$row = 2;
while ($r = $res->fetch_assoc()) {
    $sheet->setCellValue("A$row", $r['nis']);
    $sheet->setCellValue("B$row", $r['name']);
    $sheet->setCellValue("C$row", $r['entry_year']);
    $sheet->setCellValue("D$row", $r['gender']);
    $sheet->setCellValue("E$row", $r['phone']);
    $sheet->setCellValue("F$row", $r['email']);
    $row++;
}

// ============================================================
// ⚙️  CLEAN OUTPUT BUFFER
// ============================================================
if (ob_get_length()) ob_end_clean();  // penting banget
ob_start();

$filename = "Data_Siswa_" . date('Ymd_His') . ".xlsx";

header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header("Content-Disposition: attachment; filename=\"$filename\"");
header('Cache-Control: max-age=0');

// ============================================================
// ✅ OUTPUT FILE KE BROWSER
// ============================================================
$writer = new Xlsx($spreadsheet);
$writer->save('php://output');
exit;
