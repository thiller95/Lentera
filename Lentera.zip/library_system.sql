-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 29, 2025 at 06:57 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET FOREIGN_KEY_CHECKS=0;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `library_system`
--
CREATE DATABASE IF NOT EXISTS `library_system` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `library_system`;

-- --------------------------------------------------------

--
-- Table structure for table `activity_logs`
--
-- Creation: Oct 22, 2025 at 11:05 AM
--

DROP TABLE IF EXISTS `activity_logs`;
CREATE TABLE IF NOT EXISTS `activity_logs` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `school_id` bigint(20) UNSIGNED NOT NULL,
  `user_type` enum('admin','student','system') NOT NULL DEFAULT 'system',
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `action` varchar(100) NOT NULL,
  `reference_id` bigint(20) UNSIGNED DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `school_id` (`school_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `activity_logs`:
--   `school_id`
--       `schools` -> `id`
--

--
-- Dumping data for table `activity_logs`
--

INSERT INTO `activity_logs` (`id`, `school_id`, `user_type`, `user_id`, `action`, `reference_id`, `description`, `created_at`) VALUES
(1, 1, 'student', 1, 'login', NULL, 'Budi Santoso login ke sistem', '2025-10-22 18:05:32'),
(2, 1, 'admin', 1, 'return_confirm', 1, 'Konfirmasi pengembalian buku (loan_id: 1). -', '2025-10-25 14:43:52'),
(3, 1, 'system', 0, 'auto_late_update', NULL, 'Peminjaman LOAN/2025/10/0004 otomatis ditandai late oleh sistem', '2025-10-27 08:10:39'),
(4, 1, 'system', 0, 'auto_late_update', 5, 'Peminjaman LOAN/2025/10/0005 otomatis ditandai late (denda Rp 13,500)', '2025-10-28 05:02:05'),
(5, 1, 'system', 0, 'auto_late_update', 5, 'Peminjaman LOAN/2025/10/0005 otomatis ditandai late (denda Rp 14,000)', '2025-10-29 00:05:59');

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--
-- Creation: Oct 25, 2025 at 09:32 AM
--

DROP TABLE IF EXISTS `admins`;
CREATE TABLE IF NOT EXISTS `admins` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `school_id` bigint(20) UNSIGNED NOT NULL,
  `username` varchar(50) NOT NULL,
  `name` varchar(100) NOT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','staff') DEFAULT 'staff',
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `school_id` (`school_id`,`username`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `admins`:
--   `school_id`
--       `schools` -> `id`
--

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `school_id`, `username`, `name`, `photo`, `password`, `role`, `created_at`) VALUES
(1, 1, 'admin', 'Administrator', 'user_1_1761460602.jpg', '$2y$10$.UrkMtJ.VBtTBDn9USNBpezBiyR.glVA29/.s4W3FsNvBv9XXCP9q', 'admin', '2025-10-22 18:05:31'),
(2, 1, 'dinda', 'dinda.rumasya', 'user_2_1761460627.png', '$2y$10$7x3hCVLM/VuLbkhcBrepLesVi/hyeq5rZmW1V0zXNdmj4Vh0Jt4Wy', 'staff', '2025-10-26 12:31:33');

-- --------------------------------------------------------

--
-- Table structure for table `books`
--
-- Creation: Oct 22, 2025 at 11:05 AM
--

DROP TABLE IF EXISTS `books`;
CREATE TABLE IF NOT EXISTS `books` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `school_id` bigint(20) UNSIGNED NOT NULL,
  `category_id` bigint(20) UNSIGNED DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `code` varchar(20) NOT NULL,
  `title` varchar(255) NOT NULL,
  `author` varchar(150) DEFAULT NULL,
  `publisher` varchar(150) DEFAULT NULL,
  `year` year(4) DEFAULT NULL,
  `isbn` varchar(50) DEFAULT NULL,
  `stock_total` int(10) UNSIGNED DEFAULT 0,
  `stock_available` int(10) UNSIGNED DEFAULT 0,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `school_id` (`school_id`,`code`),
  KEY `category_id` (`category_id`),
  KEY `fk_books_location` (`location_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `books`:
--   `school_id`
--       `schools` -> `id`
--   `category_id`
--       `categories` -> `id`
--   `location_id`
--       `book_locations` -> `id`
--

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`id`, `school_id`, `category_id`, `location_id`, `code`, `title`, `author`, `publisher`, `year`, `isbn`, `stock_total`, `stock_available`, `created_at`) VALUES
(1, 1, 1, 2, 'BK0001', 'Matematika Kelas 8', 'Y. Supardi', 'Erlangga', '2022', NULL, 10, 10, '2025-10-22 18:05:32'),
(2, 1, 2, 1, 'BK0002', 'Laskar Pelangi', 'Andrea Hirata', 'Bentang Pustaka', '2015', '', 5, 5, '2025-10-22 18:05:32'),
(3, 1, 2, 2, 'BOOK/2025/10/00001', 'Seporsi Mie Ayam Sebelum Mati', 'Brian Krisna', 'Gramedia', '2023', '0', 2, 2, '2025-10-25 14:01:11'),
(6, 1, 2, 1, 'BOOK/2025/10/00002', 'Bandung Menjelang Pagi', 'Brian Krisna', 'Gramedia', '2023', '', 4, 4, '2025-10-25 14:21:37'),
(7, 1, 2, 2, 'BOOK/2025/10/00003', 'Hoegeng: Polisi dan Menteri Teladan', 'Suhartono', 'Gramedia', NULL, NULL, 8, 7, '2025-10-28 02:55:38'),
(8, 1, 2, 2, 'BOOK/2025/10/00004', 'Pramoedya dari Dekat Sekali', 'Koesalah Soebagyo Toer', 'Gramedia', NULL, NULL, 9, 9, '2025-10-28 02:59:57');

-- --------------------------------------------------------

--
-- Table structure for table `book_loans`
--
-- Creation: Oct 27, 2025 at 03:32 AM
--

DROP TABLE IF EXISTS `book_loans`;
CREATE TABLE IF NOT EXISTS `book_loans` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `school_id` bigint(20) UNSIGNED NOT NULL,
  `loan_code` varchar(30) NOT NULL,
  `student_id` bigint(20) UNSIGNED NOT NULL,
  `loan_date` date NOT NULL,
  `due_date` date NOT NULL,
  `return_date` date DEFAULT NULL,
  `status` enum('borrowed','returned','late') DEFAULT 'borrowed',
  `note` text DEFAULT NULL,
  `fine` decimal(10,2) DEFAULT 0.00,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `school_id` (`school_id`,`loan_code`),
  KEY `student_id` (`student_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `book_loans`:
--   `school_id`
--       `schools` -> `id`
--   `student_id`
--       `students` -> `id`
--

--
-- Dumping data for table `book_loans`
--

INSERT INTO `book_loans` (`id`, `school_id`, `loan_code`, `student_id`, `loan_date`, `due_date`, `return_date`, `status`, `note`, `fine`, `created_at`) VALUES
(1, 1, 'LOAN/2025/10/0001', 3, '2025-10-25', '2025-11-01', NULL, 'borrowed', NULL, 0.00, '2025-10-25 14:35:20'),
(2, 1, 'LOAN/2025/10/0002', 1, '2025-10-25', '2025-11-01', NULL, 'borrowed', NULL, 0.00, '2025-10-25 14:44:33'),
(3, 1, 'LOAN/2025/10/0003', 3, '2025-09-03', '2025-11-02', NULL, 'borrowed', NULL, 0.00, '2025-10-26 14:38:16'),
(4, 1, 'LOAN/2025/10/0004', 1, '2025-09-01', '2025-10-16', '2025-10-27', 'returned', NULL, 5500.00, '2025-10-27 07:57:00'),
(5, 1, 'LOAN/2025/10/0005', 2, '2025-08-13', '2025-10-01', NULL, 'late', NULL, 14000.00, '2025-10-27 11:15:50'),
(6, 1, 'LOAN/2025/10/0006', 5, '2025-10-29', '2025-11-05', NULL, 'borrowed', NULL, 0.00, '2025-10-29 00:05:49');

-- --------------------------------------------------------

--
-- Table structure for table `book_loan_details`
--
-- Creation: Oct 22, 2025 at 11:05 AM
--

DROP TABLE IF EXISTS `book_loan_details`;
CREATE TABLE IF NOT EXISTS `book_loan_details` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `loan_id` bigint(20) UNSIGNED NOT NULL,
  `book_id` bigint(20) UNSIGNED NOT NULL,
  `quantity` int(10) UNSIGNED DEFAULT 1,
  `returned` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `loan_id` (`loan_id`),
  KEY `book_id` (`book_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `book_loan_details`:
--   `loan_id`
--       `book_loans` -> `id`
--   `book_id`
--       `books` -> `id`
--

--
-- Dumping data for table `book_loan_details`
--

INSERT INTO `book_loan_details` (`id`, `loan_id`, `book_id`, `quantity`, `returned`) VALUES
(1, 1, 6, 1, 0),
(2, 1, 1, 1, 1),
(3, 2, 3, 1, 0),
(4, 3, 1, 1, 0),
(5, 4, 1, 1, 1),
(6, 5, 2, 1, 0),
(7, 6, 7, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `book_locations`
--
-- Creation: Oct 27, 2025 at 08:20 AM
--

DROP TABLE IF EXISTS `book_locations`;
CREATE TABLE IF NOT EXISTS `book_locations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `school_id` int(11) NOT NULL,
  `code` varchar(50) NOT NULL,
  `name` varchar(100) NOT NULL,
  `room` varchar(100) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_location` (`school_id`,`code`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `book_locations`:
--

--
-- Dumping data for table `book_locations`
--

INSERT INTO `book_locations` (`id`, `school_id`, `code`, `name`, `room`, `notes`, `created_at`, `updated_at`) VALUES
(1, 1, 'RAK01', 'Seksi A', 'Perpustakaan', '', '2025-10-27 15:31:36', '2025-10-27 15:31:36'),
(2, 1, 'RAK/2025/10/00001', 'Seksi B', 'Perpustakaan', '', '2025-10-28 02:55:38', '2025-10-28 03:13:16');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--
-- Creation: Oct 22, 2025 at 11:05 AM
--

DROP TABLE IF EXISTS `categories`;
CREATE TABLE IF NOT EXISTS `categories` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `school_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `school_id` (`school_id`,`name`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `categories`:
--   `school_id`
--       `schools` -> `id`
--

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `school_id`, `name`, `description`, `created_at`) VALUES
(1, 1, 'Pelajaran', 'Buku pelajaran sekolah', '2025-10-22 18:05:32'),
(2, 1, 'Novel', 'Buku bacaan umum', '2025-10-22 18:05:32'),
(3, 1, 'Komik', 'Buku Cerita Bergambar', '2025-10-26 12:21:33'),
(4, 1, 'Buku Cerita', '', '2025-10-28 05:01:15'),
(5, 1, 'Biografi', '', '2025-10-28 05:01:31');

-- --------------------------------------------------------

--
-- Table structure for table `doc_numbering`
--
-- Creation: Oct 22, 2025 at 11:05 AM
--

DROP TABLE IF EXISTS `doc_numbering`;
CREATE TABLE IF NOT EXISTS `doc_numbering` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `school_id` bigint(20) UNSIGNED NOT NULL,
  `module_code` varchar(50) NOT NULL,
  `prefix` varchar(20) NOT NULL,
  `last_number` int(10) UNSIGNED DEFAULT 0,
  `last_year` year(4) DEFAULT NULL,
  `last_month` tinyint(4) DEFAULT NULL,
  `format_pattern` varchar(100) DEFAULT '{PREFIX}/{YEAR}/{MONTH}/{NUM}',
  `pad_length` int(11) DEFAULT 4,
  `auto_reset` enum('none','monthly','yearly') DEFAULT 'monthly',
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `school_id` (`school_id`,`module_code`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `doc_numbering`:
--   `school_id`
--       `schools` -> `id`
--

--
-- Dumping data for table `doc_numbering`
--

INSERT INTO `doc_numbering` (`id`, `school_id`, `module_code`, `prefix`, `last_number`, `last_year`, `last_month`, `format_pattern`, `pad_length`, `auto_reset`, `updated_at`) VALUES
(1, 1, 'BOOK_LOAN', 'LOAN', 6, '2025', 10, '{PREFIX}/{YEAR}/{MONTH}/{NUM}', 4, 'monthly', '2025-10-29 00:05:49'),
(2, 1, 'BOOK_RETURN', 'RTRN', 0, '2025', 10, '{PREFIX}/{YEAR}/{MONTH}/{NUM}', 4, 'monthly', '2025-10-22 18:05:32'),
(3, 1, 'BOOK', 'BOOK', 4, '2025', 10, '{PREFIX}/{YEAR}/{MONTH}/{NUM}', 5, 'monthly', '2025-10-28 02:59:57'),
(4, 1, 'RAK', 'RAK', 1, '2025', 10, '{PREFIX}/{YEAR}/{MONTH}/{NUM}', 4, 'monthly', '2025-10-28 04:32:55');

-- --------------------------------------------------------

--
-- Table structure for table `fines_rules`
--
-- Creation: Oct 22, 2025 at 11:05 AM
--

DROP TABLE IF EXISTS `fines_rules`;
CREATE TABLE IF NOT EXISTS `fines_rules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `school_id` bigint(20) UNSIGNED NOT NULL,
  `fine_per_day` decimal(10,2) NOT NULL,
  `max_days` int(11) DEFAULT 30,
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `school_id` (`school_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `fines_rules`:
--   `school_id`
--       `schools` -> `id`
--

--
-- Dumping data for table `fines_rules`
--

INSERT INTO `fines_rules` (`id`, `school_id`, `fine_per_day`, `max_days`, `updated_at`) VALUES
(1, 1, 500.00, 30, '2025-10-22 18:05:32');

-- --------------------------------------------------------

--
-- Table structure for table `fine_payments`
--
-- Creation: Oct 27, 2025 at 03:46 AM
--

DROP TABLE IF EXISTS `fine_payments`;
CREATE TABLE IF NOT EXISTS `fine_payments` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `school_id` bigint(20) UNSIGNED NOT NULL,
  `loan_id` bigint(20) UNSIGNED NOT NULL,
  `student_id` bigint(20) UNSIGNED NOT NULL,
  `payment_date` datetime NOT NULL DEFAULT current_timestamp(),
  `amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `is_paid` tinyint(1) DEFAULT 0,
  `method` enum('cash','transfer','qris') DEFAULT 'cash',
  `note` text DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_finepayments_school` (`school_id`),
  KEY `fk_finepayments_loan` (`loan_id`),
  KEY `fk_finepayments_student` (`student_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `fine_payments`:
--   `loan_id`
--       `book_loans` -> `id`
--   `school_id`
--       `schools` -> `id`
--   `student_id`
--       `students` -> `id`
--

--
-- Dumping data for table `fine_payments`
--

INSERT INTO `fine_payments` (`id`, `school_id`, `loan_id`, `student_id`, `payment_date`, `amount`, `is_paid`, `method`, `note`, `created_at`, `updated_at`) VALUES
(1, 1, 4, 1, '2025-10-27 11:18:24', 5500.00, 1, 'cash', '', '2025-10-27 10:37:04', '2025-10-27 11:18:24'),
(2, 1, 5, 2, '2025-10-27 11:45:20', 13000.00, 0, 'cash', NULL, '2025-10-27 11:45:20', '2025-10-27 11:45:20');

-- --------------------------------------------------------

--
-- Table structure for table `schools`
--
-- Creation: Oct 22, 2025 at 11:05 AM
--

DROP TABLE IF EXISTS `schools`;
CREATE TABLE IF NOT EXISTS `schools` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `code` varchar(20) NOT NULL,
  `name` varchar(150) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `logo` varchar(255) DEFAULT NULL,
  `headmaster` varchar(100) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `schools`:
--

--
-- Dumping data for table `schools`
--

INSERT INTO `schools` (`id`, `code`, `name`, `address`, `phone`, `email`, `logo`, `headmaster`, `created_at`) VALUES
(1, 'PKBMTU', 'PKBM Telaga Ukhuwah', 'Kp Bojongkoneng Rt.01/02 80 m belakang 212 mart, Telagamurni, Kec. Cikarang Bar., Kabupaten Bekasi, Jawa Barat 17530', '0813-1987-9122', '', 'uploads/schools/logo_PKBMTU_1761676604.jpeg', '', '2025-10-22 18:05:31');

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--
-- Creation: Oct 22, 2025 at 11:05 AM
--

DROP TABLE IF EXISTS `settings`;
CREATE TABLE IF NOT EXISTS `settings` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `school_id` bigint(20) UNSIGNED NOT NULL,
  `key_name` varchar(100) NOT NULL,
  `key_value` text DEFAULT NULL,
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `school_id` (`school_id`,`key_name`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `settings`:
--   `school_id`
--       `schools` -> `id`
--

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `school_id`, `key_name`, `key_value`, `updated_at`) VALUES
(1, 1, 'max_loan_days', '7', '2025-10-22 18:05:32'),
(2, 1, 'library_name', 'PKBM Telaga Ukhuwah', '2025-10-29 02:02:47'),
(3, 1, 'print_footer_text', 'Harap mengembalikan buku tepat waktu.', '2025-10-22 18:05:32');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--
-- Creation: Oct 22, 2025 at 11:05 AM
--

DROP TABLE IF EXISTS `students`;
CREATE TABLE IF NOT EXISTS `students` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `school_id` bigint(20) UNSIGNED NOT NULL,
  `nis` varchar(20) NOT NULL,
  `name` varchar(100) NOT NULL,
  `entry_year` year(4) NOT NULL,
  `gender` enum('L','P') DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `nis` (`nis`),
  KEY `school_id` (`school_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `students`:
--   `school_id`
--       `schools` -> `id`
--

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `school_id`, `nis`, `name`, `entry_year`, `gender`, `address`, `phone`, `email`, `password`, `created_at`) VALUES
(1, 1, '20230123', 'Budi Santoso', '2023', 'L', NULL, '08123456789', NULL, 'budi123', '2025-10-22 18:05:31'),
(2, 1, '20240211', 'Siti Rahma', '2024', 'P', NULL, '08129876543', NULL, 'siti123', '2025-10-22 18:05:31'),
(3, 1, '12312488', 'Agung Perdana', '2000', 'L', NULL, '081212121212', '', '$2y$10$Penjh/l/8YLVVAY2iiOrK.Qk/nCBwYwkmM1f9tTtJBUHDFdfAu79K', '2025-10-25 14:24:52'),
(5, 1, '12312489', 'Rima', '2001', 'P', NULL, '081212676454', '', '', '2025-10-28 22:44:14'),
(6, 1, '12312490', 'Mala', '2002', 'P', NULL, '081212121212', NULL, '', '2025-10-28 22:44:14'),
(7, 1, '12312491', 'Kevin', '2003', 'L', NULL, '081212121212', NULL, '', '2025-10-28 22:44:14'),
(8, 1, '13232131321', 'Abdul Malik', '2025', 'L', NULL, '', '', '$2y$10$u7VEn3ENcAmJP1dXdSw18.EwLajE0cNzY2H4FMQEjzZG1ZvjZ29v6', '2025-10-29 00:07:07'),
(9, 1, '657563434', 'Abdullah', '2025', 'L', NULL, '', '', '$2y$10$ly9oXZYi9AeEIudlFxLpFOR..6xc1tk40JdQ/8lm3ka2uCwwr/0Lm', '2025-10-29 00:07:19'),
(10, 1, '8795645334', 'Abdul Hakim', '2025', 'L', NULL, '', '', '$2y$10$1.NhmiFNEoDcxRiID.D6qOdWZIz.denjgER35C5mdMMg.JA.HW0L2', '2025-10-29 00:07:36');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `activity_logs`
--
ALTER TABLE `activity_logs`
  ADD CONSTRAINT `activity_logs_ibfk_1` FOREIGN KEY (`school_id`) REFERENCES `schools` (`id`);

--
-- Constraints for table `admins`
--
ALTER TABLE `admins`
  ADD CONSTRAINT `admins_ibfk_1` FOREIGN KEY (`school_id`) REFERENCES `schools` (`id`);

--
-- Constraints for table `books`
--
ALTER TABLE `books`
  ADD CONSTRAINT `books_ibfk_1` FOREIGN KEY (`school_id`) REFERENCES `schools` (`id`),
  ADD CONSTRAINT `books_ibfk_2` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`),
  ADD CONSTRAINT `fk_books_location` FOREIGN KEY (`location_id`) REFERENCES `book_locations` (`id`);

--
-- Constraints for table `book_loans`
--
ALTER TABLE `book_loans`
  ADD CONSTRAINT `book_loans_ibfk_1` FOREIGN KEY (`school_id`) REFERENCES `schools` (`id`),
  ADD CONSTRAINT `book_loans_ibfk_2` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`);

--
-- Constraints for table `book_loan_details`
--
ALTER TABLE `book_loan_details`
  ADD CONSTRAINT `book_loan_details_ibfk_1` FOREIGN KEY (`loan_id`) REFERENCES `book_loans` (`id`),
  ADD CONSTRAINT `book_loan_details_ibfk_2` FOREIGN KEY (`book_id`) REFERENCES `books` (`id`);

--
-- Constraints for table `categories`
--
ALTER TABLE `categories`
  ADD CONSTRAINT `categories_ibfk_1` FOREIGN KEY (`school_id`) REFERENCES `schools` (`id`);

--
-- Constraints for table `doc_numbering`
--
ALTER TABLE `doc_numbering`
  ADD CONSTRAINT `doc_numbering_ibfk_1` FOREIGN KEY (`school_id`) REFERENCES `schools` (`id`);

--
-- Constraints for table `fines_rules`
--
ALTER TABLE `fines_rules`
  ADD CONSTRAINT `fines_rules_ibfk_1` FOREIGN KEY (`school_id`) REFERENCES `schools` (`id`);

--
-- Constraints for table `fine_payments`
--
ALTER TABLE `fine_payments`
  ADD CONSTRAINT `fk_finepayments_loan` FOREIGN KEY (`loan_id`) REFERENCES `book_loans` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_finepayments_school` FOREIGN KEY (`school_id`) REFERENCES `schools` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_finepayments_student` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `settings`
--
ALTER TABLE `settings`
  ADD CONSTRAINT `settings_ibfk_1` FOREIGN KEY (`school_id`) REFERENCES `schools` (`id`);

--
-- Constraints for table `students`
--
ALTER TABLE `students`
  ADD CONSTRAINT `students_ibfk_1` FOREIGN KEY (`school_id`) REFERENCES `schools` (`id`);


--
-- Metadata
--
USE `phpmyadmin`;

--
-- Metadata for table activity_logs
--

--
-- Metadata for table admins
--

--
-- Metadata for table books
--

--
-- Metadata for table book_loans
--

--
-- Metadata for table book_loan_details
--

--
-- Metadata for table book_locations
--

--
-- Metadata for table categories
--

--
-- Metadata for table doc_numbering
--

--
-- Metadata for table fines_rules
--

--
-- Metadata for table fine_payments
--

--
-- Metadata for table schools
--

--
-- Metadata for table settings
--

--
-- Metadata for table students
--

--
-- Metadata for database library_system
--
SET FOREIGN_KEY_CHECKS=1;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
