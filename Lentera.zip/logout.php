<?php
// ============================================================
// LIBRARY SYSTEM - LOGOUT
// ============================================================
if (session_status() === PHP_SESSION_NONE) { session_start(); }

require_once __DIR__ . "/config/db_config.php";

$user_type = $_SESSION['user_type'] ?? 'system';
$user_id   = (int)($_SESSION['user_id'] ?? 0);
$school_id = (int)($_SESSION['school_id'] ?? 0);

// Catat ke activity_logs
try {
    $sql = "INSERT INTO activity_logs (school_id, user_type, user_id, action, description)
            VALUES (?,?,?,?,?)";
    $desc = 'User logout dari sistem';
    $stmt = db()->prepare($sql);
    $stmt->bind_param("isiss", $school_id, $user_type, $user_id, $action = 'logout', $desc);
    $stmt->execute();
    $stmt->close();
} catch (Throwable $e) {
    // diamkan saja kalau gagal log
}

// Hapus semua session
session_unset();
session_destroy();

// Arahkan ke login
header("Location: login.php");
exit;
