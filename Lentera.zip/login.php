<?php
// ============================================================
// LENTERA LIBRARY SYSTEM – LOGIN PAGE (ADMIN / STAFF - FINAL VERSION)
// ============================================================
if (session_status() === PHP_SESSION_NONE) { session_start(); }
require_once __DIR__ . "/config/db_config.php";

$conn = db();

// Jika sudah login, langsung ke dashboard
if (!empty($_SESSION['auth']) && !empty($_SESSION['user_type'])) {
    header("Location: dashboard.php");
    exit;
}

// ============================================================
// 🔐 PROSES LOGIN
// ============================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');

    if ($username === '' || $password === '') {
        $_SESSION['flash_error'] = "Username dan kata sandi wajib diisi.";
        header("Location: login.php");
        exit;
    }

    // Ambil data user
    $stmt = $conn->prepare("
        SELECT a.*, s.name AS school_name
        FROM admins a
        JOIN schools s ON s.id = a.school_id
        WHERE a.username = ?
        LIMIT 1
    ");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
    $stmt->close();

    if (!$user) {
        $_SESSION['flash_error'] = "Username tidak ditemukan.";
        header("Location: login.php");
        exit;
    }

    // Verifikasi password
    if (!password_verify($password, $user['password'])) {
        $_SESSION['flash_error'] = "Kata sandi salah.";
        header("Location: login.php");
        exit;
    }

    // Set session
    $_SESSION['auth'] = true;
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['user_type'] = 'admin';
    $_SESSION['name'] = $user['name'];
    $_SESSION['role'] = $user['role'];
    $_SESSION['school_id'] = $user['school_id'];
    $_SESSION['school_name'] = $user['school_name'];
    $_SESSION['photo'] = 'assets/img/user-default.png';
    $_SESSION['flash_success'] = "Selamat datang, " . htmlspecialchars($user['name']) . "!";

    header("Location: dashboard.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Lentera | Login</title>
  <link rel="stylesheet" href="assets/css/bootstrap.min.css">
  <link rel="stylesheet" href="assets/css/bootstrap-icons.css">
  <link rel="stylesheet" href="assets/css/style.css">
  <script src="assets/js/jquery.min.js"></script>
  <script src="assets/js/bootstrap.bundle.min.js"></script>
  <script src="assets/js/sweetalert2.all.min.js"></script>
  <style>
    body { 
      background: url('assets/img/background.jpg') no-repeat center center fixed;
      background-size: cover;
      font-family: 'Inter', sans-serif;
      color: #1f2937;
    }
    .login-card { 
      max-width: 420px; 
      margin: auto; 
      margin-top: 10vh; 
      border: none; 
      border-radius: 18px; 
      box-shadow: 0 8px 28px rgba(0,0,0,0.25);
      background: rgba(255,255,255,0.65); /* semi transparan */
      backdrop-filter: blur(12px);        /* efek kaca buram */
      -webkit-backdrop-filter: blur(12px);
      padding: 2rem 2rem 2.2rem;
    }
    .login-card .logo img { 
      height: 90px; 
      width: auto; 
      display: block;
      margin: 0 auto 1rem auto;
    }
    .btn-primary { 
      background: #2563EB; 
      border: none; 
      border-radius: 8px; 
      font-weight: 600;
      transition: all 0.2s ease;
    }
    .btn-primary:hover { background: #1E40AF; transform: scale(1.02); }
    .form-control {
      border-radius: 8px;
      border-color: #cbd5e1;
    }
    .input-group-text, .btn-outline-secondary {
      border-radius: 8px;
    }
    .btn-outline-secondary {
      color: #64748b;
      border-color: #cbd5e1;
    }
    .btn-outline-secondary:hover {
      background: #f1f5f9;
    }
  </style>
</head>
<body>
<div class="container">
  <div class="card login-card">
    <div class="text-center mb-4">
      <div class="logo">
        <img src="assets/img/logo-login.png" alt="Logo Lentera">
      </div>
    </div>

    <form method="post" autocomplete="off">
      <div class="mb-3">
        <label for="username" class="form-label fw-semibold">Username</label>
        <input type="text" class="form-control" id="username" name="username" 
               placeholder="admin / staff1" autocomplete="username" required>
      </div>

      <div class="mb-3">
        <label for="password" class="form-label fw-semibold">Kata Sandi</label>
        <div class="input-group">
          <input type="password" class="form-control" id="password" name="password"
                 placeholder="••••••••" autocomplete="current-password" required>
          <button type="button" class="btn btn-outline-secondary" id="togglePassword" tabindex="-1">
            <i class="bi bi-eye"></i>
          </button>
        </div>
      </div>

      <button type="submit" class="btn btn-primary w-100 mt-2">Masuk</button>
    </form>
  </div>
</div>

<!-- ============================================================ -->
<!-- Flash Alerts & Password Toggle -->
<!-- ============================================================ -->
<script>
function alertSuccess(msg){
  Swal.fire({ icon:'success', title:'Berhasil', text:msg, confirmButtonColor:'#2563EB' });
}
function alertError(msg){
  Swal.fire({ icon:'error', title:'Gagal', text:msg, confirmButtonColor:'#2563EB' });
}

// Toggle Lihat / Sembunyikan Password
$("#togglePassword").on("click", function() {
  const input = $("#password");
  const icon = $(this).find("i");
  if (input.attr("type") === "password") {
    input.attr("type", "text");
    icon.removeClass("bi-eye").addClass("bi-eye-slash");
  } else {
    input.attr("type", "password");
    icon.removeClass("bi-eye-slash").addClass("bi-eye");
  }
});
</script>

<?php if (!empty($_SESSION['flash_success'])): ?>
<script> alertSuccess("<?= addslashes($_SESSION['flash_success']); ?>"); </script>
<?php unset($_SESSION['flash_success']); endif; ?>

<?php if (!empty($_SESSION['flash_error'])): ?>
<script> alertError("<?= addslashes($_SESSION['flash_error']); ?>"); </script>
<?php unset($_SESSION['flash_error']); endif; ?>

</body>
</html>
