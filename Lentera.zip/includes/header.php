<?php
// ============================================================
// LENTERA LIBRARY SYSTEM – GLOBAL HEADER (MINIA-COMPATIBLE FINAL FIX)
// ============================================================

if (session_status() === PHP_SESSION_NONE) { session_start(); }
require_once __DIR__ . '/../config/constants.php';

// Preferensi dari session (bisa diubah via localStorage oleh enhancer.js)
$sidebar_size = $_SESSION['sidebar_size'] ?? 'lg';
$dark_mode    = $_SESSION['dark_mode'] ?? false;

// Judul halaman
$pageTitle = $pageTitle ?? APP_NAME;
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="theme-color" content="#1d4ed8">

  <title><?= htmlspecialchars($pageTitle) ?> | <?= APP_SHORT ?></title>
  <meta name="description" content="Sistem Informasi Perpustakaan Lentera - <?= htmlspecialchars($pageTitle) ?>">
  <meta name="author" content="Lentera Library System">
  <link rel="icon" href="<?= BASE_URL ?>/assets/img/favicon.png" type="image/png">

  <!-- ========================================================= -->
  <!-- CSS LIBRARIES -->
  <!-- ========================================================= -->
  <link href="<?= BASE_URL ?>/assets/css/bootstrap.min.css" rel="stylesheet">
  <link href="<?= BASE_URL ?>/assets/css/bootstrap-icons.css" rel="stylesheet">
  <link href="<?= BASE_URL ?>/assets/css/sweetalert2.min.css" rel="stylesheet">

  <!-- DataTables -->
  <link href="<?= BASE_URL ?>/assets/css/dataTables.bootstrap5.min.css" rel="stylesheet">
  <link href="<?= BASE_URL ?>/assets/css/responsive.bootstrap5.min.css" rel="stylesheet">

  <!-- Animations & Layout -->
  <link href="<?= BASE_URL ?>/assets/css/animate.min.css" rel="stylesheet">
  <link href="<?= BASE_URL ?>/assets/css/layout.css" rel="stylesheet">
  <link href="<?= BASE_URL ?>/assets/css/style.css" rel="stylesheet">

  <!-- ========================================================= -->
  <!-- GOOGLE FONTS -->
  <!-- ========================================================= -->
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap" rel="stylesheet">

  <!-- ========================================================= -->
  <!-- GLOBAL VARIABLES FOR JS -->
  <!-- ========================================================= -->
  <script>
  const BASE_URL  = "<?= BASE_URL ?>";
  const APP_NAME  = "<?= APP_NAME ?>";
  const APP_SHORT = "<?= APP_SHORT ?>";
  </script>

  <!-- ========================================================= -->
  <!-- INLINE INIT SCRIPTS (Sidebar & Dark Mode) -->
  <!-- ========================================================= -->
  <script>
  document.addEventListener("DOMContentLoaded", function() {
    // Set sidebar size dari localStorage
    const savedSize = localStorage.getItem("sidebar-size") || "lg";
    document.body.setAttribute("data-sidebar-size", savedSize);

    // Aktifkan dark mode jika tersimpan
    if (localStorage.getItem("darkMode") === "1") {
      document.body.classList.add("dark-mode");
    }

    // Tampilkan body setelah semua siap
    document.body.classList.add("ready");
  });
  </script>

  <!-- ========================================================= -->
  <!-- STYLE FALLBACK (Anti Flicker saat load pertama) -->
  <!-- ========================================================= -->
  <style>
    body {
      font-family: 'Inter', sans-serif;
      visibility: hidden;
      opacity: 0;
      transition: opacity .25s ease-in-out;
    }
    body.ready {
      visibility: visible;
      opacity: 1;
    }

    /* Fix padding transition saat sidebar collapse */
    [data-sidebar-size="sm"] #mainContent {
      transition: all .3s ease;
    }
  </style>
</head>

<!-- ========================================================= -->
<!-- BODY STRUCTURE -->
<!-- ========================================================= -->
<body data-sidebar-size="<?= htmlspecialchars($sidebar_size) ?>" class="<?= $dark_mode ? 'dark-mode' : '' ?>">
