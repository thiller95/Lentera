<?php
// ============================================================
// LENTERA LIBRARY SYSTEM – GLOBAL FOOTER (FINAL FIX + GLOBAL SELECT2 SUPPORT)
// ============================================================
require_once __DIR__ . '/../config/constants.php';
?>
  <!-- ======================================================== -->
  <!-- FOOTER AREA -->
  <!-- ======================================================== -->
  <footer class="footer text-center py-3 mt-auto">
    <p class="mb-0 small text-muted">
      <?= APP_FOOTER ?> &nbsp; | &nbsp; Versi <?= APP_VERSION ?>
    </p>
  </footer>

  <!-- ======================================================== -->
  <!-- GLOBAL JAVASCRIPT LIBRARIES (ORDERED) -->
  <!-- ======================================================== -->

  <!-- 1️⃣ jQuery (HARUS PALING ATAS UNTUK SEMUA PLUGIN) -->
  <script src="<?= BASE_URL ?>/assets/js/jquery.min.js"></script>

  <!-- 3️⃣ Bootstrap & SweetAlert -->
  <script src="<?= BASE_URL ?>/assets/js/bootstrap.bundle.min.js"></script>
  <script src="<?= BASE_URL ?>/assets/js/sweetalert2.all.min.js"></script>

  <!-- 4️⃣ DataTables Core -->
  <script src="<?= BASE_URL ?>/assets/js/jquery.dataTables.min.js"></script>
  <script src="<?= BASE_URL ?>/assets/js/dataTables.bootstrap5.min.js"></script>

  <!-- 5️⃣ DataTables Responsive -->
  <script src="<?= BASE_URL ?>/assets/js/dataTables.responsive.min.js"></script>
  <script src="<?= BASE_URL ?>/assets/js/responsive.bootstrap5.min.js"></script>

  <!-- 6️⃣ Charts & Other Libraries -->
  <script src="<?= BASE_URL ?>/assets/js/chart.min.js"></script>

  <!-- 7️⃣ Layout Handler -->
  <script src="<?= BASE_URL ?>/assets/js/layout.js"></script>

  <!-- 8️⃣ Global Main Script (Auto-init Select2 + Alerts) -->
  <script src="<?= BASE_URL ?>/assets/js/main.js"></script>

  <!-- ======================================================== -->
  <!-- SWEETALERT GLOBAL HELPERS -->
  <!-- ======================================================== -->
  <script>
  // ============================================================
  // 💬 SweetAlert & Toast Helpers (Reusable)
  // ============================================================

  // ✅ Success
  window.alertSuccess = function(message, title = "Berhasil") {
    Swal.fire({
      icon: "success",
      title,
      text: message,
      timer: 2000,
      showConfirmButton: false
    });
  };

  // ❌ Error
  window.alertError = function(message, title = "Gagal") {
    Swal.fire({
      icon: "error",
      title,
      text: message,
      confirmButtonText: "OK"
    });
  };

  // ℹ️ Info
  window.alertInfo = function(message, title = "Informasi") {
    Swal.fire({
      icon: "info",
      title,
      text: message
    });
  };

  // ⚠️ Confirm (callback-based) – FINAL FIX: HTML rendering force-enabled
  window.confirmAction = function(message, callback, title = "Konfirmasi") {
    Swal.fire({
      title: title,
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#2563EB",
      cancelButtonColor: "#6B7280",
      confirmButtonText: "Ya, Lanjutkan",
      cancelButtonText: "Batal",
      html: `<div style="font-size:15px;">${message}</div>`
    }).then((result) => {
      if (result.isConfirmed && typeof callback === "function") callback();
    });
  };

  // 🔔 Toast notification (top-right)
  window.toast = function(message, type = "success") {
    const Toast = Swal.mixin({
      toast: true,
      position: "top-end",
      showConfirmButton: false,
      timer: 2500,
      timerProgressBar: true
    });
    Toast.fire({ icon: type, title: message });
  };
  </script>

  <!-- ======================================================== -->
  <!-- GLOBAL FLASH MESSAGE HANDLER (AUTO SWEETALERT) -->
  <!-- ======================================================== -->
  <?php if (!empty($_SESSION['flash_success'])): ?>
    <script>
      document.addEventListener("DOMContentLoaded", function() {
        alertSuccess("<?= addslashes($_SESSION['flash_success']); ?>");
      });
    </script>
    <?php unset($_SESSION['flash_success']); ?>
  <?php endif; ?>

  <?php if (!empty($_SESSION['flash_error'])): ?>
    <script>
      document.addEventListener("DOMContentLoaded", function() {
        alertError("<?= addslashes($_SESSION['flash_error']); ?>");
      });
    </script>
    <?php unset($_SESSION['flash_error']); ?>
  <?php endif; ?>

  <!-- ======================================================== -->
  <!-- FOOTER STYLES -->
  <!-- ======================================================== -->
  <style>
    .footer {
      background: var(--color-light, #fff);
      border-top: 1px solid #e5e7eb;
      color: #6b7280;
      transition: background 0.3s ease, color 0.3s ease;
    }
    body.dark-mode .footer {
      background: #1e293b;
      border-top: 1px solid #334155;
      color: #cbd5e1;
    }

    /* 🧩 Select2 Z-Index Fix (biar dropdown gak ketutup card/modal) */
    .select2-container {
      z-index: 2000 !important;
    }
  </style>

</body>
</html>
