<?php
// ============================================================
// SIDEBAR – Lentera Library System (RBAC + Full-Width Highlight + Soft Glow + Auto-Hide Scrollbar)
// ============================================================
require_once __DIR__ . '/../config/constants.php';
if (session_status() === PHP_SESSION_NONE) session_start();
$current_page = basename($_SERVER['PHP_SELF']);
$user_role = $_SESSION['role'] ?? 'staff'; // Default role
?>
<style>
/* ============================================================
   🌙 SIDEBAR BASE LAYOUT
   ============================================================ */
#sidebar {
  width: 250px;
  background: <?= THEME_DARK ?>;
  color: #fff;
  position: fixed;
  top: 0; bottom: 0; left: 0;
  z-index: 1040;
  display: flex;
  flex-direction: column;
  overflow-x: hidden;
  overflow-y: hidden; /* Auto-hide scrollbar */
  transition: width .3s ease, background .3s ease, box-shadow .3s ease;
  box-shadow: 4px 0 15px rgba(0, 0, 0, 0.08);
}
#sidebar:hover {
  overflow-y: auto; /* Show scrollbar only when hovered */
}

/* ============================================================
   🌪️ SCROLLBAR (Minimalist + Auto-Hide)
   ============================================================ */
#sidebar::-webkit-scrollbar { width: 6px; }
#sidebar::-webkit-scrollbar-track { background: transparent; }
#sidebar::-webkit-scrollbar-thumb {
  background-color: rgba(255,255,255,0.18);
  border-radius: 4px;
  transition: background-color 0.2s ease;
}
#sidebar::-webkit-scrollbar-thumb:hover { background-color: rgba(255,255,255,0.35); }

body[data-sidebar-size="sm"] #sidebar {
  width: 70px;
  overflow: visible !important;
  box-shadow: 2px 0 8px rgba(0, 0, 0, 0.05);
}
body.dark-mode #sidebar {
  background: rgba(15, 23, 42, 0.88);
  backdrop-filter: blur(6px);
}

/* ============================================================
   🏷️ BRAND
   ============================================================ */
#sidebar .brand {
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 14px 16px;
  border-bottom: 1px solid rgba(255,255,255,0.08);
  position: sticky;
  top: 0;
  background: inherit;
  z-index: 10;
}
#sidebar .brand img { height: 26px; margin-right: 8px; }
#sidebar .brand span { font-size: 17px; font-weight: 600; color: #fff; }
body[data-sidebar-size="sm"] #sidebar .brand span { display: none; }

/* ============================================================
   📚 NAVIGATION MENU
   ============================================================ */
#sidebar .nav {
  list-style: none;
  margin: 0;
  padding: 10px 0 50px;
  flex: 1;
}
#sidebar .nav li { position: relative; }

#sidebar .nav a {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 10px 20px;
  text-decoration: none;
  color: #dbeafe;
  position: relative;
  transition: all 0.25s ease;
  z-index: 1;
}

/* ============================================================
   ✨ FULL-WIDTH HIGHLIGHT + GLOW BORDER
   ============================================================ */
#sidebar .nav a::before {
  content: "";
  position: absolute;
  top: 0; left: 0; right: 0; bottom: 0;
  background: transparent;
  border-left: 3px solid transparent;
  border-radius: 0;
  transition: all 0.25s ease;
  z-index: -1;
}
#sidebar .nav a:hover::before {
  background: rgba(255,255,255,0.1);
  border-left-color: <?= THEME_PRIMARY ?>;
  box-shadow: 0 0 8px 1px <?= THEME_PRIMARY ?>33;
}
#sidebar .nav a.active::before {
  background: <?= THEME_PRIMARY ?>;
  border-left-color: <?= THEME_PRIMARY ?>;
  box-shadow: 0 0 10px 2px <?= THEME_PRIMARY ?>55;
}

#sidebar .nav a:hover,
#sidebar .nav a.active {
  color: #fff;
  font-weight: 600;
  transform: translateX(2px);
}

#sidebar .nav i {
  font-size: 18px;
  width: 24px;
  text-align: center;
}

/* ============================================================
   💬 SLIDE LABEL (Collapsed View)
   ============================================================ */
body[data-sidebar-size="sm"] #sidebar .nav a {
  justify-content: center;
}
body[data-sidebar-size="sm"] #sidebar .nav a span {
  position: absolute;
  left: 70px;
  top: 0;
  height: 100%;
  display: flex;
  align-items: center;
  padding: 0 14px;
  background: rgba(30,41,59,0.95);
  color: #fff;
  border-radius: 0 8px 8px 0;
  white-space: nowrap;
  opacity: 0;
  transform: translateX(-10px);
  transition: all 0.2s ease;
  pointer-events: none;
  min-width: 160px;
  box-shadow: 4px 0 10px rgba(0,0,0,0.1);
  z-index: 2000;
}
body[data-sidebar-size="sm"] #sidebar .nav a:hover span {
  opacity: 1;
  transform: translateX(0);
  pointer-events: auto;
}

/* ============================================================
   📂 SECTION TITLE
   ============================================================ */
#sidebar .section-title {
  font-size: 10px;
  text-transform: uppercase;
  opacity: .6;
  letter-spacing: .5px;
  padding: 10px 20px 5px;
  color: #cbd5e1;
}
body[data-sidebar-size="sm"] #sidebar .section-title { display: none; }
</style>

<!-- ============================================================
     SIDEBAR STRUCTURE
     ============================================================ -->
<div id="sidebar">
  <div class="brand">
    <img src="<?= BASE_URL ?>/assets/img/logo.png" alt="Logo">
    <span><?= APP_SHORT ?></span>
  </div>

  <ul class="nav">
    <!-- Dashboard -->
    <li>
      <a href="<?= BASE_URL ?>/dashboard.php"
         class="<?= $current_page == 'dashboard.php' ? 'active' : '' ?>">
        <i class="bi bi-house"></i> <span>Dashboard</span>
      </a>
    </li>

    <!-- Admin Only -->
    <?php if ($user_role === 'admin'): ?>
      <li>
        <a href="<?= BASE_URL ?>/doc_numbering/doc-numbering.php"
           class="<?= $current_page == 'doc-numbering.php' ? 'active' : '' ?>">
          <i class="bi bi-hash"></i> <span>Penomoran Dokumen</span>
        </a>
      </li>
    <?php endif; ?>

    <!-- Master Data -->
    <li class="section-title">Master Data</li>

    <li>
      <a href="<?= BASE_URL ?>/books/books.php"
         class="<?= $current_page == 'books.php' ? 'active' : '' ?>">
        <i class="bi bi-book"></i> <span>Data Buku</span>
      </a>
    </li>

    <li>
      <a href="<?= BASE_URL ?>/books/book-locations.php"
         class="<?= $current_page == 'book-locations.php' ? 'active' : '' ?>">
        <i class="bi bi-bookshelf"></i> <span>Rak / Lokasi Buku</span>
      </a>
    </li>

    <li>
      <a href="<?= BASE_URL ?>/categories/categories.php"
         class="<?= $current_page == 'categories.php' ? 'active' : '' ?>">
        <i class="bi bi-tags"></i> <span>Kategori Buku</span>
      </a>
    </li>

    <li>
      <a href="<?= BASE_URL ?>/students/students.php"
         class="<?= $current_page == 'students.php' ? 'active' : '' ?>">
        <i class="bi bi-people"></i> <span>Data Siswa</span>
      </a>
    </li>

    <!-- Transaksi -->
    <li class="section-title">Transaksi</li>
    <li>
      <a href="<?= BASE_URL ?>/loans/loans.php"
         class="<?= ($current_page == 'loans.php' || str_starts_with($current_page, 'loans-')) ? 'active' : '' ?>">
        <i class="bi bi-journal-arrow-up"></i> <span>Peminjaman</span>
      </a>
    </li>
    <li>
      <a href="<?= BASE_URL ?>/fines/fines-payments.php"
         class="<?= ($current_page == 'fines-payments.php' || str_starts_with($current_page, 'fines-payment')) ? 'active' : '' ?>">
        <i class="bi bi-cash-coin"></i> <span>Pembayaran Denda</span>
      </a>
    </li>

    <!-- Laporan -->
    <li class="section-title">Laporan</li>
    <li>
      <a href="<?= BASE_URL ?>/reports/reports-loans.php"
         class="<?= $current_page == 'reports-loans.php' ? 'active' : '' ?>">
        <i class="bi bi-file-earmark-text"></i> <span>Laporan Peminjaman</span>
      </a>
    </li>
    <li>
      <a href="<?= BASE_URL ?>/fines/fines-report-student.php"
         class="<?= $current_page == 'fines-report-student.php' ? 'active' : '' ?>">
        <i class="bi bi-people"></i> <span>Laporan Denda Siswa</span>
      </a>
    </li>

    <!-- Pengaturan -->
    <li class="section-title">Pengaturan</li>
    <?php if ($user_role === 'admin'): ?>
      <li>
        <a href="<?= BASE_URL ?>/schools/schools.php"
           class="<?= $current_page == 'schools.php' ? 'active' : '' ?>">
          <i class="bi bi-building"></i> <span>Data Sekolah</span>
        </a>
      </li>
      <li>
        <a href="<?= BASE_URL ?>/admins/admins.php"
           class="<?= $current_page == 'admins.php' ? 'active' : '' ?>">
          <i class="bi bi-person-gear"></i> <span>Data Admin</span>
        </a>
      </li>
      <li>
        <a href="<?= BASE_URL ?>/settings/system-settings.php"
           class="<?= $current_page == 'system-settings.php' ? 'active' : '' ?>">
          <i class="bi bi-gear"></i> <span>Pengaturan Sistem</span>
        </a>
      </li>
    <?php endif; ?>

    <!-- Publik -->
    <li>
      <a href="<?= BASE_URL ?>/public/public_search.php" target="_blank">
        <i class="bi bi-search"></i> <span>Pencarian Publik</span>
      </a>
    </li>
  </ul>
</div>
