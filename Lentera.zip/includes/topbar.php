<?php
// ============================================================
// TOPBAR – Lentera Library System (Polished Professional Fix)
// ============================================================

if (session_status() === PHP_SESSION_NONE) { session_start(); }
require_once __DIR__ . '/../config/constants.php';

$user_name   = $_SESSION['name'] ?? 'Guest';
$user_role   = ucfirst($_SESSION['user_type'] ?? 'Admin');
$school_name = $_SESSION['school_name'] ?? 'Perpustakaan';
$user_photo = !empty($_SESSION['photo'])
    ? BASE_URL . '/assets/img/uploads/user/' . basename($_SESSION['photo'])
    : BASE_URL . '/assets/img/user-default.png';

?>
<style>
/* ============================================================
   ✨ TOPBAR (Polished Minia-Compatible Version)
   ============================================================ */
#topbar {
  height: 60px;
  background: var(--color-primary);
  color: #fff;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 20px 0 260px; /* kanan dikasih 20px biar lega */
  position: sticky;
  top: 0;
  z-index: 900;
  transition: padding-left 0.3s ease;
}
body[data-sidebar-size="sm"] #topbar { padding-left: 90px; }

#topbar .left-group {
  display: flex;
  align-items: center;
  gap: 12px;
}
#topbar .school-name {
  font-weight: 600;
  font-size: 15px;
  letter-spacing: 0.3px;
  white-space: nowrap;
}

/* Tombol Toggle Sidebar */
#vertical-menu-btn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 38px;
  height: 38px;
  border-radius: 8px;
  border: none;
  background: rgba(255,255,255,0.18);
  color: #fff;
  cursor: pointer;
  transition: all .25s ease;
  margin-left: 4px; /* geser dikit ke kanan biar sejajar rapi */
}
#vertical-menu-btn:hover {
  background: rgba(255,255,255,0.28);
  transform: scale(1.05);
}
#vertical-menu-btn i {
  font-size: 20px;
}

/* User Menu */
#topbar .user-menu {
  display: flex;
  align-items: center;
  gap: 8px;
}
#topbar .user-menu img {
  width: 36px;
  height: 36px;
  border-radius: 50%;
  object-fit: cover;
  border: 2px solid rgba(255,255,255,0.35);
  transition: all 0.25s ease;
  cursor: pointer;
}
#topbar .user-menu img:hover {
  transform: scale(1.05);
  border-color: rgba(255,255,255,0.5);
}
#topbar .dropdown-toggle {
  color: #fff;
  font-weight: 600;
  cursor: pointer;
  font-size: 14px;
}
#topbar .dropdown-toggle:hover {
  opacity: 0.9;
}

/* Dropdown Style */
#topbar .dropdown-menu {
  border-radius: 10px;
  border: none;
  box-shadow: 0 8px 22px rgba(0,0,0,0.15);
  font-size: 14px;
  padding: 4px 0;
}
#topbar .dropdown-menu a {
  display: flex;
  align-items: center;
  gap: 8px;
  color: #111827;
  padding: 8px 14px;
  transition: background .2s ease, color .2s ease;
}
#topbar .dropdown-menu a:hover {
  background: rgba(37,99,235,0.1);
  color: #1d4ed8;
}
#topbar .dropdown-divider {
  margin: 4px 0;
}
#topbar .dropdown-menu .text-muted {
  font-size: 13px;
}

/* Dark Mode */
body.dark-mode #topbar {
  background: #1d4ed8;
}
body.dark-mode #topbar .dropdown-menu {
  background: #1e293b;
  color: #e2e8f0;
  box-shadow: 0 6px 16px rgba(255,255,255,0.08);
}
body.dark-mode #topbar .dropdown-menu a {
  color: #f1f5f9;
}
body.dark-mode #topbar .dropdown-menu a:hover {
  background: rgba(255,255,255,0.1);
  color: #fff;
}
</style>

<div id="topbar">
  <div class="left-group">
    <!-- Tombol toggle sidebar -->
    <button type="button" id="vertical-menu-btn" title="Tutup / Buka Sidebar">
      <i class="bi bi-layout-sidebar-inset"></i>
    </button>
    <div class="school-name"><?= htmlspecialchars($school_name) ?></div>
  </div>

  <div class="user-menu dropdown">
    <img src="<?= $user_photo ?>" alt="User" id="profilePhoto" data-bs-toggle="dropdown">
    <span class="dropdown-toggle" data-bs-toggle="dropdown">
      <?= htmlspecialchars($user_name) ?>
    </span>
    <ul class="dropdown-menu dropdown-menu-end">
      <li class="px-3 py-2 text-muted small">
        <i class="bi bi-person-badge me-1"></i> <?= htmlspecialchars($user_role) ?>
      </li>
      <li><hr class="dropdown-divider"></li>
      <li><a class="dropdown-item" href="<?= BASE_URL ?>/profile.php"><i class="bi bi-person-circle"></i> Profil</a></li>
      <li><a class="dropdown-item text-danger" href="<?= BASE_URL ?>/logout.php"><i class="bi bi-box-arrow-right"></i> Logout</a></li>
    </ul>
  </div>
</div>

<script>
/* ============================================================
   Dark Mode Sync (LocalStorage)
   ============================================================ */
(function(){
  const body = document.body;
  function setDark(active){ body.classList.toggle('dark-mode', active===true); }
  setDark(localStorage.getItem('darkMode') === '1');
  window.addEventListener('storage', e => { if(e.key==='darkMode') setDark(e.newValue==='1'); });
})();
</script>
