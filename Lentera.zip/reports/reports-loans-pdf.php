<?php
// ============================================================
// LENTERA LIBRARY SYSTEM – LAPORAN PEMINJAMAN BUKU (PDF EXPORT - SUPPORT TAHUN PENUH)
// ============================================================

// 🚫 Hindari output sebelum PDF
ob_start();

if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . "/../config/session_guard.php";
require_once __DIR__ . "/../config/db_config.php";
require_once __DIR__ . "/../assets/vendor/fpdf/fpdf.php";

$conn = db();
$school_id = $_SESSION['school_id'] ?? 0;
$month = (int)($_GET['month'] ?? date('m'));
$year  = (int)($_GET['year'] ?? date('Y'));

// ============================================================
// 🗓️ Nama Bulan Indonesia
// ============================================================
$bulanList = [
  1=>'Januari',2=>'Februari',3=>'Maret',4=>'April',5=>'Mei',6=>'Juni',
  7=>'Juli',8=>'Agustus',9=>'September',10=>'Oktober',11=>'November',12=>'Desember'
];
$monthName = $bulanList[$month] ?? '';
$periodeLabel = ($month === 0)
  ? "Tahun $year"
  : "$monthName $year";

// ============================================================
// 🏫 DATA SEKOLAH
// ============================================================
$stmtSchool = $conn->prepare("SELECT name, logo, address, phone, email FROM schools WHERE id = ? LIMIT 1");
$stmtSchool->bind_param("i", $school_id);
$stmtSchool->execute();
$school = $stmtSchool->get_result()->fetch_assoc();

// ============================================================
// 📚 DATA PEMINJAMAN
// ============================================================
// Jika month=0, tampilkan seluruh data tahun tersebut
if ($month === 0) {
    $stmt = $conn->prepare("
      SELECT l.loan_code, l.loan_date, l.due_date, l.status, s.name AS student_name
      FROM book_loans l
      JOIN students s ON s.id = l.student_id
      WHERE l.school_id = ?
        AND YEAR(l.loan_date) = ?
      ORDER BY l.loan_date ASC
    ");
    $stmt->bind_param("ii", $school_id, $year);
} else {
    $stmt = $conn->prepare("
      SELECT l.loan_code, l.loan_date, l.due_date, l.status, s.name AS student_name
      FROM book_loans l
      JOIN students s ON s.id = l.student_id
      WHERE l.school_id = ?
        AND MONTH(l.loan_date) = ?
        AND YEAR(l.loan_date) = ?
      ORDER BY l.loan_date ASC
    ");
    $stmt->bind_param("iii", $school_id, $month, $year);
}
$stmt->execute();
$res = $stmt->get_result();

// ============================================================
// 🖨️ SETUP PDF
// ============================================================
$pdf = new FPDF('P', 'mm', 'A4');
$pdf->AddPage();
$pdf->SetTitle("Laporan Peminjaman Buku - $periodeLabel");
$pdf->SetMargins(10, 10, 10);
$pdf->SetAutoPageBreak(true, 15);

// ============================================================
// 🏫 HEADER SEKOLAH (Auto-wrap + posisi aman)
// ============================================================
$logoPath = "../assets/img/logo.png";
if (!empty($school['logo']) && file_exists(__DIR__ . "/../" . $school['logo'])) {
    $logoPath = __DIR__ . "/../" . $school['logo'];
}

$pdf->SetY(10);
$pdf->Image($logoPath, 12, 10, 22);
$pdf->SetXY(38, 10);

$pdf->SetFont('Arial', 'B', 14);
$pdf->MultiCell(155, 7, iconv('UTF-8', 'ISO-8859-1//TRANSLIT', $school['name'] ?? 'Perpustakaan Lentera'), 0, 'L');

$pdf->SetFont('Arial', '', 9);
$alamat = trim($school['address'] ?? '');
if (!empty($school['phone']) || !empty($school['email'])) {
    $alamat .= "\nTelp: " . ($school['phone'] ?? '-') . " | Email: " . ($school['email'] ?? '-');
}
$pdf->SetX(38);
$pdf->MultiCell(155, 5, iconv('UTF-8', 'ISO-8859-1//TRANSLIT', $alamat), 0, 'L');

$pdf->Ln(3);
$pdf->SetDrawColor(0, 0, 0);
$pdf->Line(10, $pdf->GetY(), 200, $pdf->GetY());
$pdf->Ln(6);

// ============================================================
// 📋 JUDUL LAPORAN
// ============================================================
$pdf->SetFont('Arial', 'B', 12);
$titleText = "LAPORAN PEMINJAMAN BUKU – $periodeLabel";
$pdf->Cell(190, 8, iconv('UTF-8', 'ISO-8859-1//TRANSLIT', $titleText), 0, 1, 'C');
$pdf->Ln(5);

// ============================================================
// 🧾 HEADER TABEL
// ============================================================
$pdf->SetFont('Arial', 'B', 10);
$pdf->SetFillColor(230, 230, 230);
$pdf->Cell(10, 8, 'No', 1, 0, 'C', true);
$pdf->Cell(35, 8, 'Kode', 1, 0, 'C', true);
$pdf->Cell(65, 8, 'Nama Siswa', 1, 0, 'C', true);
$pdf->Cell(30, 8, 'Tgl Pinjam', 1, 0, 'C', true);
$pdf->Cell(30, 8, 'Jatuh Tempo', 1, 0, 'C', true);
$pdf->Cell(20, 8, 'Status', 1, 1, 'C', true);

// ============================================================
// 📄 ISI DATA
// ============================================================
$pdf->SetFont('Arial', '', 9);
$no = 1;
if ($res->num_rows === 0) {
    $pdf->Cell(190, 10, iconv('UTF-8', 'ISO-8859-1//TRANSLIT', "Tidak ada data peminjaman untuk periode ini."), 1, 1, 'C');
} else {
    while ($row = $res->fetch_assoc()) {
        $loanDate = date('d/m/Y', strtotime($row['loan_date']));
        $dueDate  = date('d/m/Y', strtotime($row['due_date']));
        $status   = ucfirst($row['status']);

        $pdf->Cell(10, 8, $no++, 1, 0, 'C');
        $pdf->Cell(35, 8, iconv('UTF-8', 'ISO-8859-1//TRANSLIT', $row['loan_code']), 1, 0);

        // Nama siswa pakai MultiCell agar tidak terpotong
        $x = $pdf->GetX();
        $y = $pdf->GetY();
        $pdf->MultiCell(65, 8, iconv('UTF-8', 'ISO-8859-1//TRANSLIT', substr($row['student_name'], 0, 45)), 1, 'L');
        $height = $pdf->GetY() - $y;
        if ($height < 8) $height = 8;
        $pdf->SetXY($x + 65, $y);

        $pdf->Cell(30, $height, $loanDate, 1, 0, 'C');
        $pdf->Cell(30, $height, $dueDate, 1, 0, 'C');
        $pdf->Cell(20, $height, iconv('UTF-8', 'ISO-8859-1//TRANSLIT', $status), 1, 1, 'C');
    }
}

// ============================================================
// 🕒 FOOTER CETAK
// ============================================================
$pdf->Ln(5);
$pdf->SetFont('Arial', 'I', 8);
$pdf->Cell(0, 10, iconv('UTF-8', 'ISO-8859-1//TRANSLIT', 'Dicetak pada: ' . date('d/m/Y H:i')), 0, 1, 'R');

// ============================================================
// 🧾 OUTPUT PDF
// ============================================================
$fileName = "Laporan_Peminjaman_" . str_replace(' ', '_', $periodeLabel) . ".pdf";
ob_end_clean(); // 🚿 bersihkan buffer agar tidak ada output lain
$pdf->Output('I', $fileName);
exit;
