<?php
// ============================================================
// LENTERA LIBRARY SYSTEM – LAPORAN PEMINJAMAN BUKU (FINAL STABLE + CETAK TAHUN PENUH)
// ============================================================
$pageTitle = "Laporan Peminjaman Buku";

if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . "/../config/session_guard.php";
require_once __DIR__ . "/../config/db_config.php";
require_once __DIR__ . "/../includes/header.php";
require_once __DIR__ . "/../includes/sidebar.php";
require_once __DIR__ . "/../includes/topbar.php";

if ($_SESSION['user_type'] !== 'admin') {
    header("Location: ../dashboard.php");
    exit;
}

$conn = db();
$school_id = $_SESSION['school_id'] ?? 0;

// ============================================================
// FILTER BULAN & TAHUN
// ============================================================
$month = isset($_GET['month']) ? (int)$_GET['month'] : date('m');
$year  = isset($_GET['year']) ? (int)$_GET['year'] : date('Y');

// jika dipilih 0 = semua bulan
$monthCondition = $month > 0 ? "AND MONTH(l.loan_date) = ?" : "";
$sql = "
  SELECT l.*, s.name AS student_name
  FROM book_loans l
  JOIN students s ON s.id = l.student_id
  WHERE l.school_id = ?
    $monthCondition
    AND YEAR(l.loan_date) = ?
  ORDER BY l.loan_date ASC
";

// ============================================================
// AMBIL DATA SEKOLAH (LOGO & NAMA)
// ============================================================
$stmtSchool = $conn->prepare("SELECT name, logo FROM schools WHERE id = ? LIMIT 1");
$stmtSchool->bind_param("i", $school_id);
$stmtSchool->execute();
$school = $stmtSchool->get_result()->fetch_assoc();

// ============================================================
// AMBIL DATA PEMINJAMAN
// ============================================================
if ($month > 0) {
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iii", $school_id, $month, $year);
} else {
    // tanpa filter bulan (semua bulan)
    $stmt = $conn->prepare(str_replace("AND MONTH(l.loan_date) = ?", "", $sql));
    $stmt->bind_param("ii", $school_id, $year);
}
$stmt->execute();
$res = $stmt->get_result();
$noData = ($res->num_rows === 0);

// Nama bulan untuk tampilan
if ($month === 0) {
    $periodeLabel = "Tahun " . $year;
} else {
    $periodeLabel = date('F Y', mktime(0, 0, 0, $month, 1, $year));
}
?>

<!-- ============================================================ -->
<!-- MAIN CONTENT AREA -->
<!-- ============================================================ -->
<main id="mainContent" class="flex-grow-1 p-4">
  <div class="container-fluid">

    <!-- Header -->
    <div class="d-flex justify-content-between align-items-center mb-3">
      <h4 class="text-primary mb-0">
        <i class="bi bi-file-earmark-text me-2"></i> Laporan Peminjaman Buku
      </h4>
      <a href="reports-loans-pdf.php?month=<?= $month ?>&year=<?= $year ?>" target="_blank"
         class="btn btn-outline-success btn-sm">
        <i class="bi bi-printer"></i> Cetak PDF
      </a>
    </div>

    <!-- Filter -->
    <div class="card shadow-sm border-0 mb-3">
      <div class="card-body">
        <form method="get" class="row g-2 align-items-end">
          <div class="col-md-3">
            <label class="form-label">Bulan</label>
            <select name="month" class="form-select">
              <option value="0" <?= ($month === 0 ? 'selected' : '') ?>>Semua Bulan (Tahun Penuh)</option>
              <?php for ($m = 1; $m <= 12; $m++): ?>
                <option value="<?= $m ?>" <?= ($m == $month ? 'selected' : '') ?>>
                  <?= date('F', mktime(0, 0, 0, $m, 1)) ?>
                </option>
              <?php endfor; ?>
            </select>
          </div>
          <div class="col-md-3">
            <label class="form-label">Tahun</label>
            <select name="year" class="form-select">
              <?php for ($y = date('Y') - 3; $y <= date('Y'); $y++): ?>
                <option value="<?= $y ?>" <?= ($y == $year ? 'selected' : '') ?>><?= $y ?></option>
              <?php endfor; ?>
            </select>
          </div>
          <div class="col-md-3 d-grid">
            <button type="submit" class="btn btn-primary">
              <i class="bi bi-search"></i> Tampilkan
            </button>
          </div>
        </form>
      </div>
    </div>

    <!-- Flash jika tidak ada data -->
    <?php if ($noData): ?>
      <div class="alert alert-info shadow-sm fade show mb-3" role="alert">
        <i class="bi bi-info-circle me-2"></i>
        Belum ada data peminjaman buku untuk periode <?= htmlspecialchars($periodeLabel) ?>.
      </div>
    <?php else: ?>
      <div class="alert alert-success shadow-sm fade show mb-3" role="alert">
        <i class="bi bi-check-circle me-2"></i>
        Menampilkan data peminjaman untuk periode <strong><?= htmlspecialchars($periodeLabel) ?></strong>.
      </div>
    <?php endif; ?>

    <!-- Tabel Data -->
    <div class="card shadow-sm border-0">
      <div class="card-body">
        <div class="table-responsive">
          <table class="table table-bordered table-hover align-middle">
            <thead class="table-light">
              <tr>
                <th width="5%">No</th>
                <th>Kode Peminjaman</th>
                <th>Nama Siswa</th>
                <th>Tanggal Pinjam</th>
                <th>Jatuh Tempo</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              <?php 
              $no = 1; 
              while ($row = $res->fetch_assoc()):
                $badge = match ($row['status']) {
                  'borrowed' => 'primary',
                  'returned' => 'success',
                  'late'     => 'danger',
                  default    => 'secondary'
                };
              ?>
              <tr>
                <td><?= $no++ ?></td>
                <td><?= htmlspecialchars($row['loan_code']) ?></td>
                <td><?= htmlspecialchars($row['student_name']) ?></td>
                <td><?= htmlspecialchars($row['loan_date']) ?></td>
                <td><?= htmlspecialchars($row['due_date']) ?></td>
                <td><span class="badge bg-<?= $badge ?>"><?= strtoupper($row['status']) ?></span></td>
              </tr>
              <?php endwhile; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>

  </div>
</main>

<?php require_once __DIR__ . "/../includes/footer.php"; ?>
