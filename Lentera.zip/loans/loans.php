<?php
// ============================================================
// LENTERA LIBRARY SYSTEM – BOOK LOANS (LIST VIEW - FINAL JSON SAFE VERSION)
// ============================================================

$pageTitle = "Peminjaman Buku";

if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . "/../config/session_guard.php";
require_once __DIR__ . "/../config/db_config.php";
require_once __DIR__ . "/../includes/header.php";
require_once __DIR__ . "/../includes/sidebar.php";
require_once __DIR__ . "/../includes/topbar.php";

$conn = db();
$school_id = $_SESSION['school_id'] ?? 0;

// ============================================================
// Hanya admin yang boleh
// ============================================================
if (($_SESSION['user_type'] ?? '') !== 'admin') {
    header("Location: ../dashboard.php");
    exit;
}

// ============================================================
// AMBIL DATA PEMINJAMAN
// ============================================================
$stmt = $conn->prepare("
    SELECT l.*, s.name AS student_name
    FROM book_loans l
    JOIN students s ON s.id = l.student_id
    WHERE l.school_id = ?
    ORDER BY l.loan_date DESC
");
$stmt->bind_param("i", $school_id);
$stmt->execute();
$res = $stmt->get_result();
?>

<!-- ============================================================ -->
<!-- MAIN CONTENT AREA -->
<!-- ============================================================ -->
<main id="mainContent" class="flex-grow-1 p-4">
  <div class="container-fluid">

    <!-- HEADER + ACTION BUTTON -->
    <div class="d-flex justify-content-between align-items-center mb-3">
      <h4 class="text-primary mb-0">
        <i class="bi bi-journal-arrow-up me-2"></i> Daftar Peminjaman
      </h4>
      <div>
        <button id="btnUpdateLate" class="btn btn-outline-warning btn-sm me-2">
          <i class="bi bi-arrow-repeat"></i> Update Status Terlambat
        </button>
        <a href="loans-create.php" class="btn btn-primary btn-sm">
          <i class="bi bi-plus-lg me-1"></i> Tambah Peminjaman
        </a>
      </div>
    </div>

    <div class="card shadow-sm border-0">
      <div class="card-body table-responsive">
        <table id="loanTable" class="table table-bordered table-hover align-middle w-100">
          <thead class="table-light">
            <tr>
              <th width="5%">#</th>
              <th>Kode Peminjaman</th>
              <th>Nama Siswa</th>
              <th>Tanggal Pinjam</th>
              <th>Jatuh Tempo</th>
              <th>Status</th>
              <th width="200">Aksi</th>
            </tr>
          </thead>
          <tbody>
            <?php
            $no = 1;
            while ($row = $res->fetch_assoc()):
              $statusColor = [
                'borrowed' => 'primary',
                'late'     => 'danger',
                'returned' => 'success'
              ][$row['status']] ?? 'secondary';
            ?>
            <tr>
              <td><?= $no++ ?></td>
              <td><strong><?= htmlspecialchars($row['loan_code']) ?></strong></td>
              <td><?= htmlspecialchars($row['student_name']) ?></td>
              <td><?= htmlspecialchars($row['loan_date']) ?></td>
              <td><?= htmlspecialchars($row['due_date']) ?></td>
              <td><span class="badge bg-<?= $statusColor ?>"><?= strtoupper($row['status']) ?></span></td>
              <td class="text-center">
                <a href="loans-detail.php?id=<?= $row['id'] ?>" 
                   class="btn btn-sm btn-outline-info me-1" 
                   title="Detail">
                  <i class="bi bi-eye"></i>
                </a>

                <?php if (in_array($row['status'], ['borrowed', 'late'])): ?>
                  <a href="loans-return.php?id=<?= $row['id'] ?>" 
                     class="btn btn-sm btn-outline-success me-1" 
                     title="Kembalikan Buku">
                    <i class="bi bi-arrow-return-left"></i>
                  </a>
                <?php endif; ?>

                <button 
                  class="btn btn-sm btn-outline-danger btn-delete"
                  data-id="<?= $row['id'] ?>"
                  data-code="<?= htmlspecialchars($row['loan_code']) ?>"
                  title="Hapus">
                  <i class="bi bi-trash"></i>
                </button>
              </td>
            </tr>
            <?php endwhile; ?>
          </tbody>
        </table>
      </div>
    </div>

  </div>
</main>

<?php require_once __DIR__ . "/../includes/footer.php"; ?>

<!-- ============================================================ -->
<!-- DATATABLES + ACTION SCRIPTS -->
<!-- ============================================================ -->
<script>
$(document).ready(function() {
  // ============================================================
  // Inisialisasi DataTable
  // ============================================================
  $("#loanTable").DataTable({
    pageLength: 10,
    order: [],
    language: { url: "<?= BASE_URL ?>/assets/datatables/i18n/id.json" }
  });

  // ============================================================
  // TOMBOL HAPUS DATA
  // ============================================================
  $(".btn-delete").on("click", function() {
    const id = $(this).data("id");
    const code = $(this).data("code");

    confirmAction(`Hapus transaksi peminjaman <b>${code}</b>?`, function() {
      $.ajax({
        url: "loans-delete.php",
        type: "POST",
        dataType: "json",
        data: { id },
        success: function(data) {
          if (data.status === "success") {
            toast("Peminjaman berhasil dihapus");
            setTimeout(() => location.reload(), 1200);
          } else {
            alertError(data.message || "Gagal menghapus data");
          }
        },
        error: function(xhr, status, err) {
          alertError("Tidak dapat terhubung ke server. " + (xhr.responseText || err));
        }
      });
    });
  });

  // ============================================================
  // TOMBOL UPDATE STATUS TERLAMBAT (Trigger Manual Event)
  // ============================================================
  $("#btnUpdateLate").on("click", function() {
    Swal.fire({
      icon: "question",
      title: "Update Status Terlambat?",
      text: "Sistem akan menandai semua peminjaman yang sudah melewati jatuh tempo menjadi 'LATE'.",
      showCancelButton: true,
      confirmButtonText: "Ya, Jalankan",
      cancelButtonText: "Batal",
      confirmButtonColor: "#2563EB"
    }).then((result) => {
      if (result.isConfirmed) {
        $.ajax({
          url: "loans-update-late.php",
          type: "POST",
          dataType: "json", // penting biar otomatis parse JSON
          success: function(data) {
            if (data.status === "success") {
              Swal.fire({
                icon: "success",
                title: "Berhasil!",
                text: data.message,
                confirmButtonColor: "#2563EB"
              }).then(() => location.reload());
            } else {
              alertError(data.message || "Gagal menjalankan event.");
            }
          },
          error: function(xhr, status, err) {
            console.error("XHR Response:", xhr.responseText);
            alertError("Tidak dapat terhubung ke server. " + (xhr.responseText || err));
          }
        });
      }
    });
  });
});
</script>
