<?php
// ============================================================
// LENTERA LIBRARY SYSTEM – MANUAL EXECUTION OF EVENT ev_update_late_loans (FIXED FOR SCHEMA)
// ============================================================
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . "/../config/session_guard.php";
require_once __DIR__ . "/../config/db_config.php";

header("Content-Type: application/json; charset=utf-8");
$conn = db();

if (($_SESSION['user_type'] ?? '') !== 'admin') {
    echo json_encode(["status" => "error", "message" => "Akses ditolak."]);
    exit;
}

try {
    $totalUpdated = 0;
    $totalFines   = 0;

    $rules = $conn->query("SELECT id AS school_id, fine_per_day FROM fines_rules");
    if ($rules && $rules->num_rows > 0) {
        while ($r = $rules->fetch_assoc()) {
            $sid        = (int)$r['school_id'];
            $finePerDay = (float)$r['fine_per_day'];

            // 1️⃣ Update status jadi late
            $conn->query("
                UPDATE book_loans
                SET status = 'late'
                WHERE status = 'borrowed'
                  AND return_date IS NULL
                  AND due_date < CURDATE()
                  AND school_id = $sid
            ");
            $totalUpdated += max(0, $conn->affected_rows);

            // 2️⃣ Hitung denda otomatis
            $conn->query("
                UPDATE book_loans
                SET fine = DATEDIFF(CURDATE(), due_date) * $finePerDay
                WHERE status = 'late'
                  AND return_date IS NULL
                  AND due_date < CURDATE()
                  AND school_id = $sid
            ");

            // 3️⃣ Catat ke activity_logs
            $conn->query("
                INSERT INTO activity_logs (school_id, user_type, user_id, action, reference_id, description, created_at)
                SELECT DISTINCT $sid, 'system', 0, 'auto_late_update', b.id,
                       CONCAT('Peminjaman ', b.loan_code, 
                              ' otomatis ditandai late (denda Rp ',
                              FORMAT(DATEDIFF(CURDATE(), b.due_date) * $finePerDay, 0), ')'),
                       NOW()
                FROM book_loans b
                WHERE b.status = 'late'
                  AND b.return_date IS NULL
                  AND b.due_date < CURDATE()
                  AND b.school_id = $sid
                  AND b.id NOT IN (
                      SELECT reference_id FROM activity_logs 
                      WHERE action = 'auto_late_update' 
                        AND DATE(created_at) = CURDATE()
                  )
            ");

            // 4️⃣ Buat entry fine_payments baru untuk yang kena denda
            $conn->query("
                INSERT INTO fine_payments (school_id, loan_id, student_id, amount, is_paid, created_at)
                SELECT b.school_id, b.id, b.student_id, b.fine, 0, NOW()
                FROM book_loans b
                WHERE b.status = 'late'
                  AND b.return_date IS NULL
                  AND b.due_date < CURDATE()
                  AND b.school_id = $sid
                  AND b.id NOT IN (SELECT loan_id FROM fine_payments)
            ");
            $totalFines += max(0, $conn->affected_rows);
        }
    }

    // 5️⃣ Buat pesan hasil
    if ($totalUpdated > 0) {
        $msg = "{$totalUpdated} peminjaman diperbarui jadi terlambat.";
        if ($totalFines > 0) {
            $msg .= " ({$totalFines} denda baru dibuat)";
        }
    } else {
        $msg = "Tidak ada peminjaman yang perlu diperbarui.";
    }

    echo json_encode(["status" => "success", "message" => $msg]);
} catch (Throwable $e) {
    echo json_encode(["status" => "error", "message" => "Gagal menjalankan event: " . $e->getMessage()]);
}
exit;
