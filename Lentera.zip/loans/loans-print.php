<?php
// ============================================================
// LENTERA LIBRARY SYSTEM – CETAK BUKTI PEMINJAMAN (FINAL REVISED)
// ============================================================

if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . "/../config/session_guard.php";
require_once __DIR__ . "/../config/db_config.php";

$conn = db();
$school_id = $_SESSION['school_id'] ?? 0;
$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) die("❌ ID peminjaman tidak valid.");

// ============================================================
// 🧾 AMBIL DATA HEADER PEMINJAMAN
// ============================================================
$stmtH = $conn->prepare("
    SELECT 
        l.loan_code,
        l.loan_date,
        l.due_date,
        l.return_date,
        l.status,
        s.name AS student_name,
        s.nis,
        sc.name AS school_name,
        sc.logo,
        sc.address,
        sc.phone,
        sc.email
    FROM book_loans l
    JOIN students s ON s.id = l.student_id
    JOIN schools sc ON sc.id = l.school_id
    WHERE l.school_id = ? AND l.id = ?
    LIMIT 1
");
$stmtH->bind_param("ii", $school_id, $id);
$stmtH->execute();
$header = $stmtH->get_result()->fetch_assoc();
$stmtH->close();

if (!$header) die("❌ Data peminjaman tidak ditemukan.");

// ============================================================
// 📚 AMBIL DATA DETAIL BUKU DIPINJAM
// ============================================================
$stmtD = $conn->prepare("
    SELECT b.code, b.title, b.author, d.quantity, d.returned
    FROM book_loan_details d
    JOIN books b ON b.id = d.book_id
    WHERE d.loan_id = ?
");
$stmtD->bind_param("i", $id);
$stmtD->execute();
$resD = $stmtD->get_result();

// ============================================================
// 🗓️ FORMAT DATA
// ============================================================
$loan_date    = date('d M Y', strtotime($header['loan_date']));
$due_date     = date('d M Y', strtotime($header['due_date']));
$return_date  = $header['return_date'] ? date('d M Y', strtotime($header['return_date'])) : '-';
$status_label = strtoupper($header['status']);
$admin_name   = $_SESSION['name'] ?? "Petugas Perpustakaan";

$logo_path = "../assets/img/logo.png";
if (!empty($header['logo']) && file_exists(__DIR__ . "/../" . $header['logo'])) {
    $logo_path = "../" . $header['logo'];
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="utf-8">
<title>Cetak Peminjaman – <?= htmlspecialchars($header['loan_code']) ?></title>
<link href="../assets/css/bootstrap.min.css" rel="stylesheet">
<style>
body {
  font-family: Arial, sans-serif;
  background: #fff;
  color: #000;
  font-size: 13px;
  margin: 25px;
}
.header {
  display: flex;
  align-items: center;
  border-bottom: 2px solid #000;
  padding-bottom: 8px;
  margin-bottom: 15px;
}
.header img {
  height: 65px;
  margin-right: 15px;
  border-radius: 4px;
  border: 1px solid #ddd;
  background: #fff;
}
.header .title {
  font-size: 18px;
  font-weight: 700;
  text-transform: uppercase;
}
.header .sub {
  font-size: 13px;
  line-height: 1.3em;
}
h4 {
  font-weight: 600;
  text-transform: uppercase;
  font-size: 16px;
}
.table {
  border: 1px solid #000;
  width: 100%;
}
.table th, .table td {
  border: 1px solid #000;
  padding: 6px 8px;
}
.table-borderless td {
  border: none !important;
}
.footer-note {
  margin-top: 30px;
  font-size: 12px;
  text-align: center;
  color: #555;
}
@media print {
  .no-print { display: none !important; }
  body { margin: 10px; }
  .container { width: 100%; }
}
</style>
</head>
<body onload="window.print()">

<div class="container my-3">

  <!-- ============================================================ -->
  <!-- 🏫 HEADER SEKOLAH -->
  <!-- ============================================================ -->
  <div class="header">
    <img src="<?= htmlspecialchars($logo_path) ?>" alt="Logo Sekolah">
    <div>
      <div class="title"><?= htmlspecialchars($header['school_name']) ?></div>
      <div class="sub">
        <?= htmlspecialchars($header['address']) ?><br>
        Telp: <?= htmlspecialchars($header['phone']) ?> | Email: <?= htmlspecialchars($header['email']) ?>
      </div>
    </div>
  </div>

  <!-- ============================================================ -->
  <!-- 🧾 JUDUL CETAK -->
  <!-- ============================================================ -->
  <div class="text-center mb-4">
    <h4><u>Bukti Peminjaman Buku</u></h4>
    <p class="mb-0">Kode Peminjaman: <strong><?= htmlspecialchars($header['loan_code']) ?></strong></p>
  </div>

  <!-- ============================================================ -->
  <!-- 📄 INFORMASI PEMINJAMAN -->
  <!-- ============================================================ -->
  <table class="table table-borderless mb-3">
    <tr>
      <td width="25%"><strong>Nama Siswa</strong></td>
      <td>: <?= htmlspecialchars($header['student_name']) ?></td>
      <td width="25%"><strong>Tanggal Pinjam</strong></td>
      <td>: <?= $loan_date ?></td>
    </tr>
    <tr>
      <td><strong>NIS</strong></td>
      <td>: <?= htmlspecialchars($header['nis']) ?></td>
      <td><strong>Jatuh Tempo</strong></td>
      <td>: <?= $due_date ?></td>
    </tr>
    <tr>
      <td><strong>Status</strong></td>
      <td>: <?= htmlspecialchars($status_label) ?></td>
      <td><strong>Tanggal Kembali</strong></td>
      <td>: <?= htmlspecialchars($return_date) ?></td>
    </tr>
  </table>

  <!-- ============================================================ -->
  <!-- 📚 DAFTAR BUKU DIPINJAM -->
  <!-- ============================================================ -->
  <table class="table table-sm table-bordered mb-4">
    <thead class="table-light">
      <tr>
        <th width="5%">No</th>
        <th width="15%">Kode Buku</th>
        <th>Judul Buku</th>
        <th width="25%">Pengarang</th>
        <th width="8%" class="text-center">Qty</th>
        <th width="15%" class="text-center">Status</th>
      </tr>
    </thead>
    <tbody>
      <?php $no = 1; while($d = $resD->fetch_assoc()): ?>
      <tr>
        <td><?= $no++ ?></td>
        <td><?= htmlspecialchars($d['code']) ?></td>
        <td><?= htmlspecialchars($d['title']) ?></td>
        <td><?= htmlspecialchars($d['author']) ?></td>
        <td class="text-center"><?= (int)$d['quantity'] ?></td>
        <td class="text-center">
          <?= $d['returned'] ? '<span class="text-success">Dikembalikan</span>' : '<span class="text-danger">Dipinjam</span>' ?>
        </td>
      </tr>
      <?php endwhile; ?>
      <?php if ($no === 1): ?>
      <tr><td colspan="6" class="text-center text-muted">Tidak ada data buku.</td></tr>
      <?php endif; ?>
    </tbody>
  </table>

  <!-- ============================================================ -->
  <!-- ✍️ TANDA TANGAN -->
  <!-- ============================================================ -->
  <div class="row mt-5">
    <div class="col-6 text-center">
      <p><strong>Peminjam</strong></p>
      <br><br><br>
      <p>(<?= htmlspecialchars($header['student_name']) ?>)</p>
    </div>
    <div class="col-6 text-center">
      <p><strong>Petugas</strong></p>
      <br><br><br>
      <p>(<?= htmlspecialchars($admin_name) ?>)</p>
    </div>
  </div>

  <!-- ============================================================ -->
  <!-- 📜 FOOTER -->
  <!-- ============================================================ -->
  <div class="footer-note mt-4">
    <p>Harap mengembalikan buku tepat waktu. Terima kasih telah menggunakan layanan perpustakaan Lentera.</p>
    <p class="no-print mt-2">
      <a href="javascript:window.print()" class="btn btn-sm btn-primary">
        <i class="bi bi-printer"></i> Cetak Ulang
      </a>
    </p>
  </div>

</div>

</body>
</html>
