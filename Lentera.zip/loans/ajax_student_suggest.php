<?php
// ============================================================
// LENTERA LIBRARY SYSTEM – AJAX STUDENT AUTO-SUGGEST (MANUAL AUTOCOMPLETE)
// ============================================================

if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . "/../config/db_config.php";

header('Content-Type: application/json; charset=utf-8');

$conn = db();
$school_id = $_SESSION['school_id'] ?? 0;

$q = trim($_GET['q'] ?? '');
if ($q === '') {
    echo json_encode([]);
    exit;
}

$sql = "
    SELECT s.id, s.name, s.nis
    FROM students s
    WHERE s.school_id = ?
      AND (s.name LIKE ? OR s.nis LIKE ?)
      AND NOT EXISTS (
        SELECT 1 
        FROM book_loans l 
        WHERE l.school_id = s.school_id 
          AND l.student_id = s.id 
          AND l.status IN ('borrowed','late')
      )
    ORDER BY s.name ASC
    LIMIT 10
";

$stmt = $conn->prepare($sql);
$like = "%$q%";
$stmt->bind_param("iss", $school_id, $like, $like);
$stmt->execute();
$res = $stmt->get_result();

$data = [];
while ($r = $res->fetch_assoc()) {
    $data[] = [
        'id' => $r['id'],
        'label' => $r['name'] . " (" . $r['nis'] . ")"
    ];
}

echo json_encode($data);
