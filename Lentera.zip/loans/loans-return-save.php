<?php
// ============================================================
// LENTERA LIBRARY SYSTEM – LOAN RETURN SAVE (COMPATIBLE WITH fine_payments)
// ============================================================

if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . "/../config/session_guard.php";
require_once __DIR__ . "/../config/db_config.php";

$conn = db();
$school_id = $_SESSION['school_id'] ?? 0;

// ============================================================
// HAK AKSES
// ============================================================
if (($_SESSION['user_type'] ?? '') !== 'admin') {
    header("Location: ../dashboard.php");
    exit;
}

// ============================================================
// VALIDASI INPUT
// ============================================================
$loan_id        = (int)($_POST['loan_id'] ?? 0);
$fine           = (float)($_POST['fine'] ?? 0);
$note           = trim($_POST['note'] ?? ""); // disimpan ke fine_payments.note kalau ada denda
$returned_books = $_POST['return_books'] ?? [];

if ($loan_id <= 0) {
    die("Invalid Loan ID");
}

try {
    $conn->begin_transaction();

    // ------------------------------------------------------------
    // AMBIL DATA LOAN (untuk student_id)
    // ------------------------------------------------------------
    $stmtLoan = $conn->prepare("
        SELECT id, status, student_id 
        FROM book_loans 
        WHERE id = ? AND school_id = ? 
        LIMIT 1
    ");
    $stmtLoan->bind_param("ii", $loan_id, $school_id);
    $stmtLoan->execute();
    $loan = $stmtLoan->get_result()->fetch_assoc();
    if (!$loan) {
        throw new Exception("Data peminjaman tidak ditemukan.");
    }
    $student_id = (int)$loan['student_id'];

    // ------------------------------------------------------------
    // UPDATE DETAIL BUKU (TANDAI SEBAGAI DIKEMBALIKAN) & TAMBAH STOK
    // ------------------------------------------------------------
    if (!empty($returned_books)) {
        $stmtUpdateDetail = $conn->prepare("
            UPDATE book_loan_details 
            SET returned = 1 
            WHERE loan_id = ? AND book_id = ?
        ");
        $stmtUpdateBook = $conn->prepare("
            UPDATE books 
            SET stock_available = stock_available + 1 
            WHERE id = ? AND school_id = ?
        ");

        foreach ($returned_books as $book_id) {
            $book_id = (int)$book_id;

            // Tandai detail sudah kembali
            $stmtUpdateDetail->bind_param("ii", $loan_id, $book_id);
            $stmtUpdateDetail->execute();

            // Tambahkan stok
            $stmtUpdateBook->bind_param("ii", $book_id, $school_id);
            $stmtUpdateBook->execute();
        }
    }

    // ------------------------------------------------------------
    // CEK SISA BUKU YANG BELUM DIKEMBALIKAN
    // ------------------------------------------------------------
    $resChk = $conn->query("
        SELECT COUNT(*) AS sisa 
        FROM book_loan_details 
        WHERE loan_id = {$loan_id} AND returned = 0
    ");
    $remaining = (int)($resChk->fetch_assoc()['sisa'] ?? 0);

    if ($remaining === 0) {
        // Semua buku kembali → status returned + return_date
        $stmtStatus = $conn->prepare("
            UPDATE book_loans 
            SET status = 'returned', return_date = CURDATE()
            WHERE id = ? AND school_id = ?
        ");
        $stmtStatus->bind_param("ii", $loan_id, $school_id);
        $stmtStatus->execute();
    } else {
        // Masih ada yang belum kembali → tetap borrowed
        $stmtStatus = $conn->prepare("
            UPDATE book_loans 
            SET status = 'borrowed'
            WHERE id = ? AND school_id = ?
        ");
        $stmtStatus->bind_param("ii", $loan_id, $school_id);
        $stmtStatus->execute();
    }

    // ------------------------------------------------------------
    // CATAT DENDA (Jika Ada) ke TABEL: fine_payments
    // Kolom ada: id, school_id, loan_id, student_id, payment_date, amount, method, note, created_at, updated_at
    // ------------------------------------------------------------
    if ($fine > 0) {
        $stmtFine = $conn->prepare("
            INSERT INTO fine_payments (school_id, loan_id, student_id, payment_date, amount, is_paid, method, note)
            VALUES (?, ?, ?, NOW(), ?, 0, NULL, ?)

        ");
        $stmtFine->bind_param("iiids", $school_id, $loan_id, $student_id, $fine, $note);
        $stmtFine->execute();
    }

    $conn->commit();

    $_SESSION['flash_success'] = "Pengembalian buku berhasil disimpan.";
    header("Location: loans.php");
    exit;

} catch (Exception $e) {
    $conn->rollback();
    echo "<div style='margin:40px;color:red;font-weight:bold'>
            ❌ Terjadi kesalahan: " . htmlspecialchars($e->getMessage()) . "
          </div>";
}
