<?php
// ============================================================
// LENTERA LIBRARY SYSTEM – LOAN RETURN CONFIRMATION (FINAL)
// ============================================================

$pageTitle = "Konfirmasi Pengembalian Buku";

if (session_status() === PHP_SESSION_NONE) session_start();
ob_start();

require_once __DIR__ . "/../config/session_guard.php";
require_once __DIR__ . "/../config/db_config.php";
require_once __DIR__ . "/../includes/header.php";
require_once __DIR__ . "/../includes/sidebar.php";
require_once __DIR__ . "/../includes/topbar.php";

$conn = db();
$school_id = $_SESSION['school_id'] ?? 0;

// ============================================================
// VALIDASI AKSES
// ============================================================
if (($_SESSION['user_type'] ?? '') !== 'admin') {
    header("Location: ../dashboard.php");
    exit;
}

// ============================================================
// VALIDASI PARAMETER
// ============================================================
$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) die("Invalid ID.");

// ============================================================
// AMBIL DATA PEMINJAMAN (HEADER)
// ============================================================
$stmtH = $conn->prepare("
    SELECT l.*, s.name AS student_name, s.nis
    FROM book_loans l
    JOIN students s ON s.id = l.student_id
    WHERE l.id = ? AND l.school_id = ?
    LIMIT 1
");
$stmtH->bind_param("ii", $id, $school_id);
$stmtH->execute();
$resH = $stmtH->get_result();
$loan = $resH->fetch_assoc();
$stmtH->close();

if (!$loan) {
    die("Data peminjaman tidak ditemukan.");
}

// ============================================================
// AMBIL DETAIL BUKU
// ============================================================
$stmtD = $conn->prepare("
    SELECT d.*, b.title, b.code, b.id AS book_id
    FROM book_loan_details d
    JOIN books b ON b.id = d.book_id
    WHERE d.loan_id = ?
");
$stmtD->bind_param("i", $id);
$stmtD->execute();
$resD = $stmtD->get_result();

// ============================================================
// HITUNG DENDA (Jika terlambat)
// ============================================================
$today = date('Y-m-d');
$fine = 0;
$daysLate = 0;

if ($loan['status'] !== 'returned' && $loan['due_date'] < $today) {
    $stmtFine = $conn->prepare("SELECT fine_per_day FROM fines_rules WHERE school_id = ? LIMIT 1");
    $stmtFine->bind_param("i", $school_id);
    $stmtFine->execute();
    $resFine = $stmtFine->get_result();
    $fine_per_day = (float)($resFine->fetch_assoc()['fine_per_day'] ?? 0);
    $stmtFine->close();

    $daysLate = max(0, floor((strtotime($today) - strtotime($loan['due_date'])) / 86400));
    $fine = $fine_per_day * $daysLate;
}
?>

<!-- ============================================================ -->
<!-- MAIN CONTENT AREA -->
<!-- ============================================================ -->
<main id="mainContent" class="flex-grow-1 p-4">
<div class="container-fluid">

  <div class="d-flex justify-content-between align-items-center mb-3">
    <h4 class="text-primary mb-0">
      <i class="bi bi-arrow-return-left me-2"></i> Konfirmasi Pengembalian Buku
    </h4>
    <a href="loans-detail.php?id=<?= $id ?>" class="btn btn-outline-secondary btn-sm">
      <i class="bi bi-arrow-left"></i> Kembali
    </a>
  </div>

  <!-- ============================================================ -->
  <!-- INFORMASI PEMINJAMAN -->
  <!-- ============================================================ -->
  <div class="card shadow-sm border-0 mb-4">
    <div class="card-body">
      <h5 class="card-title mb-3"><i class="bi bi-info-circle me-2"></i> Informasi Peminjaman</h5>
      <table class="table table-sm mb-0">
        <tr>
          <th width="200">Kode Peminjaman</th>
          <td><?= htmlspecialchars($loan['loan_code']) ?></td>
        </tr>
        <tr>
          <th>Nama Siswa</th>
          <td><?= htmlspecialchars($loan['student_name']) ?> (<?= htmlspecialchars($loan['nis']) ?>)</td>
        </tr>
        <tr>
          <th>Tanggal Pinjam</th>
          <td><?= htmlspecialchars($loan['loan_date']) ?></td>
        </tr>
        <tr>
          <th>Jatuh Tempo</th>
          <td><?= htmlspecialchars($loan['due_date']) ?></td>
        </tr>
        <tr>
          <th>Status</th>
          <td><span class="badge bg-warning text-dark"><?= strtoupper($loan['status']) ?></span></td>
        </tr>
      </table>

      <?php if ($fine > 0): ?>
        <div class="alert alert-danger mt-3 mb-0">
          <strong>Denda:</strong> Rp <?= number_format($fine, 0, ',', '.') ?> 
          <small>(Terlambat <?= $daysLate ?> hari)</small>
        </div>
      <?php endif; ?>
    </div>
  </div>

  <!-- ============================================================ -->
  <!-- FORM KONFIRMASI PENGEMBALIAN -->
  <!-- ============================================================ -->
  <div class="card shadow-sm border-0">
    <div class="card-body">
      <h5 class="card-title mb-3"><i class="bi bi-book me-2"></i> Daftar Buku</h5>

      <form method="post" action="loans-return-save.php">
        <input type="hidden" name="loan_id" value="<?= $id ?>">
        <input type="hidden" name="fine" value="<?= $fine ?>">

        <div class="table-responsive mb-3">
          <table class="table table-bordered align-middle">
            <thead class="table-light">
              <tr>
                <th width="40">#</th>
                <th>Kode Buku</th>
                <th>Judul Buku</th>
                <th>Status</th>
                <th width="80">Kembali</th>
              </tr>
            </thead>
            <tbody>
              <?php $no = 1; while ($b = $resD->fetch_assoc()): ?>
                <tr>
                  <td><?= $no++ ?></td>
                  <td><?= htmlspecialchars($b['code']) ?></td>
                  <td><?= htmlspecialchars($b['title']) ?></td>
                  <td>
                    <?php if ($b['returned']): ?>
                      <span class="badge bg-success">Sudah</span>
                    <?php else: ?>
                      <span class="badge bg-warning text-dark">Belum</span>
                    <?php endif; ?>
                  </td>
                  <td class="text-center">
                    <?php if (!$b['returned']): ?>
                      <input type="checkbox" name="return_books[]" value="<?= $b['book_id'] ?>" checked>
                    <?php endif; ?>
                  </td>
                </tr>
              <?php endwhile; ?>
            </tbody>
          </table>
        </div>

        <div class="mb-3">
          <label class="form-label fw-semibold">Catatan Tambahan</label>
          <textarea name="note" class="form-control" rows="2" placeholder="Opsional, misal: Buku rusak sedikit"></textarea>
        </div>

        <div class="text-end">
          <button type="submit" class="btn btn-success px-4">
            <i class="bi bi-check-lg me-1"></i> Konfirmasi Pengembalian
          </button>
        </div>
      </form>
    </div>
  </div>
</div>
</main>

<?php require_once __DIR__ . "/../includes/footer.php"; ?>
<?php ob_end_flush(); ?>
