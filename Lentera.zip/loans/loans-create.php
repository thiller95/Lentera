<?php
// ============================================================
// LENTERA LIBRARY SYSTEM – LOANS (CREATE NEW - FINAL AUTO DUE DATE + INFO SETTINGS)
// ============================================================

$pageTitle = "Tambah Peminjaman Buku";

if (session_status() === PHP_SESSION_NONE) session_start();
ob_start();

require_once __DIR__ . "/../config/session_guard.php";
require_once __DIR__ . "/../config/db_config.php";
require_once __DIR__ . "/../config/doc_numbering_helper.php"; 
require_once __DIR__ . "/../includes/header.php";
require_once __DIR__ . "/../includes/sidebar.php";
require_once __DIR__ . "/../includes/topbar.php";

$conn = db();
$school_id = $_SESSION['school_id'] ?? 0;
$msg = "";

// ============================================================
// CEK HAK AKSES
// ============================================================
if (($_SESSION['user_type'] ?? '') !== 'admin') {
    header("Location: ../dashboard.php");
    exit;
}

// ============================================================
// AMBIL DATA BUKU TERSEDIA
// ============================================================
$stmtBooks = $conn->prepare("
    SELECT id, code, title, stock_available 
    FROM books 
    WHERE school_id = ? AND stock_available > 0
    ORDER BY title ASC
");
$stmtBooks->bind_param("i", $school_id);
$stmtBooks->execute();
$books = $stmtBooks->get_result();

// ============================================================
// AMBIL SETTING LAMA PEMINJAMAN (max_loan_days)
// ============================================================
$stmtSet = $conn->prepare("SELECT key_value FROM settings WHERE school_id = ? AND key_name='max_loan_days' LIMIT 1");
$stmtSet->bind_param("i", $school_id);
$stmtSet->execute();
$max_days = (int)($stmtSet->get_result()->fetch_assoc()['key_value'] ?? 7);

$default_loan_date = date('Y-m-d');
$default_due_date  = date('Y-m-d', strtotime("+{$max_days} days"));

// ============================================================
// HANDLE FORM SUBMIT
// ============================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $student_id = (int)($_POST['student_id'] ?? 0);
    $book_ids   = $_POST['book_ids'] ?? [];
    $loan_date  = trim($_POST['loan_date'] ?? $default_loan_date);
    $due_date   = trim($_POST['due_date'] ?? $default_due_date);

    if ($student_id <= 0 || empty($book_ids)) {
        $msg = "Siswa dan buku wajib dipilih.";
    } else {
        try {
            $conn->begin_transaction();

            // Cek siswa masih punya pinjaman aktif?
            $checkActive = $conn->prepare("
                SELECT COUNT(*) AS c 
                FROM book_loans 
                WHERE student_id = ? AND school_id = ? 
                  AND status IN ('borrowed', 'late')
            ");
            $checkActive->bind_param("ii", $student_id, $school_id);
            $checkActive->execute();
            $active = $checkActive->get_result()->fetch_assoc()['c'] ?? 0;
            if ($active > 0) {
                throw new Exception("Siswa ini masih memiliki peminjaman aktif. Harap kembalikan buku sebelumnya terlebih dahulu.");
            }

            // Generate kode otomatis
            $loan_code = generate_doc_number($conn, $school_id, 'BOOK_LOAN');

            // Insert Header
            $stmtH = $conn->prepare("
                INSERT INTO book_loans (school_id, loan_code, student_id, loan_date, due_date, status)
                VALUES (?, ?, ?, ?, ?, 'borrowed')
            ");
            $stmtH->bind_param("isiss", $school_id, $loan_code, $student_id, $loan_date, $due_date);
            $stmtH->execute();
            $loan_id = $conn->insert_id;

            // Insert Detail & Update Stok Buku
            $stmtD = $conn->prepare("INSERT INTO book_loan_details (loan_id, book_id, quantity) VALUES (?, ?, 1)");
            $stmtUpdateBook = $conn->prepare("
                UPDATE books 
                SET stock_available = stock_available - 1 
                WHERE id = ? AND school_id = ? AND stock_available > 0
            ");

            foreach ($book_ids as $book_id) {
                $book_id = (int)$book_id;
                $stmtD->bind_param("ii", $loan_id, $book_id);
                $stmtD->execute();
                $stmtUpdateBook->bind_param("ii", $book_id, $school_id);
                $stmtUpdateBook->execute();
            }

            $conn->commit();

            $_SESSION['flash_success'] = "Peminjaman berhasil disimpan (Kode: $loan_code)";
            ob_clean();
            header("Location: loans.php");
            exit;

        } catch (Exception $e) {
            $conn->rollback();
            $msg = "Gagal menyimpan data: " . htmlspecialchars($e->getMessage());
        }
    }
}
?>

<!-- ============================================================ -->
<!-- MAIN CONTENT AREA -->
<!-- ============================================================ -->
<main id="mainContent" class="flex-grow-1 p-4">
  <div class="container-fluid">

    <div class="d-flex justify-content-between align-items-center mb-3">
      <h4 class="text-primary mb-0">
        <i class="bi bi-journal-plus me-2"></i> Tambah Peminjaman Baru
      </h4>
      <a href="loans.php" class="btn btn-outline-secondary btn-sm">
        <i class="bi bi-arrow-left"></i> Kembali
      </a>
    </div>

    <div class="card shadow-sm border-0">
      <div class="card-body">
        <?php if ($msg): ?>
          <div class="alert alert-danger"><?= htmlspecialchars($msg) ?></div>
        <?php endif; ?>

        <form method="post" autocomplete="off">
          <div class="row g-3 mb-3 position-relative">
            <div class="col-md-6 position-relative">
              <label class="form-label fw-semibold">Nama Siswa</label>
              <div class="position-relative">
                <input type="hidden" name="student_id" id="student_id">
                <input type="text" id="student_search" class="form-control pe-5"
                       placeholder="Ketik nama atau NIS siswa..." required autocomplete="off">
                <!-- Spinner kecil di kanan -->
                <div id="loadingSpinner" class="spinner-border spinner-border-sm text-primary" 
                     style="position:absolute; top:50%; right:10px; transform:translateY(-50%); display:none;"></div>
                <div id="studentSuggest" class="suggest-box shadow-sm"></div>
              </div>
              <small class="text-muted d-block mt-1">
                * Ketik sebagian nama/NIS untuk mencari siswa tanpa pinjaman aktif
              </small>
            </div>

            <div class="col-md-3">
              <label class="form-label fw-semibold">Tanggal Pinjam</label>
              <input type="date" name="loan_date" class="form-control" value="<?= $default_loan_date ?>" required>
              <small class="text-muted">Tanggal awal peminjaman.</small>
            </div>

            <div class="col-md-3">
              <label class="form-label fw-semibold">Jatuh Tempo</label>
              <input type="date" name="due_date" class="form-control" value="<?= $default_due_date ?>" required>
              <small class="text-muted">
                Jatuh tempo otomatis <strong><?= (int)$max_days ?></strong> hari setelah tanggal pinjam.
              </small>
            </div>
          </div>

          <hr>

          <div class="mb-3">
            <label class="form-label fw-semibold">Pilih Buku</label>
            <div class="table-responsive" style="max-height:300px; overflow:auto;">
              <table class="table table-sm table-hover align-middle">
                <thead class="table-light">
                  <tr>
                    <th width="40"></th>
                    <th>Kode</th>
                    <th>Judul Buku</th>
                    <th>Stok Tersedia</th>
                  </tr>
                </thead>
                <tbody>
                  <?php 
                  $books->data_seek(0);
                  while ($b = $books->fetch_assoc()): ?>
                    <tr>
                      <td><input type="checkbox" name="book_ids[]" value="<?= $b['id'] ?>"></td>
                      <td><?= htmlspecialchars($b['code']) ?></td>
                      <td><?= htmlspecialchars($b['title']) ?></td>
                      <td><?= (int)$b['stock_available'] ?></td>
                    </tr>
                  <?php endwhile; ?>
                </tbody>
              </table>
            </div>
          </div>

          <div class="text-end mt-3">
            <button type="submit" class="btn btn-primary px-4">
              <i class="bi bi-save me-1"></i> Simpan
            </button>
          </div>
        </form>
      </div>
    </div>
  </div>
</main>

<!-- ============================================================ -->
<!-- STYLE -->
<!-- ============================================================ -->
<style>
.suggest-box {
  position: absolute;
  top: 100%;
  left: 0;
  transform: translateY(2px);
  width: 100%;
  background: #fff;
  border: 1px solid #ccc;
  border-radius: 6px;
  display: none;
  z-index: 5000;
  max-height: 230px;
  overflow-y: auto;
  box-shadow: 0 6px 16px rgba(0,0,0,0.12);
}
.suggest-item { padding: 8px 12px; cursor: pointer; transition: background 0.15s; font-size: 14px; }
.suggest-item strong { color: #2563EB; }
.suggest-item:hover { background: #f3f4f6; }
</style>

<!-- ============================================================ -->
<!-- JQUERY + AUTOCOMPLETE + AUTO DUE DATE SCRIPT -->
<!-- ============================================================ -->
<script src="../assets/js/jquery.min.js"></script>
<script>
$(function(){
  const input = $("#student_search");
  const suggest = $("#studentSuggest");
  const hidden = $("#student_id");
  const spinner = $("#loadingSpinner");
  const loanDate = $("input[name='loan_date']");
  const dueDate  = $("input[name='due_date']");
  const maxDays  = <?= (int)$max_days ?>;
  let timer;

  // 🔍 AUTOCOMPLETE SISWA
  function highlightText(text, term) {
    const regex = new RegExp("(" + term + ")", "gi");
    return text.replace(regex, "<strong>$1</strong>");
  }

  input.on("input", function(){
    clearTimeout(timer);
    const q = $(this).val().trim();
    if (q.length < 2) { suggest.hide(); spinner.hide(); return; }

    timer = setTimeout(() => {
      spinner.show();
      $.getJSON("ajax_student_suggest.php", { q }, function(data){
        spinner.hide();
        suggest.empty();
        if (!data || data.length === 0) { suggest.hide(); return; }

        data.forEach(item => {
          const highlighted = highlightText(item.label, q);
          const el = $("<div>").addClass("suggest-item").html(highlighted);
          el.on("click", function(){
            input.val(item.label);
            hidden.val(item.id);
            suggest.hide();
          });
          suggest.append(el);
        });

        suggest.stop(true, true).hide().fadeIn(150);
      }).fail(() => spinner.hide());
    }, 300);
  });

  $(document).on("click", function(e){
    if (!$(e.target).closest("#student_search, #studentSuggest").length)
      suggest.hide();
  });

  // 📅 AUTO HITUNG JATUH TEMPO
  loanDate.on("change", function(){
    const val = $(this).val();
    if (!val) return;
    const start = new Date(val);
    start.setDate(start.getDate() + maxDays);
    const y = start.getFullYear();
    const m = String(start.getMonth() + 1).padStart(2, '0');
    const d = String(start.getDate()).padStart(2, '0');
    dueDate.val(`${y}-${m}-${d}`);
  });
});
</script>

<?php require_once __DIR__ . "/../includes/footer.php"; ?>
<?php ob_end_flush(); ?>
