<?php
// ============================================================
// LENTERA LIBRARY SYSTEM – LOAN DETAIL (FINAL STABLE)
// ============================================================

$pageTitle = "Detail Peminjaman";

if (session_status() === PHP_SESSION_NONE) session_start();
ob_start();

require_once __DIR__ . "/../config/session_guard.php";
require_once __DIR__ . "/../config/db_config.php";
require_once __DIR__ . "/../includes/header.php";
require_once __DIR__ . "/../includes/sidebar.php";
require_once __DIR__ . "/../includes/topbar.php";

$conn = db();
$school_id = $_SESSION['school_id'] ?? 0;

// ============================================================
// VALIDASI AKSES
// ============================================================
if (($_SESSION['user_type'] ?? '') !== 'admin') {
    header("Location: ../dashboard.php");
    exit;
}

// ============================================================
// VALIDASI PARAMETER
// ============================================================
$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) die("ID tidak valid.");

// ============================================================
// AMBIL HEADER PEMINJAMAN
// ============================================================
$stmtH = $conn->prepare("
    SELECT l.*, s.name AS student_name, s.nis
    FROM book_loans l
    JOIN students s ON s.id = l.student_id
    WHERE l.id = ? AND l.school_id = ?
    LIMIT 1
");
$stmtH->bind_param("ii", $id, $school_id);
$stmtH->execute();
$resH = $stmtH->get_result();
$loan = $resH->fetch_assoc();
$stmtH->close();

if (!$loan) {
    die("Data peminjaman tidak ditemukan.");
}

// ============================================================
// AMBIL DETAIL BUKU
// ============================================================
$stmtD = $conn->prepare("
    SELECT d.*, b.title, b.code 
    FROM book_loan_details d
    JOIN books b ON b.id = d.book_id
    WHERE d.loan_id = ?
");
$stmtD->bind_param("i", $id);
$stmtD->execute();
$resD = $stmtD->get_result();
?>

<!-- ============================================================ -->
<!-- MAIN CONTENT AREA -->
<!-- ============================================================ -->
<main id="mainContent" class="flex-grow-1 p-4">
  <div class="container-fluid">

    <div class="d-flex justify-content-between align-items-center mb-3">
      <h4 class="text-primary mb-0"><i class="bi bi-eye me-2"></i> Detail Peminjaman</h4>
      <a href="loans.php" class="btn btn-outline-secondary btn-sm">
        <i class="bi bi-arrow-left"></i> Kembali
      </a>
    </div>

    <!-- ============================================================ -->
    <!-- INFORMASI HEADER -->
    <!-- ============================================================ -->
    <div class="card shadow-sm border-0 mb-4">
      <div class="card-body">
        <div class="row mb-3">
          <div class="col-md-6">
            <p><strong>Kode Peminjaman:</strong> <?= htmlspecialchars($loan['loan_code']) ?></p>
            <p><strong>Nama Siswa:</strong> <?= htmlspecialchars($loan['student_name']) ?> (<?= htmlspecialchars($loan['nis']) ?>)</p>
          </div>
          <div class="col-md-6">
            <p><strong>Tanggal Pinjam:</strong> <?= htmlspecialchars($loan['loan_date']) ?></p>
            <p><strong>Jatuh Tempo:</strong> <?= htmlspecialchars($loan['due_date']) ?></p>
          </div>
        </div>

        <?php
        $statusColor = [
          'borrowed' => 'primary',
          'returned' => 'success',
          'late'     => 'danger'
        ][$loan['status']] ?? 'secondary';
        ?>
        <p class="mb-0"><strong>Status:</strong> 
          <span class="badge bg-<?= $statusColor ?>">
            <?= strtoupper($loan['status']) ?>
          </span>
        </p>

        <?php if ($loan['status'] === 'late'): ?>
          <p class="text-danger small mt-2 mb-0">
            <i class="bi bi-exclamation-circle"></i> Terlambat dikembalikan sejak <?= htmlspecialchars($loan['due_date']) ?>
          </p>
        <?php endif; ?>
      </div>
    </div>

    <!-- ============================================================ -->
    <!-- DAFTAR BUKU -->
    <!-- ============================================================ -->
    <div class="card shadow-sm border-0">
      <div class="card-body">
        <h5 class="card-title mb-3"><i class="bi bi-book me-2"></i> Daftar Buku</h5>
        <div class="table-responsive">
          <table class="table table-bordered table-hover align-middle mb-0">
            <thead class="table-light">
              <tr>
                <th width="5%">#</th>
                <th>Kode Buku</th>
                <th>Judul</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              <?php $no = 1; while ($b = $resD->fetch_assoc()): ?>
                <?php
                  $status = ($b['returned'] ?? 0) ? 'Dikembalikan' : 'Dipinjam';
                  $color  = ($b['returned'] ?? 0) ? 'success' : 'warning';
                ?>
                <tr>
                  <td><?= $no++ ?></td>
                  <td><?= htmlspecialchars($b['code']) ?></td>
                  <td><?= htmlspecialchars($b['title']) ?></td>
                  <td><span class="badge bg-<?= $color ?>"><?= $status ?></span></td>
                </tr>
              <?php endwhile; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>

    <!-- ============================================================ -->
    <!-- TOMBOL AKSI -->
    <!-- ============================================================ -->
    <div class="text-end mt-4">
    <!-- Tombol Cetak Selalu Tampil -->
    <a href="loans-print.php?id=<?= $id ?>" target="_blank" class="btn btn-outline-primary px-4 me-2">
    <i class="bi bi-printer me-1"></i> Cetak Bukti
    </a>

    <!-- Tombol Kembalikan Buku Hanya Jika Masih Dipinjam -->
    <?php if ($loan['status'] === 'borrowed'): ?>
    <a href="loans-return.php?id=<?= $id ?>" class="btn btn-success px-4">
      <i class="bi bi-arrow-return-left me-1"></i> Kembalikan Buku
    </a>
    <?php endif; ?>
    </div>

  </div>
</main>

<?php require_once __DIR__ . "/../includes/footer.php"; ?>
<?php ob_end_flush(); ?>
