<?php
// ============================================================
// LENTERA LIBRARY SYSTEM – LOAN DELETE ACTION (FINAL STABLE)
// ============================================================

if (session_status() === PHP_SESSION_NONE) session_start();
header("Content-Type: application/json; charset=utf-8");

require_once __DIR__ . "/../config/session_guard.php";
require_once __DIR__ . "/../config/db_config.php";

if (($_SESSION['user_type'] ?? '') !== 'admin') {
    echo json_encode(["status" => "error", "message" => "Akses ditolak."]);
    exit;
}

$school_id = $_SESSION['school_id'] ?? 0;
$user_id   = $_SESSION['user_id'] ?? 0;
$loan_id   = (int)($_POST['id'] ?? 0);

if ($loan_id <= 0 || $school_id <= 0) {
    echo json_encode(["status" => "error", "message" => "ID tidak valid."]);
    exit;
}

$conn = db();

try {
    $conn->begin_transaction();

    // ============================================================
    // 1️⃣ Ambil daftar buku yang harus dikembalikan stoknya
    // ============================================================
    $stmtBooks = $conn->prepare("
        SELECT b.id 
        FROM book_loan_details d
        JOIN books b ON b.id = d.book_id
        WHERE d.loan_id = ?
    ");
    $stmtBooks->bind_param("i", $loan_id);
    $stmtBooks->execute();
    $resBooks = $stmtBooks->get_result();

    $stmtUpdateStock = $conn->prepare("
        UPDATE books 
        SET stock_available = stock_available + 1 
        WHERE id = ? AND school_id = ?
    ");
    while ($row = $resBooks->fetch_assoc()) {
        $book_id = (int)$row['id'];
        $stmtUpdateStock->bind_param("ii", $book_id, $school_id);
        $stmtUpdateStock->execute();
    }
    $stmtBooks->close();
    $stmtUpdateStock->close();

    // ============================================================
    // 2️⃣ Hapus detail peminjaman
    // ============================================================
    $stmtDelDetails = $conn->prepare("DELETE FROM book_loan_details WHERE loan_id = ?");
    $stmtDelDetails->bind_param("i", $loan_id);
    $stmtDelDetails->execute();
    $stmtDelDetails->close();

    // ============================================================
    // 3️⃣ Hapus header peminjaman
    // ============================================================
    $stmtDelHeader = $conn->prepare("DELETE FROM book_loans WHERE id = ? AND school_id = ?");
    $stmtDelHeader->bind_param("ii", $loan_id, $school_id);
    $stmtDelHeader->execute();
    $stmtDelHeader->close();

    // ============================================================
    // 4️⃣ Simpan log aktivitas
    // ============================================================
    $stmtLog = $conn->prepare("
        INSERT INTO activity_logs 
        (school_id, user_type, user_id, action, reference_id, description)
        VALUES (?, 'admin', ?, 'delete_loan', ?, ?)
    ");
    $desc = "Hapus data peminjaman (loan_id: $loan_id)";
    $stmtLog->bind_param("iiis", $school_id, $user_id, $loan_id, $desc);
    $stmtLog->execute();
    $stmtLog->close();

    // ============================================================
    // 5️⃣ Commit dan kirim response
    // ============================================================
    $conn->commit();
    echo json_encode(["status" => "success"]);

} catch (Exception $e) {
    $conn->rollback();
    echo json_encode([
        "status" => "error",
        "message" => "Gagal menghapus data: " . $e->getMessage()
    ]);
}
