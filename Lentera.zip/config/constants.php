<?php
// ============================================================
// LENTERA LIBRARY SYSTEM – Global Constants (Final Version)
// ============================================================
// Menyimpan seluruh konstanta global: path, URL, tema, timezone, format, dsb.
// ============================================================

// ==========================
// ⚙️ APP INFO
// ==========================
define('APP_NAME', 'Lentera System');
define('APP_SHORT', 'Lentera');
define('APP_VERSION', 'v1.0.0');
define('APP_AUTHOR', 'Tim Pengembang Lentera Digital');
define('APP_YEAR', date('Y'));

// ==========================
// 📁 PATHS (Server-side path)
// ==========================
define('BASE_PATH', realpath(__DIR__ . '/../'));
define('CONFIG_PATH', BASE_PATH . '/config');
define('INCLUDES_PATH', BASE_PATH . '/includes');
define('ASSETS_PATH', BASE_PATH . '/assets');
define('IMG_PATH', ASSETS_PATH . '/img');
define('VENDOR_PATH', ASSETS_PATH . '/vendor');
define('UPLOADS_PATH', BASE_PATH . '/uploads');

// ==========================
// 🌐 URL BASE (Client-side, untuk HTML <a>, <img>, dsb.)
// ==========================
// ⚠️ Ganti sesuai nama folder utama kamu di htdocs.
// Karena kamu pakai folder "Lentera", maka:
define('BASE_URL', '/Lentera');
define('ASSETS_URL', BASE_URL . '/assets');
define('IMG_URL', ASSETS_URL . '/img');
define('VENDOR_URL', ASSETS_URL . '/vendor');
define('UPLOADS_URL', BASE_URL . '/uploads');

// ==========================
// 🎨 THEME COLORS (Global UI Colors)
// ==========================
define('THEME_PRIMARY', '#2563EB');  // Biru utama
define('THEME_SUCCESS', '#10B981');  // Hijau (berhasil)
define('THEME_INFO', '#3B82F6');     // Biru muda (info)
define('THEME_WARNING', '#F59E0B');  // Kuning (peringatan)
define('THEME_DANGER', '#EF4444');   // Merah (gagal)
define('THEME_LIGHT', '#F3F4F6');    // Abu terang (background)
define('THEME_DARK', '#1E293B');     // Abu gelap (teks utama)

// ==========================
// ⚙️ SYSTEM DEFAULTS
// ==========================
define('DEFAULT_SCHOOL_CODE', 'SMP01');
define('DEFAULT_LOAN_DAYS', 7);
define('DEFAULT_FINE_PER_DAY', 500); // Rp per hari keterlambatan
define('MAX_FINE_DAYS', 30);

// ==========================
// 🌏 TIMEZONE & FORMATTING
// ==========================
define('TIMEZONE_DEFAULT', 'Asia/Jakarta');
date_default_timezone_set(TIMEZONE_DEFAULT);

define('CURRENCY_SYMBOL', 'Rp');
define('DECIMAL_SEPARATOR', ',');
define('THOUSAND_SEPARATOR', '.');

// ==========================
// 🔒 SESSION & SECURITY
// ==========================
define('SESSION_TIMEOUT', 3600); // 1 jam
define('PASSWORD_HASH_ALGO', PASSWORD_DEFAULT);

// ==========================
// 🧾 FOOTER / COPYRIGHT
// ==========================
define('APP_FOOTER', sprintf('© %s %s. Semua Hak Dilindungi.', APP_YEAR, APP_NAME));

// ============================================================
// ✅ HELPER FUNCTIONS
// ============================================================

// Format ke Rupiah
if (!function_exists('currency_format')) {
    function currency_format($amount, $decimals = 0) {
        if (!is_numeric($amount)) $amount = 0;
        return CURRENCY_SYMBOL . ' ' . number_format((float)$amount, $decimals, DECIMAL_SEPARATOR, THOUSAND_SEPARATOR);
    }
}

// Buat <title> HTML otomatis
if (!function_exists('app_header')) {
    function app_header($title = '') {
        $safeTitle = htmlspecialchars($title);
        $fullTitle = $title ? "{$safeTitle} | " . APP_NAME : APP_NAME;
        echo "<title>{$fullTitle}</title>\n";
    }
}

// Redirect cepat berbasis BASE_URL
if (!function_exists('redirect')) {
    function redirect($path = '/dashboard.php') {
        header("Location: " . BASE_URL . $path);
        exit;
    }
}

// Format tanggal ke format lokal
if (!function_exists('fmt_date')) {
    function fmt_date($dateStr) {
        if (!$dateStr) return '-';
        $bulan = ['Jan','Feb','Mar','Apr','Mei','Jun','Jul','Agu','Sep','Okt','Nov','Des'];
        $ts = strtotime($dateStr);
        return date('d', $ts) . ' ' . $bulan[(int)date('m',$ts)-1] . ' ' . date('Y', $ts);
    }
}

// Menampilkan teks footer
if (!function_exists('app_footer_text')) {
    function app_footer_text() {
        echo APP_FOOTER;
    }
}
?>
