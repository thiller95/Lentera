<?php
// ============================================================
// LENTERA LIBRARY SYSTEM
// GLOBAL HELPER: Generate Dokumen Number Otomatis (All Modules)
// ============================================================
//
// ✅ Aman dari nomor ganda (pakai transaksi + SELECT ... FOR UPDATE)
// ✅ Auto-create entry di doc_numbering bila belum ada
// ✅ Mendukung reset otomatis: none, monthly, yearly
// ✅ Kompatibel untuk semua modul (BOOK, RAK, LOAN, FINE, REPORT, dsb)
// ============================================================

function generate_doc_number(mysqli $link, int $school_id, string $module_code, string $default_prefix = ''): string
{
    // Pastikan kode modul bersih
    $module_code = trim($module_code);

    $year  = (int)date('Y');
    $month = (int)date('m');

    mysqli_begin_transaction($link);

    try {
        // ============================================================
        // 1️⃣ Coba ambil dan kunci record numbering
        // ============================================================
        $stmt = mysqli_prepare($link, "
            SELECT id, prefix, last_number, last_year, last_month, format_pattern, pad_length, auto_reset
            FROM doc_numbering
            WHERE school_id = ? AND module_code = ?
            FOR UPDATE
        ");
        mysqli_stmt_bind_param($stmt, 'is', $school_id, $module_code);
        mysqli_stmt_execute($stmt);
        $res = mysqli_stmt_get_result($stmt);
        $data = mysqli_fetch_assoc($res);
        mysqli_stmt_close($stmt);

        // ============================================================
        // 2️⃣ Jika belum ada record → buat default baru
        // ============================================================
        if (!$data) {
            $default_prefix = $default_prefix ?: strtoupper($module_code);
            $format_default = '{PREFIX}/{YEAR}/{MONTH}/{NUM}';
            $pad_default    = 5;
            $reset_default  = 'monthly';

            $stmt_ins = mysqli_prepare($link, "
                INSERT INTO doc_numbering
                (school_id, module_code, prefix, last_number, last_year, last_month, format_pattern, pad_length, auto_reset)
                VALUES (?, ?, ?, 0, ?, ?, ?, ?, ?)
            ");
            mysqli_stmt_bind_param(
                $stmt_ins,
                'issiiiss',
                $school_id,
                $module_code,
                $default_prefix,
                $year,
                $month,
                $format_default,
                $pad_default,
                $reset_default
            );
            mysqli_stmt_execute($stmt_ins);
            mysqli_stmt_close($stmt_ins);

            // Ambil ulang record yang baru dibuat
            $stmt = mysqli_prepare($link, "
                SELECT id, prefix, last_number, last_year, last_month, format_pattern, pad_length, auto_reset
                FROM doc_numbering
                WHERE school_id = ? AND module_code = ?
                FOR UPDATE
            ");
            mysqli_stmt_bind_param($stmt, 'is', $school_id, $module_code);
            mysqli_stmt_execute($stmt);
            $res = mysqli_stmt_get_result($stmt);
            $data = mysqli_fetch_assoc($res);
            mysqli_stmt_close($stmt);
        }

        // ============================================================
        // 3️⃣ Proses penomoran
        // ============================================================
        $prefix      = $data['prefix'];
        $last_number = (int)$data['last_number'];
        $last_year   = (int)$data['last_year'];
        $last_month  = (int)$data['last_month'];
        $format      = $data['format_pattern'] ?: '{PREFIX}/{YEAR}/{MONTH}/{NUM}';
        $pad_length  = (int)$data['pad_length'];
        $auto_reset  = strtolower(trim($data['auto_reset']));

        // Tentukan apakah perlu reset
        $need_reset = false;
        if ($auto_reset === 'monthly' && ($year != $last_year || $month != $last_month)) {
            $need_reset = true;
        } elseif ($auto_reset === 'yearly' && $year != $last_year) {
            $need_reset = true;
        }
        if ($need_reset) {
            $last_number = 0;
        }

        $new_number = $last_number + 1;
        $num_str = str_pad($new_number, $pad_length, '0', STR_PAD_LEFT);

        $doc_code = str_replace(
            ['{PREFIX}', '{YEAR}', '{MONTH}', '{NUM}'],
            [$prefix, $year, str_pad($month, 2, '0', STR_PAD_LEFT), $num_str],
            $format
        );

        // ============================================================
        // 4️⃣ Update nomor terakhir ke database
        // ============================================================
        $stmt2 = mysqli_prepare($link, "
            UPDATE doc_numbering
            SET last_number = ?, last_year = ?, last_month = ?, updated_at = NOW()
            WHERE school_id = ? AND module_code = ?
        ");
        mysqli_stmt_bind_param($stmt2, 'iiiis', $new_number, $year, $month, $school_id, $module_code);
        mysqli_stmt_execute($stmt2);
        mysqli_stmt_close($stmt2);

        mysqli_commit($link);
        return $doc_code;

    } catch (Exception $e) {
        mysqli_rollback($link);
        throw $e;
    }
}
?>
