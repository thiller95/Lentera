<?php
// ============================================================
// LENTERA LIBRARY SYSTEM – SESSION GUARD (FINAL RBAC READY)
// ============================================================
// Wajib di-include di semua halaman setelah login.
// Fungsi:
// 1️⃣ Pastikan user sudah login (anti akses langsung).
// 2️⃣ Logout otomatis jika idle terlalu lama.
// 3️⃣ Validasi fingerprint (IP + User-Agent).
// 4️⃣ Tambahan: Helper untuk cek peran user (admin/staff).
// ============================================================

if (session_status() === PHP_SESSION_NONE) { session_start(); }
require_once __DIR__ . '/constants.php';

// ============================================================
// 1️⃣ CEK LOGIN STATUS
// ============================================================
if (empty($_SESSION['auth']) || empty($_SESSION['user_id']) || empty($_SESSION['role'])) {
    header("Location: " . BASE_URL . "/login.php");
    exit;
}

// ============================================================
// 2️⃣ CEK TIMEOUT SESSION (Auto Logout jika Idle Terlalu Lama)
// ============================================================
if (defined('SESSION_TIMEOUT')) {
    $max_idle_time = (int)SESSION_TIMEOUT;
    if (isset($_SESSION['last_active']) && (time() - $_SESSION['last_active'] > $max_idle_time)) {
        session_unset();
        session_destroy();
        header("Location: " . BASE_URL . "/login.php?timeout=1");
        exit;
    }
    $_SESSION['last_active'] = time();
}

// ============================================================
// 3️⃣ VALIDASI FINGERPRINT (ANTI SESSION HIJACK)
// ============================================================
if (!isset($_SESSION['client_fingerprint'])) {
    $_SESSION['client_fingerprint'] = md5($_SERVER['HTTP_USER_AGENT'] . ($_SERVER['REMOTE_ADDR'] ?? ''));
} else {
    $current_fingerprint = md5($_SERVER['HTTP_USER_AGENT'] . ($_SERVER['REMOTE_ADDR'] ?? ''));
    if ($_SESSION['client_fingerprint'] !== $current_fingerprint) {
        session_unset();
        session_destroy();
        header("Location: " . BASE_URL . "/login.php?forcelogout=1");
        exit;
    }
}

// ============================================================
// 4️⃣ HELPER: CEK ROLE USER (RBAC SEDERHANA)
// ============================================================

/**
 * Cek apakah user punya role tertentu
 * Contoh: require_role('admin'); → hanya admin yang boleh akses
 */
function require_role($role) {
    if (empty($_SESSION['role']) || $_SESSION['role'] !== $role) {
        header("Location: " . BASE_URL . "/dashboard.php?denied=1");
        exit;
    }
}

/**
 * Cek apakah user memiliki salah satu role dari array
 * Contoh: require_any_role(['admin','staff']);
 */
function require_any_role(array $roles) {
    if (empty($_SESSION['role']) || !in_array($_SESSION['role'], $roles)) {
        header("Location: " . BASE_URL . "/dashboard.php?denied=1");
        exit;
    }
}

// ============================================================
// ✅ SELESAI
// ============================================================
?>
