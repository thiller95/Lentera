<?php
// ============================================================
// LIBRARY SYSTEM - DATABASE CONFIGURATION
// ============================================================
// File ini mengatur koneksi ke database MySQL
// ============================================================

if (session_status() === PHP_SESSION_NONE) { session_start(); }

// ---------- KONFIGURASI DATABASE ----------
define('DB_HOST', '127.0.0.1');   // atau 'localhost'
define('DB_USER', 'root');        // username MySQL
define('DB_PASS', '');            // password MySQL
define('DB_NAME', 'library_system'); // nama database

// ---------- KONEKSI DATABASE ----------
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

function db(): mysqli {
    static $link = null;
    if ($link === null) {
        try {
            $link = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
            $link->set_charset('utf8mb4');
        } catch (mysqli_sql_exception $e) {
            die("Koneksi database gagal: " . $e->getMessage());
        }
    }
    return $link;
}

// ---------- TEST CONNECTION (opsional, bisa dihapus) ----------
// Jalankan ini hanya kalau mau cek koneksi manual via browser:
// if (basename($_SERVER['PHP_SELF']) === 'db_config.php') {
//     echo "<pre>Database connection OK ✅</pre>";
// }
