<?php
// ============================================================
// LENTERA LIBRARY SYSTEM – ADMINS CREATE (ADMIN MASTER)
// ============================================================

$pageTitle = "Tambah Pengguna";

if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . "/../config/session_guard.php";
require_once __DIR__ . "/../config/db_config.php";
require_once __DIR__ . "/../includes/header.php";
require_once __DIR__ . "/../includes/sidebar.php";
require_once __DIR__ . "/../includes/topbar.php";

$conn = db();

if ($_SESSION['user_type'] !== 'admin') {
    header("Location: ../dashboard.php");
    exit;
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $school_id = (int)($_POST['school_id'] ?? 0);
    $username = trim($_POST['username'] ?? '');
    $name = trim($_POST['name'] ?? '');
    $password = trim($_POST['password'] ?? '');
    $role = trim($_POST['role'] ?? 'staff');

    if ($school_id <= 0 || $username === '' || $password === '') {
        $error = "Semua field wajib diisi.";
    } else {
        $stmt = $conn->prepare("SELECT id FROM admins WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        if ($stmt->get_result()->num_rows > 0) {
            $error = "Username sudah digunakan.";
        } else {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("INSERT INTO admins (school_id, username, name, password, role) VALUES (?, ?, ?, ?, ?)");
            $stmt->bind_param("issss", $school_id, $username, $name, $hash, $role);
            if ($stmt->execute()) $success = "Pengguna berhasil ditambahkan.";
            else $error = "Gagal menambah pengguna.";
        }
    }
}
?>

<main id="mainContent" class="flex-grow-1 p-4">
  <div class="container-fluid" style="max-width:700px;">
    <div class="d-flex justify-content-between align-items-center mb-3">
      <h4 class="text-primary mb-0"><i class="bi bi-person-plus me-2"></i> Tambah Pengguna</h4>
      <a href="admins.php" class="btn btn-secondary btn-sm"><i class="bi bi-arrow-left"></i> Kembali</a>
    </div>

    <?php if (!empty($error)): ?><div class="alert alert-danger"><?= $error ?></div><?php endif; ?>
    <?php if (!empty($success)): ?><div class="alert alert-success"><?= $success ?></div><?php endif; ?>

    <div class="card shadow-sm border-0">
      <div class="card-body">
        <form method="POST" class="needs-validation" novalidate>
          <div class="mb-3">
            <label class="form-label fw-semibold">Sekolah <span class="text-danger">*</span></label>
            <select name="school_id" class="form-select" required>
              <option value="">-- Pilih Sekolah --</option>
              <?php
              $res = $conn->query("SELECT id, name FROM schools ORDER BY name ASC");
              while ($s = $res->fetch_assoc()):
              ?>
              <option value="<?= $s['id'] ?>"><?= htmlspecialchars($s['name']) ?></option>
              <?php endwhile; ?>
            </select>
          </div>

          <div class="mb-3">
            <label class="form-label fw-semibold">Username <span class="text-danger">*</span></label>
            <input type="text" name="username" class="form-control" required>
          </div>

          <div class="mb-3">
            <label class="form-label fw-semibold">Nama Lengkap</label>
            <input type="text" name="name" class="form-control">
          </div>

          <div class="mb-3">
            <label class="form-label fw-semibold">Password <span class="text-danger">*</span></label>
            <input type="password" name="password" class="form-control" required>
          </div>

          <div class="mb-3">
            <label class="form-label fw-semibold">Role</label>
            <select name="role" class="form-select">
              <option value="admin">Admin</option>
              <option value="staff">Staff</option>
            </select>
          </div>

          <div class="text-end">
            <button type="submit" class="btn btn-primary"><i class="bi bi-save me-1"></i> Simpan</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</main>

<?php require_once __DIR__ . "/../includes/footer.php"; ?>
