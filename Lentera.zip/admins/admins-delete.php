<?php
// ============================================================
// LENTERA LIBRARY SYSTEM – ADMINS DELETE (AJAX)
// ============================================================

if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . "/../config/session_guard.php";
require_once __DIR__ . "/../config/db_config.php";

header("Content-Type: application/json; charset=UTF-8");
$conn = db();

if ($_SESSION['user_type'] !== 'admin') {
    echo json_encode(["status" => "error", "message" => "Akses ditolak."]);
    exit;
}

$id = (int)($_POST["id"] ?? 0);
if ($id <= 0) {
    echo json_encode(["status" => "error", "message" => "Parameter tidak valid."]);
    exit;
}

$stmt = $conn->prepare("DELETE FROM admins WHERE id = ?");
$stmt->bind_param("i", $id);

if ($stmt->execute()) {
    echo json_encode(["status" => "success", "message" => "Pengguna berhasil dihapus."]);
} else {
    echo json_encode(["status" => "error", "message" => "Gagal menghapus data pengguna."]);
}
?>
