<?php
// ============================================================
// LENTERA LIBRARY SYSTEM – ADMINS EDIT (ADMIN MASTER)
// ============================================================

$pageTitle = "Edit Pengguna";

if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . "/../config/session_guard.php";
require_once __DIR__ . "/../config/db_config.php";
require_once __DIR__ . "/../includes/header.php";
require_once __DIR__ . "/../includes/sidebar.php";
require_once __DIR__ . "/../includes/topbar.php";

$conn = db();
if ($_SESSION['user_type'] !== 'admin') {
    header("Location: ../dashboard.php");
    exit;
}

$id = (int)($_GET["id"] ?? 0);
if ($id <= 0) die("ID tidak valid.");

$stmt = $conn->prepare("SELECT * FROM admins WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$data = $stmt->get_result()->fetch_assoc();
if (!$data) die("Data pengguna tidak ditemukan.");

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name = trim($_POST["name"] ?? "");
    $role = trim($_POST["role"] ?? "staff");
    $password = trim($_POST["password"] ?? "");

    if ($password !== "") {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $conn->prepare("UPDATE admins SET name=?, role=?, password=? WHERE id=?");
        $stmt->bind_param("sssi", $name, $role, $hash, $id);
    } else {
        $stmt = $conn->prepare("UPDATE admins SET name=?, role=? WHERE id=?");
        $stmt->bind_param("ssi", $name, $role, $id);
    }

    if ($stmt->execute()) $success = "Data pengguna berhasil diperbarui.";
    else $error = "Gagal memperbarui data pengguna.";
}
?>

<main id="mainContent" class="flex-grow-1 p-4">
  <div class="container-fluid" style="max-width:700px;">
    <div class="d-flex justify-content-between align-items-center mb-3">
      <h4 class="text-primary mb-0"><i class="bi bi-pencil-square me-2"></i> Edit Pengguna</h4>
      <a href="admins.php" class="btn btn-secondary btn-sm"><i class="bi bi-arrow-left"></i> Kembali</a>
    </div>

    <?php if (!empty($error)): ?><div class="alert alert-danger"><?= $error ?></div><?php endif; ?>
    <?php if (!empty($success)): ?><div class="alert alert-success"><?= $success ?></div><?php endif; ?>

    <div class="card shadow-sm border-0">
      <div class="card-body">
        <form method="POST">
          <div class="mb-3">
            <label class="form-label fw-semibold">Username</label>
            <input type="text" class="form-control" value="<?= htmlspecialchars($data['username']) ?>" disabled>
          </div>
          <div class="mb-3">
            <label class="form-label fw-semibold">Nama Lengkap</label>
            <input type="text" name="name" class="form-control" value="<?= htmlspecialchars($data['name']) ?>">
          </div>
          <div class="mb-3">
            <label class="form-label fw-semibold">Password (opsional)</label>
            <input type="password" name="password" class="form-control" placeholder="Isi jika ingin mengubah password">
          </div>
          <div class="mb-3">
            <label class="form-label fw-semibold">Role</label>
            <select name="role" class="form-select">
              <option value="admin" <?= $data['role'] === 'admin' ? 'selected' : '' ?>>Admin</option>
              <option value="staff" <?= $data['role'] === 'staff' ? 'selected' : '' ?>>Staff</option>
            </select>
          </div>
          <div class="text-end">
            <button type="submit" class="btn btn-primary"><i class="bi bi-save me-1"></i> Simpan</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</main>

<?php require_once __DIR__ . "/../includes/footer.php"; ?>
