<?php
// ============================================================
// LENTERA LIBRARY SYSTEM – DASHBOARD (ADMIN / STAFF ONLY - FINAL)
// ============================================================
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . "/config/session_guard.php";
require_once __DIR__ . "/config/db_config.php";
require_once __DIR__ . "/includes/header.php";
require_once __DIR__ . "/includes/sidebar.php";
require_once __DIR__ . "/includes/topbar.php";

$conn = db();
$school_id   = $_SESSION['school_id'] ?? 0;
$name        = $_SESSION['name'] ?? '';
$school_name = $_SESSION['school_name'] ?? 'Perpustakaan';

// ============================================================
// CARD DATA STATISTICS
// ============================================================
$total_books    = $conn->query("SELECT COUNT(*) AS c FROM books WHERE school_id=$school_id")->fetch_assoc()['c'] ?? 0;
$total_students = $conn->query("SELECT COUNT(*) AS c FROM students WHERE school_id=$school_id")->fetch_assoc()['c'] ?? 0;
$total_loans    = $conn->query("SELECT COUNT(*) AS c FROM book_loans WHERE school_id=$school_id")->fetch_assoc()['c'] ?? 0;
$total_late     = $conn->query("SELECT COUNT(*) AS c FROM book_loans WHERE school_id=$school_id AND status='late'")->fetch_assoc()['c'] ?? 0;

// ============================================================
// GRAPH: PEMINJAMAN PER BULAN (12 BULAN TERAKHIR)
// ============================================================
$sqlGraph = "
  SELECT DATE_FORMAT(loan_date,'%Y-%m') AS period, COUNT(*) AS total
  FROM book_loans
  WHERE school_id=$school_id 
    AND loan_date >= DATE_SUB(CURDATE(), INTERVAL 12 MONTH)
  GROUP BY period 
  ORDER BY period ASC
";
$resGraph = $conn->query($sqlGraph);
$labels = [];
$values = [];
while ($r = $resGraph->fetch_assoc()) {
  $labels[] = date('M Y', strtotime($r['period'].'-01'));
  $values[] = (int)$r['total'];
}

// ============================================================
// 5 BUKU PALING SERING DIPINJAM
// ============================================================
$sqlTopBooks = "
  SELECT b.title, COUNT(d.book_id) AS total
  FROM book_loan_details d
  JOIN books b ON b.id = d.book_id
  JOIN book_loans l ON l.id = d.loan_id
  WHERE l.school_id=$school_id
  GROUP BY d.book_id
  ORDER BY total DESC 
  LIMIT 5
";
$resBooks = $conn->query($sqlTopBooks);

// ============================================================
// 5 SISWA PALING AKTIF
// ============================================================
$sqlTopStudents = "
  SELECT s.name, COUNT(l.id) AS total
  FROM book_loans l
  JOIN students s ON s.id = l.student_id
  WHERE l.school_id=$school_id
  GROUP BY s.id
  ORDER BY total DESC 
  LIMIT 5
";
$resStudents = $conn->query($sqlTopStudents);
?>

<!-- ============================================================
     MAIN CONTENT
     ============================================================ -->
<main id="mainContent" class="flex-grow-1 p-4">
  <div class="container-fluid">

    <!-- WELCOME SECTION -->
    <div class="mb-4">
      <h4 class="fw-semibold text-primary">📊 Dashboard Perpustakaan</h4>
      <p class="text-muted mb-0">
        Halo, <strong><?= htmlspecialchars($name) ?></strong> 👋  
        Selamat datang di <strong><?= htmlspecialchars($school_name) ?></strong>.
      </p>
    </div>

    <!-- STATISTIC CARDS -->
    <div class="row g-3 mb-4">
      <div class="col-md-3">
        <div class="card text-center shadow-sm border-0 bg-primary text-white">
          <div class="card-body">
            <h2><?= $total_books ?></h2>
            <p class="mb-0">Total Buku</p>
          </div>
        </div>
      </div>
      <div class="col-md-3">
        <div class="card text-center shadow-sm border-0" style="background:#10B981;color:#fff;">
          <div class="card-body">
            <h2><?= $total_students ?></h2>
            <p class="mb-0">Total Siswa</p>
          </div>
        </div>
      </div>
      <div class="col-md-3">
        <div class="card text-center shadow-sm border-0" style="background:#3B82F6;color:#fff;">
          <div class="card-body">
            <h2><?= $total_loans ?></h2>
            <p class="mb-0">Total Peminjaman</p>
          </div>
        </div>
      </div>
      <div class="col-md-3">
        <div class="card text-center shadow-sm border-0" style="background:#EF4444;color:#fff;">
          <div class="card-body">
            <h2><?= $total_late ?></h2>
            <p class="mb-0">Terlambat</p>
          </div>
        </div>
      </div>
    </div>

    <!-- CHART SECTION -->
    <div class="card shadow-sm mb-4">
      <div class="card-body">
        <h5 class="text-primary mb-3">
          <i class="bi bi-bar-chart"></i> Statistik Peminjaman per Bulan
        </h5>
        <div style="height:300px;">
          <canvas id="loanChart"></canvas>
        </div>
      </div>
    </div>

    <!-- TOP DATA -->
    <div class="row">
      <!-- Buku Populer -->
      <div class="col-md-6">
        <div class="card shadow-sm mb-4">
          <div class="card-body">
            <h5 class="text-primary mb-3"><i class="bi bi-book"></i> Buku Paling Sering Dipinjam</h5>
            <div class="table-responsive">
              <table class="table table-sm table-bordered align-middle w-100">
                <thead class="table-light">
                  <tr>
                    <th>Judul Buku</th>
                    <th width="80" class="text-center">Jumlah</th>
                  </tr>
                </thead>
                <tbody>
                  <?php if ($resBooks && $resBooks->num_rows > 0): ?>
                    <?php while ($b = $resBooks->fetch_assoc()): ?>
                      <tr>
                        <td><?= htmlspecialchars($b['title']) ?></td>
                        <td class="text-center"><?= $b['total'] ?></td>
                      </tr>
                    <?php endwhile; ?>
                  <?php else: ?>
                    <tr><td colspan="2" class="text-center text-muted">Belum ada data.</td></tr>
                  <?php endif; ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>

      <!-- Siswa Aktif -->
      <div class="col-md-6">
        <div class="card shadow-sm mb-4">
          <div class="card-body">
            <h5 class="text-primary mb-3"><i class="bi bi-people"></i> Siswa Paling Aktif</h5>
            <div class="table-responsive">
              <table class="table table-sm table-bordered align-middle w-100">
                <thead class="table-light">
                  <tr>
                    <th>Nama Siswa</th>
                    <th width="80" class="text-center">Pinjaman</th>
                  </tr>
                </thead>
                <tbody>
                  <?php if ($resStudents && $resStudents->num_rows > 0): ?>
                    <?php while ($s = $resStudents->fetch_assoc()): ?>
                      <tr>
                        <td><?= htmlspecialchars($s['name']) ?></td>
                        <td class="text-center"><?= $s['total'] ?></td>
                      </tr>
                    <?php endwhile; ?>
                  <?php else: ?>
                    <tr><td colspan="2" class="text-center text-muted">Belum ada data.</td></tr>
                  <?php endif; ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>

  </div>
</main>

<?php require_once __DIR__ . "/includes/footer.php"; ?>

<!-- ============================================================
     📊 CHART.JS INIT (RESPONSIVE)
     ============================================================ -->
<script>
document.addEventListener("DOMContentLoaded", function() {
  const ctx = document.getElementById('loanChart');
  if (!ctx) return;

  window.loanChart = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: <?= json_encode($labels) ?>,
      datasets: [{
        label: 'Jumlah Peminjaman',
        data: <?= json_encode($values) ?>,
        backgroundColor: '#2563EB',
        borderRadius: 6
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      scales: {
        y: { beginAtZero: true, ticks: { stepSize: 1 } }
      },
      plugins: {
        legend: { display: false },
        tooltip: { backgroundColor: '#111827' }
      }
    }
  });

  // ✅ Chart resize otomatis diserahkan ke lentera-ui-enhancements.js
  window.addEventListener("sidebar:changed", () => {
    if (window.loanChart && typeof window.loanChart.resize === "function") {
      setTimeout(() => window.loanChart.resize(), 400);
    }
  });
});
</script>
